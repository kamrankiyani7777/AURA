# AURA experiments (built on the DOT repository)

This folder is the official DOT code (Jun & Lee, ACL 2025) plus a self-contained AURA
implementation. The original DOT code in `src/` and `scripts/` is untouched. The new code is:

```
aura/            core library
  data.py          loading (DOT "####" format or JSONL), linearisation, parsing, implicit/anchor rules
  views.py         view enumeration, dataset-level ranking R, anchored views
  constraints.py   marker-aware structural decoding constraint (LogitsProcessor)
  model.py         T5 training, constrained generation with forced prefixes, scoring, count betas
  core.py          AURA decision rule: count belief, K(x), support, gate, re-viewing, vote, cost (Eqs. 1-7)
  calibration.py   temperature choice, Platt scaling, grid search
  metrics.py       exact-match F1 (no stop-word filtering), implicit/explicit F1, ECE, paired bootstrap
scripts_aura/    pipeline steps (see below)
tests_aura/      tests that run without a GPU
run_aura.sh      the whole pipeline
```

## Setup

```bash
pip install -r requirements_aura.txt        # torch>=2.1, transformers>=4.40, sentencepiece, numpy, scipy
python tests_aura/test_pure.py              # CPU, seconds
python tests_aura/test_pipeline_fake.py     # CPU, seconds (script glue with a fake model)
python scripts_aura/selftest.py --model t5-base   # GPU, ~1-2 min: tokeniser, constrained decoding, scoring, training
```

## Run

```bash
SMOKE=1 DATASETS="R15" SEEDS="5" bash run_aura.sh   # 24 sentences, 2 epochs: checks the whole pipeline (runs_smoke/)
DATASETS="R15" SEEDS="5" bash run_aura.sh           # one dataset, one seed
bash run_aura.sh                                    # 9 benchmarks x seeds {5,10,15,20,25}
```

Drop `--bf16` with `EXTRA=""` on GPUs without bfloat16 (T4, V100). Every step skips work
that already exists, so an interrupted run can simply be restarted.

What `run_aura.sh` does for each dataset and seed:

| step | script | output (in `runs_aura/<dataset>/seed<s>/`) |
|---|---|---|
| view ranking R (pre-trained T5, train set only, once per dataset) | `rank_views.py` | `../R.json` |
| count model f (30 epochs) | `train.py --role count` | `f/` |
| AURA generator g (40 epochs, + one anchored single-view example per gold tuple) | `train.py --role gen` | `g/` |
| DOT-baseline generator (40 epochs, no anchored examples) | `train.py --role gen_dot` | `g_dot/` |
| inference caches (dev, test; DOT test without re-views) | `infer.py` | `cache_*.jsonl` |
| calibration + grid search on dev, for AURA and every ablation | `tune.py` | `tuned.json` |
| wall-clock timing of the real AURA and DOT pipelines | `infer.py --timed` | `timed_*.json` |
| all systems and analyses on test | `evaluate.py` | `results.json` |

Finally `aggregate.py` averages over seeds and prints every table of the paper
(`runs_aura/summary.json`, `runs_aura/tables.tex`).

Optional, shared setting across datasets (Section "Sensitivity and a shared setting"):

```bash
for s in 5 10 15 20 25; do
  python scripts_aura/tune_shared.py --runs runs_aura --seed $s --datasets R15 R16 Lap Rest M-Rest M-Lap Books Clothing Hotel
  for ds in R15 R16 Lap Rest M-Rest M-Lap Books Clothing Hotel; do
    python scripts_aura/evaluate.py --dataset $ds --seed $s --tuned runs_aura/$ds/seed$s/tuned_shared.json --tag _shared
  done
done
python scripts_aura/aggregate.py --runs runs_aura --tag _shared
```

### Lap-Im / Res-Im

Place the triplet files as `data/gomit/Lap-Im/{train,dev,test}.txt` (and `Res-Im`), one line per
sentence: `sentence####[['target', 'opinion', 'positive'], ...]` (JSONL with
`{"sentence": ..., "tuples": [[t, o, s], ...]}` also works). Then
`DATASETS="Lap-Im Res-Im" bash run_aura.sh`. In these datasets implicit elements carry inferred
terms, so an element counts as implicit when its term does not occur in the sentence, and
aspect/opinion contents are not restricted to sentence tokens during decoding.

## How the experiments map to the paper

Everything except wall-clock time is computed offline from one cached GPU run per split:
`infer.py` stores the count betas, the decodes of the top-3 count hypotheses, the greedy count
and the gold count, the element-token log-probabilities at several temperatures, and the
re-decodes of every pooled tuple under all its anchored views (plus 4 random unanchored views).
`core.decide()` then reproduces AURA, DOT, the oracle-count runs and all ablations as pure
functions of that cache, so tuning and ablations need no extra GPU time. `timed` mode runs the
real online pipeline and also reports its F1, which should match `results.json` closely.

| paper | key in `results.json` |
|---|---|
| Table main: DOT (ours) / AURA | `dot.f1`, `aura.f1`, `aura.passes`, `timed_aura.seconds`, `timed_dot.seconds`, `p_aura_vs_dot` |
| Table ablation | `variants.<name>.{f1, implicit.f1, passes}` |
| Table oracle | `count.greedy_acc` (DOT), `count.argmax_acc`, `count.coverage`, `dot_oracle.f1`, `aura_oracle.f1` |
| Implicit vs explicit | `{dot,aura}.implicit.f1`, `{dot,aura}.explicit.f1` |
| Calibration | `calibration_eval.{ece_raw, ece_temp, ece_platt, bins_platt}`, `flags.*` |
| Where computation goes | `passes_by_difficulty.*`, `aura.flag_rate` |
| Sensitivity (tau x M) | `sensitivity` |
| Effect of anchored training alone | `g_with_dot_rule.f1` (AURA's generator with DOT's decision rule) |

MvP and the other baselines are not re-implemented here; use the numbers reported in their
papers or the official MvP code (`github.com/ZubinGou/multi-view-prompting`).

## Implementation choices to state in the paper

1. **Re-implementation.** DOT's pipeline is re-implemented with current `transformers`
   (DOT pins 4.14) so that DOT and AURA share data handling, decoding and evaluation.
   "DOT (ours)" uses the same count model f as AURA and a generator trained exactly like
   DOT's (no anchored examples).
2. **Label-free view ranking.** Both DOT (ours) and AURA use a dataset-level ranking R computed
   on the training set with a pre-trained T5 (as in MvP); no test labels are used at inference.
3. **Evaluation.** Exact match on all elements, without DOT's stop-word filtering. As in DOT's
   targets, an annotated aspect "it" is treated as the implicit aspect (5 ACOS-Lap training
   tuples); one ACOS-Rest training tuple with an empty opinion is read as `null`.
4. **Decoding.** Greedy decoding with a structural constraint (each element marker exactly
   once per tuple, element contents restricted to sentence tokens / categories / sentiment
   words). This is stricter than DOT's vocabulary-only constraint (`--vocab_only` reverts to it).
5. **Count model output.** The count belief uses the probability of continuing the template
   (first token of `[SSEP]`) versus stopping (EOS) at each view boundary, renormalised over the
   two, with teacher forcing on a fixed template R[:6].
6. **Tuples beyond six.** Sentences with more than K_max = 6 gold tuples (a handful per
   dataset) reuse the last view, as in DOT; the oracle count is min(gold, 6).
7. **Calibration.** T is the grid value minimising the dev NLL of gold element tokens; Platt
   scaling on dev tuples from all cached hypotheses. "Raw" confidence for the ablation and for
   "ECE before calibration" is exp(z), the geometric-mean token probability (a sigmoid of z
   would be bounded by 0.5).
8. **Ablation definitions.** *w/o implicit cue* ranks anchored views by NLL alone; *random
   views* uses 4 random unanchored views per tuple. Each variant is tuned on dev with its own
   grid search.
9. **View exclusion.** Re-viewing does not reuse the views R[:max K(x)] already used for the
   chosen hypotheses.
