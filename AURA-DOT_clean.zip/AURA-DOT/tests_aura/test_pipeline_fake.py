"""Integration test of the script glue without torch (run: python tests_aura/test_pipeline_fake.py).

Replaces aura.model by a fake (random betas, random *constrained* decodes honouring forced
prefixes and single-tuple mode, random log-probs) and runs, on 24 real R15 sentences:
infer (dev+test caches, DOT cache without re-views, timed AURA and timed DOT) -> tune ->
evaluate -> aggregate. Checks the cache schema that core.py expects.
"""
import json
import os
import random
import shutil
import sys
import types
from argparse import Namespace

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts_aura"))
sys.path.insert(0, os.path.join(ROOT, "tests_aura"))

import numpy as np
from test_pure import FakeTok
from aura.constraints import ALL, allowed_next, scan
from aura.data import MAX_VIEWS
from aura.views import all_views, save_ranking

RUNS = os.path.join(ROOT, "tests_aura", "_runs_fake")
rng = random.Random(0)
TOK = FakeTok()


def fake_module():
    M = types.ModuleType("aura.model")
    M.DEFAULT_T_GRID = ["0.5", "1.0", "2.0"]
    M.load = lambda path: (object(), TOK)

    def count_betas(f, tok, sents, tmpl, mv):
        return [[rng.random() for _ in range(MAX_VIEWS - 1)] for _ in sents]

    def constrained_generate(model, tok, inputs, contents, mv, prefixes=None, single=False, max_new_tokens=200,
                             batch_size=32, vocab_only=False):
        out = []
        V = len(tok.vocab)
        for i, c in enumerate(contents):
            seq = list(tok(prefixes[i], add_special_tokens=False).input_ids) if prefixes and prefixes[i] else []
            # keep outputs short: prefer EOS / markers when allowed
            for _ in range(max_new_tokens):
                allowed, excl = allowed_next(scan(seq, mv), mv, c, single)
                cand = list(range(V)) if allowed is ALL else sorted(allowed)
                cand = [x for x in cand if allowed is not ALL or x not in excl]
                if mv.eos_id in cand and rng.random() < 0.6:
                    nxt = mv.eos_id
                else:
                    starts = [x for x in cand if x in mv.starts]
                    nxt = rng.choice(starts) if starts and rng.random() < 0.5 else rng.choice(cand)
                seq.append(nxt)
                if nxt == mv.eos_id:
                    break
            out.append(seq)
        return out

    def token_logprobs(model, tok, inputs, target_ids, T_grid=("1.0",), batch_size=32):
        return [{T: -np.abs(np.random.RandomState(len(t)).randn(len(t))) / float(T) for T in T_grid} for t in target_ids]

    def mean_nll(model, tok, inputs, targets, batch_size=32):
        return [rng.random() * 3 for _ in targets]

    def segment_z(ids, lp_by_T, mv):
        st = scan(ids, mv)
        res = []
        for seg in st.segments:
            pos = [p for p, el in seg if el is not None]
            res.append({T: float(np.mean(lp_by_T[T][pos])) if pos else -1e9 for T in lp_by_T})
        return res

    def content_nll(ids, lp_by_T, mv):
        st = scan(ids, mv)
        pos = [p for seg in st.segments for p, el in seg if el is not None]
        return {T: (float(-lp_by_T[T][pos].sum()), len(pos)) for T in lp_by_T}

    M.count_betas, M.constrained_generate, M.token_logprobs = count_betas, constrained_generate, token_logprobs
    M.mean_nll, M.segment_z, M.content_nll = mean_nll, segment_z, content_nll
    M.decode_text = lambda tok, ids: tok.decode(ids)
    return M


def main():
    import aura
    fake = fake_module()
    sys.modules["aura.model"] = fake
    aura.model = fake
    sys.modules["torch"] = types.SimpleNamespace(cuda=types.SimpleNamespace(is_available=lambda: False,
                                                                             synchronize=lambda: None))
    shutil.rmtree(RUNS, ignore_errors=True)
    os.makedirs(os.path.join(RUNS, "R15"))
    save_ranking(os.path.join(RUNS, "R15", "R.json"), all_views("quad"))
    import infer, tune, evaluate
    from common import Logger, read_jsonl

    base = dict(data_root=os.path.join(ROOT, "data"), runs=RUNS, dataset="R15", smoke=True, seed=5,
                vocab_only=False, out=None, review_chunk=7, timed=False, dot=False, tuned=None)
    log = Logger(os.path.join(RUNS, "log.txt"))
    for split, gen, nrv in [("dev", "g", False), ("test", "g", False), ("test", "g_dot", True)]:
        infer.cache_mode(Namespace(**base, split=split, gen=gen, no_reviews=nrv), log)
    sd = os.path.join(RUNS, "R15", "seed5")
    test = read_jsonl(os.path.join(sd, "cache_g_test.jsonl"))
    r = test[0]
    assert set(r) >= {"idx", "sentence", "gold", "gold_count", "betas", "hyps", "reviews"}
    assert len(r["betas"]) == MAX_VIEWS - 1
    assert str(min(r["gold_count"], MAX_VIEWS)) in r["hyps"]
    n_rev = sum(len(x["reviews"]) for x in test)
    n_rand = sum(len(v["rand_cands"]) for x in test for v in x["reviews"].values())
    n_anch = sum(len(v["cands"]) for x in test for v in x["reviews"].values())
    assert n_rev > 0 and n_rand > 0 and n_anch > 0
    for x in test:
        for v in x["reviews"].values():
            for c in v["cands"]:
                assert c["text"].startswith(v["anchor"]), (c["text"], v["anchor"])
                assert set(c["z"]) == set(fake.DEFAULT_T_GRID)
    dev = read_jsonl(os.path.join(sd, "cache_g_dev.jsonl"))
    assert all("gold_nll" in d for d in dev)
    print(f"  ok cache: {len(test)} test records, {n_rev} reviewed tuples, {n_anch} anchored + {n_rand} random re-decodes")

    small = {"rho": [0.8, 0.95], "H": [2, 3], "tau": [0.5, 0.8], "tau_v": [0.4], "M": [1, 2]}
    out = tune.tune_records(dev, grid=small, log=lambda *a: None)
    json.dump(out, open(os.path.join(sd, "tuned.json"), "w"))
    print("  ok tune")
    for dot in (False, True):
        infer.timed_mode(Namespace(**{**base, "timed": True, "dot": dot, "tuned": os.path.join(sd, "tuned.json")},
                                   split="test", gen="g_dot" if dot else "g", no_reviews=False), log)
    print("  ok timed AURA + DOT")
    sys.argv = ["evaluate.py", "--dataset", "R15", "--runs", RUNS, "--smoke", "--seed", "5", "--bootstrap", "50"]
    evaluate.main()
    res = json.load(open(os.path.join(sd, "results.json")))
    assert {"aura", "dot", "dot_oracle", "aura_oracle", "variants", "count", "calibration_eval", "flags",
            "passes_by_difficulty", "sensitivity", "timed_aura", "timed_dot"} <= set(res)
    print("  ok evaluate")
    import aggregate
    sys.argv = ["aggregate.py", "--runs", RUNS]
    aggregate.main()
    print("  ok aggregate")
    shutil.rmtree(RUNS, ignore_errors=True)
    print("\npipeline test passed")


if __name__ == "__main__":
    main()
