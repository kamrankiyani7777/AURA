"""Tests for the torch-free parts (run: python tests_aura/test_pure.py).

1. data: loading, linearisation, parsing round trip on the real datasets
2. views: anchored views, implicit-last rule
3. constraints: scanner + allowed_next with a fake tokenizer; random-score constrained decoding
   always yields well-formed, parseable outputs
4. core/calibration/evaluate on a synthetic cache: belief, hypothesis set, gate, vote, grid
   search, every evaluation routine end-to-end
"""
import math
import os
import random
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts_aura"))

from aura.data import (MAX_VIEWS, QUAD_MARKERS, SSEP, anchor_of, dataset_path, generator_input,
                       implicit_elements, linearise, linearise_many, load_split, parse_output, template, tuple_key)
from aura.views import all_views, anchored_views, training_anchor_view
from aura.constraints import ALL, MarkerVocab, allowed_next, scan
from aura.core import (Calibration, Config, count_belief, decide, greedy_count, hypothesis_set, run, support, vote)
from aura.calibration import fit_calibration, fit_platt, grid_search
from aura.metrics import ece, exact_match_f1, paired_bootstrap
import numpy as np

PASS = []


def ok(name):
    PASS.append(name)
    print("  ok", name)


# ------------------------------------------------------------------ 1. data
def test_data():
    data_root = os.path.join(ROOT, "data")
    for task, ds in [("asqp", "R15"), ("acos", "Lap"), ("memd", "Books")]:
        for split in ("train", "dev", "test"):
            ex = load_split(dataset_path(data_root, task, ds, split), "quad")
            assert ex and all(e.count > 0 for e in ex)
            views = all_views("quad")
            bad = 0
            for e in ex:
                k = min(e.count, MAX_VIEWS)
                vs = views[:k]
                text = linearise_many(e.tuples, vs, "quad")
                back = parse_output(text, "quad")
                if back != list(e.tuples):
                    bad += 1
            assert bad == 0, f"{ds}/{split}: {bad} round-trip failures"
    ok("data round trip on R15, Lap, Books (all splits)")


# ------------------------------------------------------------------ 2. views
def test_views():
    assert len(all_views("quad")) == 24 and len(all_views("triplet")) == 6
    t = ("food", "food#quality", "great", "null")
    s = "space was limited , but the food made up for it ."
    assert implicit_elements(t, s, "quad") == ["[O]"]
    mk, val = anchor_of(t, s, "quad")
    assert (mk, val) == ("[A]", "food")
    av = anchored_views(mk, ["[O]"], "quad")
    assert len(av) == 2 and all(v[0] == "[A]" and v[-1] == "[O]" for v in av)
    t2 = ("null", "laptop#general", "bad", "slow")
    mk2, val2 = anchor_of(t2, "it is slow", "quad")
    assert (mk2, val2) == ("[C]", "laptop#general")
    av2 = anchored_views(mk2, ["[A]"], "quad")
    assert all(v[0] == "[C]" and v[-1] == "[A]" for v in av2) and len(av2) == 2
    R = all_views("quad")[::-1]
    v = training_anchor_view(mk, ["[O]"], "quad", R)
    assert v in av
    # triplet: target explicit, opinion inferred
    tt = ("battery", "durable", "great")
    assert implicit_elements(tt, "the battery lasts all day", "triplet") == ["[O]"]
    ok("views: anchored + implicit-last")


# ------------------------------------------------------------------ 3. constraints
class FakeEnc:
    def __init__(self, ids):
        self.input_ids = ids


class FakeTok:
    """Whitespace tokenizer; markers split into '[' + name + ']' so that they share a first
    token (exercises the partial-marker logic). eos=1, pad=0."""
    def __init__(self):
        self.vocab = {"<pad>": 0, "</s>": 1}
        self.eos_token_id, self.pad_token_id = 1, 0

    def _id(self, w):
        if w not in self.vocab:
            self.vocab[w] = len(self.vocab)
        return self.vocab[w]

    def __call__(self, text, add_special_tokens=True):
        ids = []
        for w in text.split():
            if w.startswith("[") and w.endswith("]"):
                ids += [self._id("["), self._id(w[1:-1]), self._id("]")]
            else:
                ids.append(self._id(w))
        if add_special_tokens:
            ids.append(1)
        return FakeEnc(ids)

    def decode(self, ids):
        inv = {v: k for k, v in self.vocab.items()}
        out = []
        for i in ids:
            if i in (0, 1):
                continue
            out.append(inv[i])
        return " ".join(out).replace("[ ", "[").replace(" ]", "]")


def test_constraints():
    tok = FakeTok()
    mv = MarkerVocab.build(tok, "quad")
    s = "the food was great but service slow"
    src = set(tok(s, add_special_tokens=False).input_ids)
    cats = set(tok("food#quality service#general", add_special_tokens=False).input_ids)
    sent = set(tok("great bad ok", add_special_tokens=False).input_ids)
    content = {"[A]": src | set(tok("it", add_special_tokens=False).input_ids),
               "[O]": src | set(tok("null", add_special_tokens=False).input_ids), "[C]": cats, "[S]": sent}
    # scanner on a gold target
    tgt = "[A] food [C] food#quality [S] great [O] great [SSEP] [C] service#general [A] service [O] slow [S] bad"
    ids = tok(tgt).input_ids
    st = scan(ids, mv)
    assert st.tuples_done == 1 and len(st.segments) == 2
    assert [el for _, el in st.segments[0]] == ["[A]", "[C]", "[S]", "[O]"]
    rng = random.Random(0)
    vocab_size = len(tok.vocab) + 5
    for trial in range(300):
        single = trial % 3 == 0
        prefix = tok("[A] food", add_special_tokens=False).input_ids if trial % 2 else []
        seq = list(prefix)
        for _ in range(80):
            allowed, excl = allowed_next(scan(seq, mv), mv, content, single)
            cand = [i for i in range(vocab_size) if (allowed is ALL and i not in excl) or (allowed is not ALL and i in allowed)]
            assert cand, (seq, allowed)
            nxt = rng.choice(cand)
            seq.append(nxt)
            if nxt == 1:
                break
        if seq[-1] != 1:
            continue           # ran out of budget mid-tuple: generate() would cut it too
        parsed = parse_output(tok.decode(seq), "quad")
        assert all(p is not None for p in parsed), (tok.decode(seq), parsed)
        if single:
            assert len(parsed) == 1
    ok("constraints: 300 random constrained decodes are all well-formed")


# ------------------------------------------------------------------ 4. core on a synthetic cache
def synth_records(n, seed, T_grid=("0.5", "1.0", "2.0")):
    """Records whose generator is right more often with higher z, count model ~ informative."""
    rng = random.Random(seed)
    recs = []
    for i in range(n):
        g = rng.choice([1, 1, 1, 2, 2, 3])
        gold = [(f"a{i}_{j}", "food#quality", rng.choice(["great", "bad"]), rng.choice([f"o{i}_{j}", "null"])) for j in range(g)]
        betas = []
        for b in range(1, MAX_VIEWS):
            p = 0.9 if b < g else 0.1
            betas.append(min(0.99, max(0.01, p + rng.gauss(0, 0.25))))
        hyps = {}
        top = sorted(range(MAX_VIEWS), key=lambda i: -count_belief(betas)[i])[:3]
        ks = sorted({i + 1 for i in top} | {greedy_count(betas), min(g, MAX_VIEWS)})
        reviews = {}
        for k in ks:
            segs = []
            for j in range(k):
                if j < g and rng.random() < 0.75:
                    t = gold[j]
                    z = -abs(rng.gauss(0.2, 0.2))
                else:
                    t = (f"wrong{i}_{j}_{k}", "food#quality", "ok", "null")
                    z = -abs(rng.gauss(1.0, 0.5))
                segs.append({"t": list(t), "view": list(QUAD_MARKERS), "z": {T: z * float(T) ** -0.5 for T in T_grid}})
                good = t in gold
                cands = []
                for v in range(4):
                    if rng.random() < (0.8 if good else 0.4):
                        ct = gold[min(j, g - 1)]
                    else:
                        ct = None if rng.random() < 0.2 else (f"x{rng.random()}", "food#quality", "ok", "null")
                    cz = -abs(rng.gauss(0.3 if ct in gold else 1.0, 0.3))
                    cands.append({"view": list(QUAD_MARKERS), "nll": rng.random(), "implicit_last": v < 2,
                                  "t": list(ct) if ct else None, "z": {T: cz for T in T_grid}})
                reviews[tuple_key(t)] = {"anchor": "[A]", "implicit": [], "used_views": [], "cands": cands,
                                         "rand_cands": cands[::-1]}
            hyps[str(k)] = {"segments": segs}
        gold_nll = {T: [abs(float(T) - 1.0) * 10 + 5, 10] for T in T_grid}
        recs.append({"idx": i, "sentence": " ".join(t[0] for t in gold) + " x", "gold": [list(t) for t in gold],
                     "gold_count": g, "betas": betas, "hyps": hyps, "reviews": reviews, "gold_nll": gold_nll})
    return recs


def test_core():
    p = count_belief([0.9, 0.2, 0.1, 0.1, 0.1])
    assert abs(sum(p) - 1) < 1e-9 and max(range(6), key=lambda i: p[i]) == 1
    assert greedy_count([0.9, 0.2, 0.1, 0.1, 0.1]) == 2 and greedy_count([0.9] * 5) == 6
    assert hypothesis_set([0.5, 0.3, 0.2, 0, 0, 0], 0.8, 3) == [1, 2]
    assert hypothesis_set([0.5, 0.3, 0.2, 0, 0, 0], 0.99, 2) == [1, 2]
    sup = support({1: {("a",): 0}, 2: {("a",): 0, ("b",): 0}}, [0.6, 0.4, 0, 0, 0, 0])
    assert abs(sup[("a",)] - 1) < 1e-9 and abs(sup[("b",)] - 0.4) < 1e-9
    kept, A = vote(("a",), 0.6, [(("a",), 0.8), (("b",), 0.9)], 0.4)
    assert kept == ("a",) and abs(A - (1.4 / 3)) < 1e-9
    kept, _ = vote(("a",), 0.2, [(("b",), 0.9), (("b",), 0.9)], 0.4)
    assert kept == ("b",)
    kept, _ = vote(("a",), 0.2, [(None, 0.0)], 0.4)
    assert kept is None
    w, b = fit_platt(np.array([-2, -1.5, -0.3, -0.1, -0.2, -1.8]), np.array([0, 0, 1, 1, 1, 0.]))
    assert w > 0
    assert ece([0.9, 0.9, 0.1], [1, 1, 0]) < 11
    ok("core: belief, greedy, hypothesis set, support, vote, platt, ece")

    from tune import tune_records
    import evaluate as E
    dev, test = synth_records(150, 1), synth_records(150, 2)
    small = {"rho": [0.8, 0.95], "H": [2, 3], "tau": [0.5, 0.8], "tau_v": [0.3, 0.5], "M": [1, 3]}
    tuned = tune_records(dev, grid=small, log=lambda *a: None)
    assert tuned["calibration"]["T"] == "1.0"            # synthetic gold NLL is minimal at T=1
    cal, cfg = Calibration(**tuned["calibration"]), Config(**tuned["config"])
    outs = run(test, cfg, cal)
    aura = E.system_scores(test, outs, "quad")
    dot = E.system_scores(test, run(test, Config(mode="dot"), Calibration()), "quad")
    oracle = E.system_scores(test, run(test, Config(mode="dot_oracle"), Calibration()), "quad")
    assert oracle["f1"] >= dot["f1"] - 1e-9
    assert all(o["passes"] >= 1 + len(o["K"]) for o in outs)
    E.count_stats(test, cfg)
    E.calibration_stats(test, outs, cal)
    E.flag_analysis(test, outs)
    E.passes_by_difficulty(test, outs, "quad")
    E.sensitivity(test, cfg, cal, taus=(0.5, 0.9), Ms=(1, 2))
    for name, v in tuned["variants"].items():
        E.system_scores(test, run(test, Config(**v["config"]), cal), "quad")
    p = paired_bootstrap([o["pred"] for o in outs], [o["pred"] for o in run(test, Config(mode="dot"), Calibration())],
                         E.golds_of(test), 200)
    print(f"     synthetic: AURA F1 {aura['f1']:.1f} ({aura['passes']:.2f} passes) | DOT {dot['f1']:.1f} | "
          f"DOT oracle {oracle['f1']:.1f} | p={p:.3f}")
    assert aura["f1"] > dot["f1"], "on the synthetic cache AURA should beat DOT"
    ok("tune + evaluate end-to-end on a synthetic cache")


if __name__ == "__main__":
    test_data()
    test_views()
    test_constraints()
    test_core()
    print(f"\nall {len(PASS)} test groups passed")
