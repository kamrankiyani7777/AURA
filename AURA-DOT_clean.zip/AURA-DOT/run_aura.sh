#!/usr/bin/env bash
# Full AURA experiment pipeline.  Usage:
#   bash run_aura.sh                                   # 9 benchmarks x 5 seeds
#   DATASETS="R15 Lap" SEEDS="5" bash run_aura.sh      # subset
#   SMOKE=1 DATASETS="R15" SEEDS="5" bash run_aura.sh  # 2-minute end-to-end check
#   DATASETS="Lap-Im Res-Im" bash run_aura.sh          # once data/gomit/{Lap-Im,Res-Im} exist
set -euo pipefail
cd "$(dirname "$0")"

DATASETS=${DATASETS:-"R15 R16 Lap Rest M-Rest M-Lap Books Clothing Hotel"}
SEEDS=${SEEDS:-"5 10 15 20 25"}
RUNS=${RUNS:-runs_aura}; [ "${SMOKE:-0}" = "1" ] && RUNS=${RUNS_SMOKE:-runs_smoke}
MODEL=${MODEL:-t5-base}
EXTRA=${EXTRA:-"--bf16"}           # drop --bf16 on GPUs without bfloat16 (e.g. T4, V100)
SMK=""; [ "${SMOKE:-0}" = "1" ] && SMK="--smoke"
S=scripts_aura

for ds in $DATASETS; do
  common="--dataset $ds --runs $RUNS $SMK"
  [ -f "$RUNS/$ds/R.json" ] || python $S/rank_views.py $common --model $MODEL
  for seed in $SEEDS; do
    sd="$RUNS/$ds/seed$seed"
    echo "=================== $ds seed $seed ==================="
    [ -d "$sd/f" ]     || python $S/train.py $common --seed $seed --role count   --model $MODEL $EXTRA
    [ -d "$sd/g" ]     || python $S/train.py $common --seed $seed --role gen     --model $MODEL $EXTRA
    [ -d "$sd/g_dot" ] || python $S/train.py $common --seed $seed --role gen_dot --model $MODEL $EXTRA
    [ -f "$sd/cache_g_dev.jsonl" ]      || python $S/infer.py $common --seed $seed --split dev  --gen g
    [ -f "$sd/cache_g_test.jsonl" ]     || python $S/infer.py $common --seed $seed --split test --gen g
    [ -f "$sd/cache_g_dot_test.jsonl" ] || python $S/infer.py $common --seed $seed --split test --gen g_dot --no_reviews
    python $S/tune.py $common --seed $seed
    python $S/infer.py $common --seed $seed --split test --gen g     --timed --tuned "$sd/tuned.json"
    python $S/infer.py $common --seed $seed --split test --gen g_dot --timed --dot --tuned "$sd/tuned.json"
    python $S/evaluate.py $common --seed $seed
  done
done

python $S/aggregate.py --runs $RUNS
