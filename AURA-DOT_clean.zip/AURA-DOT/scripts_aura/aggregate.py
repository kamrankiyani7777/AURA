"""Step 6: average results over seeds and print the paper's tables (plain text + LaTeX rows).

  python scripts_aura/aggregate.py --runs runs_aura [--tag _shared]
Writes runs_aura/summary.json and runs_aura/tables.tex.
"""
import argparse
import glob
import json
import os
import statistics as st

MAIN = ["R15", "R16", "Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]
IM = ["Lap-Im", "Res-Im"]
ORACLE_SETS = ["R15", "R16", "Lap", "Rest"]
IMPLICIT_SETS = ["Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]
VARIANTS = [("full", "AURA (full)"), ("wo_belief", "w/o count belief"), ("wo_support", "w/o support"),
            ("wo_calibration", "w/o calibration"), ("wo_reviewing", "w/o re-viewing"),
            ("accept_all", "accept all"), ("random_views", "random views"),
            ("wo_implicit_cue", "w/o implicit cue")]


def get(d, path):
    for k in path.split("."):
        if d is None or k not in d:
            return None
        d = d[k]
    return d


def ms(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return None, None
    return st.mean(vals), (st.stdev(vals) if len(vals) > 1 else 0.0)


def fmt(m, s=None, nd=2):
    if m is None:
        return "--"
    return f"{m:.{nd}f}" + (f"$_{{\\pm{s:.{nd}f}}}$" if s is not None else "")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--tag", default="")
    args = p.parse_args()
    R = {}
    for fp in sorted(glob.glob(os.path.join(args.runs, "*", "seed*", f"results{args.tag}.json"))):
        r = json.load(open(fp))
        R.setdefault(r["dataset"], []).append(r)
    if not R:
        raise SystemExit("no results found")

    def agg(ds, path):
        return ms([get(r, path) for r in R.get(ds, [])])

    summary = {ds: {} for ds in R}
    paths = ["aura.f1", "aura.passes", "aura.flag_rate", "aura.implicit.f1", "aura.explicit.f1",
             "aura_oracle.f1", "dot.f1", "dot.implicit.f1", "dot.explicit.f1", "dot_oracle.f1",
             "g_with_dot_rule.f1", "count.greedy_acc", "count.argmax_acc", "count.coverage", "count.mean_|K|",
             "calibration_eval.ece_raw", "calibration_eval.ece_temp", "calibration_eval.ece_platt",
             "flags.precision_accepted", "flags.precision_flagged", "flags.change_rate_when_wrong",
             "flags.change_rate_when_right", "passes_by_difficulty.easy_two_pass_pct",
             "passes_by_difficulty.hard_mean", "p_aura_vs_dot", "timed_aura.seconds", "timed_dot.seconds"]
    paths += [f"variants.{v}.{m}" for v, _ in VARIANTS for m in ("f1", "implicit.f1", "passes")]
    for ds in R:
        for pth in paths:
            m, s = agg(ds, pth)
            summary[ds][pth] = {"mean": m, "std": s, "n": len(R[ds])}
    json.dump(summary, open(os.path.join(args.runs, f"summary{args.tag}.json"), "w"), indent=1)

    L = []
    S = lambda ds, pth: summary.get(ds, {}).get(pth, {}).get("mean")
    sd = lambda ds, pth: summary.get(ds, {}).get(pth, {}).get("std")
    main_ds = [d for d in MAIN if d in R]
    print("\n== Main results (F1, mean over seeds) ==")
    print(f"{'':10s}" + "".join(f"{d:>10s}" for d in main_ds) + f"{'Avg':>8s}")
    for name, key in [("DOT", "dot.f1"), ("AURA", "aura.f1")]:
        vals = [S(d, key) for d in main_ds]
        avg = st.mean([v for v in vals if v is not None]) if any(v is not None for v in vals) else None
        print(f"{name:10s}" + "".join(f"{(v if v is not None else float('nan')):10.2f}" for v in vals)
              + f"{(avg if avg is not None else float('nan')):8.2f}")
        L.append(f"{name} (ours) & " + " & ".join(fmt(S(d, key), sd(d, key)) for d in main_ds)
                 + f" & {fmt(avg)} \\\\  % main")
    pa = [S(d, "aura.passes") for d in main_ds]
    ta = [S(d, "timed_aura.seconds") for d in main_ds]
    td = [S(d, "timed_dot.seconds") for d in main_ds]
    if pa and all(v is not None for v in pa):
        print(f"AURA passes/input avg {st.mean(pa):.2f}")
    if ta and all(v is not None for v in ta):
        print(f"time total AURA {sum(ta):.0f}s DOT {sum(td) if all(v is not None for v in td) else float('nan'):.0f}s")
    ps = [S(d, "p_aura_vs_dot") for d in main_ds]
    print("bootstrap p (AURA>DOT) per dataset:", {d: round(v, 3) for d, v in zip(main_ds, ps) if v is not None})

    print("\n== Ablation (avg over available main datasets) ==")
    for v, label in VARIANTS:
        row = []
        for m in ("f1", "implicit.f1", "passes"):
            vals = [S(d, f"variants.{v}.{m}") for d in main_ds]
            vals = [x for x in vals if x is not None]
            row.append(st.mean(vals) if vals else None)
        print(f"{label:20s} " + "  ".join(fmt(x) for x in row))
        L.append(f"{label:20s} & " + " & ".join(fmt(x) for x in row) + " \\\\  % ablation")

    print("\n== Count errors (ASQP + ACOS) ==")
    od = [d for d in ORACLE_SETS if d in R]
    avg = lambda key: (st.mean([S(d, key) for d in od if S(d, key) is not None]) if od and any(S(d, key) is not None for d in od) else None)
    rows = [("DOT", avg("count.greedy_acc"), None, avg("dot.f1"), avg("dot_oracle.f1")),
            ("AURA", avg("count.argmax_acc"), avg("count.coverage"), avg("aura.f1"), avg("aura_oracle.f1"))]
    for name, a, c, f, o in rows:
        print(f"{name:6s} acc {fmt(a)}  coverage {fmt(c)}  F1 pred {fmt(f)}  oracle {fmt(o)}")
        L.append(f"{name} & {fmt(a)} & {fmt(c) if c is not None else '--'} & {fmt(f)} & {fmt(o)} \\\\  % oracle")

    print("\n== Implicit vs explicit (ACOS + MEMD) ==")
    idd = [d for d in IMPLICIT_SETS if d in R]
    for name, pre in [("DOT", "dot"), ("AURA", "aura")]:
        im = [S(d, f"{pre}.implicit.f1") for d in idd]
        ex = [S(d, f"{pre}.explicit.f1") for d in idd]
        im, ex = [x for x in im if x is not None], [x for x in ex if x is not None]
        print(f"{name:6s} implicit {fmt(st.mean(im) if im else None)}  explicit {fmt(st.mean(ex) if ex else None)}")

    print("\n== Calibration / flags / cost (avg over datasets) ==")
    for key in ["calibration_eval.ece_raw", "calibration_eval.ece_temp", "calibration_eval.ece_platt",
                "flags.precision_accepted", "flags.precision_flagged", "flags.change_rate_when_wrong",
                "flags.change_rate_when_right", "aura.flag_rate", "passes_by_difficulty.easy_two_pass_pct",
                "passes_by_difficulty.hard_mean"]:
        vals = [S(d, key) for d in main_ds if S(d, key) is not None]
        print(f"{key:42s} {fmt(st.mean(vals) if vals else None)}")

    imd = [d for d in IM if d in R]
    if imd:
        print("\n== Inferred implicit terms (Lap-Im / Res-Im) ==")
        for name, key in [("DOT", "dot.f1"), ("AURA", "aura.f1")]:
            print(f"{name:6s} " + "  ".join(f"{d} {fmt(S(d, key), sd(d, key))}" for d in imd))
            L.append(f"{name} (ours) & " + " & ".join(fmt(S(d, key), sd(d, key)) for d in imd) + " \\\\  % im")

    with open(os.path.join(args.runs, f"tables{args.tag}.tex"), "w") as fp:
        fp.write("\n".join(L) + "\n")
    print(f"\nwrote {os.path.join(args.runs, f'summary{args.tag}.json')} and tables{args.tag}.tex")


if __name__ == "__main__":
    main()
