"""Step 3: run the models once and cache everything AURA's decisions need.

Cache mode (default) writes one JSON record per sentence with
  betas (count model), generator decodes for the top-3 count hypotheses + the greedy count +
  the gold count, per-tuple confidences z at several temperatures, re-decodes of every pooled
  tuple under every anchored view (with view NLL for ranking), and on dev the gold-target NLL
  for temperature fitting. Tuning, ablations, oracle studies and the DOT baseline are then
  computed offline by tune.py / evaluate.py.

  --no_reviews : skip re-decoding (use for the DOT baseline generator g_dot)

Timed mode (--timed --tuned tuned.json) runs only the real AURA path (or DOT with --dot) and
reports wall-clock time per test set: count -> K(x) decodes -> scoring -> gate -> re-view of
flagged tuples with the top-M views -> vote.
"""
import json
import os
import random
import time

from common import Logger, base_parser, categories, load, mode_of, free_vocab_of, seed_dir, write_jsonl
from aura.data import (MAX_VIEWS, SSEP, anchor_of, generator_input, implicit_elements, linearise,
                       linearise_many, parse_output, template, tuple_key)
from aura.core import Calibration, Config, count_belief, greedy_count, hypothesis_set, vote
from aura.views import all_views, anchored_views, load_ranking

MAX_NEW = 200  # max generated tokens for a full multi-tuple output
N_RANDOM = 4   # unanchored random views per pooled tuple, for the "random views" ablation


def build(args):
    from aura import model as M
    from aura.constraints import MarkerVocab, content_vocab
    sd = seed_dir(args, args.seed)
    f, tok = M.load(os.path.join(sd, "f"))
    g, _ = M.load(os.path.join(sd, args.gen))
    mode = mode_of(args.dataset)
    mv = MarkerVocab.build(tok, mode)
    R = load_ranking(os.path.join(args.runs, args.dataset, "R.json"))
    cats = categories(load(args, "train"))
    return M, f, g, tok, mv, R, cats, mode


def contents_for(tok, mode, sentences, cats, free):
    from aura.constraints import content_vocab
    return [content_vocab(tok, mode, tok(s, add_special_tokens=False).input_ids, cats, free) for s in sentences]


def decode_hypotheses(M, g, tok, mv, R, mode, sentences, ks, contents, T_grid, vocab_only=False):
    """Decode g under template R[:k] for each (sentence index, k); return segments with z."""
    inputs = [generator_input(sentences[i], R[:k]) for i, k in ks]
    cont = [contents[i] for i, _ in ks]
    ids = M.constrained_generate(g, tok, inputs, cont, mv, max_new_tokens=MAX_NEW, vocab_only=vocab_only)
    lps = M.token_logprobs(g, tok, inputs, ids, T_grid)
    out = []
    for (i, k), seq, lp in zip(ks, ids, lps):
        text = M.decode_text(tok, seq)
        tuples = parse_output(text, mode)
        zs = M.segment_z(seq, lp, mv)
        segs = []
        for j, t in enumerate(tuples):
            z = zs[j] if j < len(zs) else {T: -1e9 for T in T_grid}
            segs.append({"t": list(t) if t else None, "view": list(R[min(j, k - 1)]), "z": z})
        out.append({"text": text, "segments": segs, "n_tokens": len(seq)})
    return out




def review_batch(M, g, tok, mv, mode, items, T_grid, vocab_only=False):
    """Re-decode every pooled tuple of several sentences under all its anchored views (anchor
    forced as decoder prefix) plus N_RANDOM unanchored random views, batched across sentences.
    items: [(sentence, [(tuple, used_views)], content)] -> one reviews dict per item."""
    jobs = []      # (item, tuple, view, prefix, kind)
    for it, (sentence, tuples_with_views, _) in enumerate(items):
        for t, used in tuples_with_views:
            imp = implicit_elements(t, sentence, mode)
            mk, val = anchor_of(t, sentence, mode)
            strict = set(anchored_views(mk, imp, mode, exclude=used, implicit_last=True))
            for v in anchored_views(mk, imp, mode, exclude=used, implicit_last=False):
                jobs.append((it, t, v, f"{mk} {val}", v in strict))
            rng = random.Random(f"{sentence}|{tuple_key(t)}")
            pool = [v for v in all_views(mode) if v not in set(used)]
            for v in rng.sample(pool, min(N_RANDOM, len(pool))):
                jobs.append((it, t, v, None, "random"))     # no anchor: free single-tuple decode
    out = [{} for _ in items]
    if not jobs:
        return out
    inputs = [generator_input(items[it][0], [v]) for it, _, v, _, _ in jobs]
    nll = M.mean_nll(g, tok, inputs, [linearise(t, v, mode) for _, t, v, _, _ in jobs])
    ids = M.constrained_generate(g, tok, inputs, [items[it][2] for it, _, _, _, _ in jobs], mv,
                                 prefixes=[p for _, _, _, p, _ in jobs], single=True, max_new_tokens=64,
                                 vocab_only=vocab_only)
    lps = M.token_logprobs(g, tok, inputs, ids, T_grid)
    for (it, t, v, p, kind), n, seq, lp in zip(jobs, nll, ids, lps):
        sentence = items[it][0]
        text = M.decode_text(tok, seq)
        parsed = parse_output(text, mode)
        q = parsed[0] if parsed else None
        zs = M.segment_z(seq, lp, mv)
        z = zs[0] if zs else {T: -1e9 for T in T_grid}
        mk0, _ = anchor_of(t, sentence, mode)
        e = out[it].setdefault(tuple_key(t), {"anchor": mk0, "implicit": implicit_elements(t, sentence, mode),
                                              "used_views": [], "cands": [], "rand_cands": []})
        c = {"view": list(v), "nll": n, "t": list(q) if q else None, "z": z, "text": text}
        if kind == "random":
            e["rand_cands"].append(c)
        else:
            c["implicit_last"] = bool(kind)
            e["cands"].append(c)
    for it, (_, tuples_with_views, _) in enumerate(items):
        for t, used in tuples_with_views:
            if tuple_key(t) in out[it]:
                out[it][tuple_key(t)]["used_views"] = [list(u) for u in used]
    return out


def cache_mode(args, log):
    M, f, g, tok, mv, R, cats, mode = build(args)
    T_grid = M.DEFAULT_T_GRID
    ex = load(args, args.split)
    sents = [e.sentence for e in ex]
    contents = contents_for(tok, mode, sents, cats, free_vocab_of(args.dataset))
    t0 = time.time()
    betas = M.count_betas(f, tok, sents, template(R[:MAX_VIEWS]), mv)
    log(f"betas done ({time.time() - t0:.0f}s)")
    ks_per = []
    for e, b in zip(ex, betas):
        probs = count_belief(b)
        top = sorted(range(MAX_VIEWS), key=lambda i: -probs[i])[:3]
        ks = sorted({i + 1 for i in top} | {greedy_count(b), min(max(e.count, 1), MAX_VIEWS)})
        ks_per.append(ks)
    jobs = [(i, k) for i, ks in enumerate(ks_per) for k in ks]
    hyps = decode_hypotheses(M, g, tok, mv, R, mode, sents, jobs, contents, T_grid, args.vocab_only)
    log(f"{len(jobs)} hypothesis decodes done ({time.time() - t0:.0f}s)")
    recs = []
    by_i = {}
    for (i, k), h in zip(jobs, hyps):
        by_i.setdefault(i, {})[str(k)] = h
    for i, e in enumerate(ex):
        rec = {"idx": e.idx, "sentence": e.sentence, "gold": [list(t) for t in e.tuples], "gold_count": e.count,
               "betas": betas[i], "hyps": by_i[i], "reviews": {}, "R": [list(v) for v in R[:MAX_VIEWS]]}
        recs.append(rec)
    if not args.no_reviews:
        items = []
        for rec, cont in zip(recs, contents):
            used = {}
            for k, h in rec["hyps"].items():
                for sg in h["segments"]:
                    if sg["t"] is not None:
                        used.setdefault(tuple(sg["t"]), set()).add(tuple(sg["view"]))
            # all anchored views are cached; decide() later excludes the views R[:max K] that the
            # chosen hypotheses already used, exactly as the online path (timed mode) does
            items.append((rec["sentence"], [(t, []) for t in used], cont))
        for s0 in range(0, len(items), args.review_chunk):
            rvs = review_batch(M, g, tok, mv, mode, items[s0:s0 + args.review_chunk], T_grid, args.vocab_only)
            for rec, rv in zip(recs[s0:s0 + args.review_chunk], rvs):
                rec["reviews"] = rv
            log(f"  reviews {min(s0 + args.review_chunk, len(items))}/{len(items)} ({time.time() - t0:.0f}s)")
    if args.split == "dev":
        ins, tg = [], []
        for e in ex:
            k = min(max(e.count, 1), MAX_VIEWS)
            ins.append(generator_input(e.sentence, R[:k]))
            tg.append(tok(linearise_many(e.tuples, R[:k], mode), add_special_tokens=True).input_ids)
        lps = M.token_logprobs(g, tok, ins, tg, T_grid)
        for rec, ids, lp in zip(recs, tg, lps):
            rec["gold_nll"] = M.content_nll(ids, lp, mv)
    out = args.out or os.path.join(seed_dir(args, args.seed), f"cache_{args.gen}_{args.split}.jsonl")
    write_jsonl(out, recs)
    log(f"wrote {out} ({len(recs)} records, {time.time() - t0:.0f}s)")


def timed_mode(args, log):
    """Wall-clock time of the real pipeline on the chosen split, every stage batched across the
    whole split: count belief -> decodes for K(x) -> gate -> view ranking (NLL of the tuple
    under each anchored view) -> top-M anchored re-decodes -> vote. Also reports F1 so that the
    online path can be checked against the offline (cached) result."""
    import torch
    from aura.metrics import exact_match_f1
    M, f, g, tok, mv, R, cats, mode = build(args)
    tuned = json.load(open(args.tuned))
    cal = Calibration(**tuned["calibration"])
    cfg = Config(**tuned["config"])
    ex = load(args, args.split)
    sents = [e.sentence for e in ex]
    contents = contents_for(tok, mode, sents, cats, free_vocab_of(args.dataset))
    sync = (lambda: torch.cuda.synchronize()) if torch.cuda.is_available() else (lambda: None)
    sync()
    t0 = time.time()
    betas = M.count_betas(f, tok, sents, template(R[:MAX_VIEWS]), mv)
    if args.dot:
        jobs = [(i, greedy_count(b)) for i, b in enumerate(betas)]
        hyps = decode_hypotheses(M, g, tok, mv, R, mode, sents, jobs, contents, ["1.0"], args.vocab_only)
        preds = [{tuple(sg["t"]) for sg in h["segments"] if sg["t"]} for h in hyps]
        passes = [2] * len(ex)
    else:
        probs = [count_belief(b) for b in betas]
        Ks = [hypothesis_set(p, cfg.rho, cfg.H) for p in probs]
        jobs = [(i, k) for i, K in enumerate(Ks) for k in K]
        hyps = decode_hypotheses(M, g, tok, mv, R, mode, sents, jobs, contents, [cal.T], args.vocab_only)
        per = [{} for _ in ex]
        for (i, k), h in zip(jobs, hyps):
            d = per[i].setdefault(k, {})
            for sg in h["segments"]:
                if sg["t"]:
                    t = tuple(sg["t"])
                    d[t] = max(d.get(t, -1e9), sg["z"][cal.T])
        preds, passes, flagged = [set() for _ in ex], [1 + len(K) for K in Ks], []
        for i, K in enumerate(Ks):
            mass = sum(probs[i][k - 1] for k in K) or 1.0
            sup, pool = {}, {}
            for k in K:
                for t, z in per[i].get(k, {}).items():
                    sup[t] = sup.get(t, 0.0) + probs[i][k - 1] / mass
                    pool[t] = max(pool.get(t, -1e9), z)
            for t, z in pool.items():
                c = cal.conf(z)
                if sup[t] >= 1 - 1e-9 and c >= cfg.tau:
                    preds[i].add(t)
                else:
                    flagged.append((i, t, c))
        # rank anchored views of every flagged tuple by the NLL of the tuple under that view
        rank_jobs = []
        for n, (i, t, _) in enumerate(flagged):
            mk, val = anchor_of(t, sents[i], mode)
            imp = implicit_elements(t, sents[i], mode)
            used = {tuple(R[min(j, k - 1)]) for k in Ks[i] for j in range(k)}
            vs = anchored_views(mk, imp, mode, exclude=used, implicit_last=True) or \
                anchored_views(mk, imp, mode, exclude=used, implicit_last=False)
            rank_jobs += [(n, v, f"{mk} {val}") for v in vs]
        nll = M.mean_nll(g, tok, [generator_input(sents[flagged[n][0]], [v]) for n, v, _ in rank_jobs],
                         [linearise(flagged[n][1], v, mode) for n, v, _ in rank_jobs]) if rank_jobs else []
        best = {}
        for (n, v, p), x in zip(rank_jobs, nll):
            best.setdefault(n, []).append((x, v, p))
        dec_jobs = [(n, v, p) for n, lst in best.items() for _, v, p in sorted(lst)[: cfg.M]]
        ins = [generator_input(sents[flagged[n][0]], [v]) for n, v, _ in dec_jobs]
        ids = M.constrained_generate(g, tok, ins, [contents[flagged[n][0]] for n, _, _ in dec_jobs], mv,
                                     prefixes=[p for _, _, p in dec_jobs], single=True, max_new_tokens=64,
                                     vocab_only=args.vocab_only) if dec_jobs else []
        lps = M.token_logprobs(g, tok, ins, ids, [cal.T]) if dec_jobs else []
        cands = {}
        for (n, _, _), seq, lp in zip(dec_jobs, ids, lps):
            parsed = parse_output(M.decode_text(tok, seq), mode)
            zs = M.segment_z(seq, lp, mv)
            q = parsed[0] if parsed else None
            cands.setdefault(n, []).append((q, cal.conf(zs[0][cal.T]) if zs else 0.0))
        for n, (i, t, c) in enumerate(flagged):
            cs = cands.get(n, [])
            passes[i] += len(cs)
            kept, _ = vote(t, c, cs, cfg.tau_v)
            if kept is not None:
                preds[i].add(kept)
    sync()
    secs = time.time() - t0
    f1 = exact_match_f1(preds, [e.tuples for e in ex])["f1"]
    mp = sum(passes) / max(1, len(ex))
    name = "DOT" if args.dot else "AURA"
    log(f"TIMED {name} {args.dataset} {args.split}: {secs:.1f}s, {mp:.2f} passes/input, online F1 {f1:.2f}")
    out = os.path.join(seed_dir(args, args.seed), f"timed_{name.lower()}_{args.split}.json")
    json.dump({"seconds": secs, "passes": mp, "f1_online": f1, "n": len(ex)}, open(out, "w"), indent=1)


def main():
    p = base_parser(__doc__)
    p.add_argument("--seed", type=int, default=5)
    p.add_argument("--split", choices=["dev", "test"], default="test")
    p.add_argument("--gen", default="g", help="generator dir: g (AURA) or g_dot (DOT baseline)")
    p.add_argument("--no_reviews", action="store_true")
    p.add_argument("--review_chunk", type=int, default=32, help="sentences per batched re-viewing step")
    p.add_argument("--vocab_only", action="store_true", help="fallback: vocabulary-only constraint")
    p.add_argument("--out", default=None)
    p.add_argument("--timed", action="store_true")
    p.add_argument("--dot", action="store_true", help="timed mode: DOT pipeline")
    p.add_argument("--tuned", default=None)
    args = p.parse_args()
    log = Logger(os.path.join(seed_dir(args, args.seed), "log_infer.txt"))
    (timed_mode if args.timed else cache_mode)(args, log)


if __name__ == "__main__":
    main()
