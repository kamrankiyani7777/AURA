"""Analysis figures from the finished runs (mean over seeds; error bars = std over seeds).

  python scripts_aura/make_figures.py --runs runs_aura --out figures

Reads <runs>/<dataset>/seed*/results.json (+ gate_on_dot.json when present). Every figure is
written as PDF (for LaTeX) and PNG, next to a CSV with the plotted numbers. figures/README.txt
lists how many seeds each dataset contributed; quote figures only once every dataset has 5.

  main_f1          F1 per dataset: DOT, DOT + gate, AURA
  tradeoff         mean F1 vs decoding passes: systems and ablation variants
  ablation         F1 change of each ablation variant relative to full AURA
  implicit         F1 on implicit / explicit test tuples, DOT vs AURA
  reliability      reliability diagrams of the calibrated confidence (Platt), per dataset
  ece              expected calibration error: raw, temperature-scaled, Platt
  sensitivity      test F1 vs gate threshold tau, one line per M (re-views per flagged tuple)
  passes           mean decoding passes for easy vs hard inputs
  flags            precision of accepted vs flagged tuples
  count            count accuracy (DOT greedy) vs coverage of AURA's hypothesis set
"""
import argparse
import csv
import glob
import json
import os
import statistics as st

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

MAIN = ["R15", "R16", "Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]
IMPLICIT_SETS = ["Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]
VARIANTS = [("wo_belief", "w/o count belief"), ("wo_support", "w/o support"),
            ("wo_calibration", "w/o calibration"), ("wo_reviewing", "w/o re-viewing"),
            ("accept_all", "accept all"), ("random_views", "random views"),
            ("wo_implicit_cue", "w/o implicit cue")]

# reference palette (dataviz skill), light mode; one fixed color per system in every figure
DOT, AURA, GATE = "#2a78d6", "#eb6834", "#1baf7a"
RAMP = {250: "#86b6ef", 400: "#3987e5", 450: "#2a78d6", 550: "#1c5cab", 650: "#104281", 700: "#0d366b"}
INK, INK2, MUTED, GRID, AXIS, SURFACE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#fcfcfb"
COL, FULL = 3.3, 6.9  # column / full text width in inches (ACL)

plt.rcParams.update({
    "font.family": "sans-serif", "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "legend.frameon": False,
    "text.color": INK, "axes.labelcolor": INK2, "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.edgecolor": AXIS, "axes.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "axes.grid.axis": "y", "grid.color": GRID, "grid.linewidth": 0.5, "grid.linestyle": "-",
    "axes.axisbelow": True, "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "savefig.dpi": 300, "pdf.fonttype": 42,
})


def get(d, path):
    for k in path.split("."):
        if not isinstance(d, dict) or k not in d:
            return None
        d = d[k]
    return d


class Runs:
    def __init__(self, root):
        self.R, self.G = {}, {}
        for fp in sorted(glob.glob(os.path.join(root, "*", "seed*", "results.json"))):
            r = json.load(open(fp))
            self.R.setdefault(r["dataset"], []).append(r)
            gp = fp.replace("results.json", "gate_on_dot.json")
            if os.path.exists(gp):
                self.G.setdefault(r["dataset"], []).append(json.load(open(gp)))
        self.ds = [d for d in MAIN if d in self.R]

    def ms(self, ds, path, src="R"):
        v = [get(r, path) for r in getattr(self, src).get(ds, [])]
        v = [x for x in v if x is not None]
        if not v:
            return None, None
        return st.mean(v), (st.stdev(v) if len(v) > 1 else 0.0)

    def m(self, ds, path, src="R"):
        return self.ms(ds, path, src)[0]


def save(fig, out, name, header, rows):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(out, f"{name}.{ext}"))
    plt.close(fig)
    with open(os.path.join(out, f"{name}.csv"), "w", newline="") as fp:
        w = csv.writer(fp)
        w.writerow(header)
        for r in rows:
            w.writerow([f"{x:.4f}" if isinstance(x, float) else ("" if x is None else x) for x in r])
    print(f"  {name}")


SHORT = {"Clothing": "Cloth."}  # as in the paper's tables


def short(ds):
    return [SHORT.get(d, d) for d in ds]


def declutter(fig, ax, texts, step=6.0):
    """Place each annotation at the first nearby offset (right of its point first, then left) whose text
    box overlaps no label placed before it and no marker; leader lines show which point it belongs to."""
    from matplotlib.text import Text
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    marks = [ax.transData.transform(t.xy) for t in texts]
    placed = []
    for t in sorted(texts, key=lambda t: -t.xy[1]):
        for dx, ha in ((5, "left"), (-5, "right")):
            ok = False
            for k in (0, -1, 1, -2, 2, -3, 3):
                t.set_position((dx, -2 + k * step))
                t.set_ha(ha)
                bb = Text.get_window_extent(t, r).expanded(1.04, 1.15)   # the text only, not its leader line
                if not any(bb.overlaps(p) for p in placed) and \
                        not any(bb.x0 - 3 <= mx <= bb.x1 + 3 and bb.y0 - 3 <= my <= bb.y1 + 3 for mx, my in marks):
                    ok = True
                    break
            if ok:
                break
        placed.append(Text.get_window_extent(t, r))


def grouped_bars(ax, groups, series, width=0.8):
    """series: [(label, color, means, stds)]; a surface-colored edge leaves a gap between bars."""
    n = len(series)
    w = width / n
    for i, (label, color, means, stds) in enumerate(series):
        xs = [g + (i - (n - 1) / 2) * w for g in range(len(groups))]
        ok = [(x, m, s) for x, m, s in zip(xs, means, stds) if m is not None]
        if not ok:
            continue
        x, m, s = zip(*ok)
        ax.bar(x, m, w, color=color, label=label, edgecolor="white", linewidth=1.0,
               yerr=None if None in s else s,  # pooled numbers have no spread to show
               error_kw={"elinewidth": 0.6, "ecolor": INK2, "capsize": 1.5, "capthick": 0.6})
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels(short(groups))
    ax.tick_params(axis="x", length=0)


def fig_main_f1(R, out):
    gate = any(R.G.get(d) for d in R.ds)
    series = [("DOT", DOT, [R.ms(d, "dot.f1")[0] for d in R.ds], [R.ms(d, "dot.f1")[1] for d in R.ds])]
    if gate:
        series.append(("DOT + gate", GATE, [R.ms(d, "dot_gate.f1", "G")[0] for d in R.ds],
                       [R.ms(d, "dot_gate.f1", "G")[1] for d in R.ds]))
    series.append(("AURA", AURA, [R.ms(d, "aura.f1")[0] for d in R.ds], [R.ms(d, "aura.f1")[1] for d in R.ds]))
    fig, ax = plt.subplots(figsize=(FULL, 2.2))
    grouped_bars(ax, R.ds, series)
    lo = min(m for _, _, ms_, _ in series for m in ms_ if m is not None)
    ax.set_ylim(max(0, lo - 12), None)
    ax.set_ylabel("F1 (%)")
    ax.legend(ncol=len(series), loc="upper left", bbox_to_anchor=(0, 1.15))
    rows = [[d] + [x for _, _, ms_, ss in series for x in (ms_[i], ss[i])] for i, d in enumerate(R.ds)]
    save(fig, out, "main_f1", ["dataset"] + [f"{s[0]} {k}" for s in series for k in ("mean", "std")], rows)


def fig_tradeoff(R, out):
    """Mean over datasets of F1 and passes; only datasets that have every plotted system."""
    pts = [("DOT", "dot.f1", None, "R", DOT, True), ("AURA", "aura.f1", "aura.passes", "R", AURA, True)]
    if any(R.G.get(d) for d in R.ds):
        pts += [("DOT + gate", "dot_gate.f1", "dot_gate.passes", "G", GATE, True),
                ("DOT + belief + gate", "dot_belief_gate.f1", "dot_belief_gate.passes", "G", GATE, False)]
    pts += [(lab, f"variants.{v}.f1", f"variants.{v}.passes", "R", MUTED, False) for v, lab in VARIANTS]
    ds = [d for d in R.ds if all(R.m(d, f, s) is not None for _, f, _, s, _, _ in pts)]
    if not ds:
        return
    fig, ax = plt.subplots(figsize=(COL, 2.6))
    rows, texts = [], []
    for lab, f, p, src, color, solid in pts:
        y = st.mean(R.m(d, f, src) for d in ds)
        x = 2.0 if p is None else st.mean(R.m(d, p, src) for d in ds)
        ax.scatter([x], [y], s=28, color=color if solid else "white", edgecolor=color, linewidth=1.2, zorder=3)
        texts.append(ax.annotate(lab, (x, y), xytext=(5, -2), textcoords="offset points", fontsize=6.5,
                                 va="center", color=INK if solid else INK2,
                                 arrowprops={"arrowstyle": "-", "color": AXIS, "lw": 0.5, "shrinkA": 1, "shrinkB": 3}))
        rows.append([lab, x, y])
    ax.set_xlabel(f"decoding passes per input (mean over {len(ds)} datasets)")
    ax.set_ylabel("F1 (%)")
    ax.grid(axis="x")
    ax.set_xlim(right=ax.get_xlim()[1] + 0.25)  # room for labels of the right-most points
    declutter(fig, ax, texts)
    save(fig, out, "tradeoff", ["system", "passes", "f1"], rows)


def fig_ablation(R, out):
    rows = []
    for v, lab in VARIANTS:
        diffs = [R.m(d, f"variants.{v}.f1") - R.m(d, "aura.f1") for d in R.ds
                 if R.m(d, f"variants.{v}.f1") is not None and R.m(d, "aura.f1") is not None]
        if diffs:
            rows.append([lab, st.mean(diffs), min(diffs), max(diffs)])
    if not rows:
        return
    fig, ax = plt.subplots(figsize=(COL, 2.2))
    y = list(range(len(rows)))[::-1]
    ax.barh(y, [r[1] for r in rows], 0.6, color=RAMP[450], edgecolor="white", linewidth=1.0)
    ax.hlines(y, [r[2] for r in rows], [r[3] for r in rows], color=INK2, linewidth=0.6)
    ax.axvline(0, color=AXIS, linewidth=0.8)
    for yi, r in zip(y, rows):  # values in a column right of the plot, clear of bars and range lines
        ax.text(1.02, yi, f"{r[1]:+.2f}", transform=ax.get_yaxis_transform(), va="center", fontsize=6.5,
                color=INK2)
    ax.set_yticks(y)
    ax.set_yticklabels([r[0] for r in rows])
    ax.tick_params(axis="y", length=0)
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x")
    ax.set_xlabel(f"F1 change vs full AURA\n(mean over {len(R.ds)} datasets; line = min–max)")
    save(fig, out, "ablation", ["variant", "mean_delta_f1", "min", "max"], rows)


def fig_implicit(R, out):
    ds = [d for d in IMPLICIT_SETS if d in R.R]
    if not ds:
        return
    fig, axes = plt.subplots(1, 2, figsize=(FULL, 2.0), sharey=True)
    rows = []
    for ax, part in zip(axes, ("implicit", "explicit")):
        series = [(name, c, [R.ms(d, f"{k}.{part}.f1")[0] for d in ds], [R.ms(d, f"{k}.{part}.f1")[1] for d in ds])
                  for name, k, c in (("DOT", "dot", DOT), ("AURA", "aura", AURA))]
        grouped_bars(ax, ds, series)
        ax.set_title(f"{part.capitalize()} tuples", loc="left", color=INK)
        for i, d in enumerate(ds):
            rows.append([d, part] + [x for _, _, ms_, ss in series for x in (ms_[i], ss[i])])
    axes[0].set_ylabel("F1 (%)")
    axes[0].legend(ncol=2, loc="upper left", bbox_to_anchor=(0, 1.25))
    save(fig, out, "implicit", ["dataset", "subset", "DOT mean", "DOT std", "AURA mean", "AURA std"], rows)


def fig_reliability(R, out):
    ds = [d for d in R.ds if any(get(r, "calibration_eval.bins_platt") for r in R.R[d])]
    if not ds:
        return
    cols = 3
    nrows = (len(ds) + cols - 1) // cols
    fig, axes = plt.subplots(nrows, cols, figsize=(FULL, 1.9 * nrows), sharex=True, sharey=True, squeeze=False)
    rows = []
    for ax, d in zip(axes.flat, ds):
        pooled = {}
        for r in R.R[d]:
            for b in get(r, "calibration_eval.bins_platt") or []:
                p = pooled.setdefault(b["bin"], [0, 0.0, 0.0])
                p[0] += b["n"]
                p[1] += b["conf"] * b["n"]
                p[2] += b["acc"] * b["n"]
        bins = sorted(pooled)
        conf = [pooled[b][1] / pooled[b][0] for b in bins]
        acc = [pooled[b][2] / pooled[b][0] for b in bins]
        ax.plot([0, 1], [0, 1], color=AXIS, linewidth=0.8)
        ax.plot(conf, acc, color=DOT, linewidth=1.5, marker="o", markersize=3.5,
                markeredgecolor="white", markeredgewidth=0.8)
        ece_m = R.m(d, "calibration_eval.ece_platt")
        ax.set_title(f"{d}   ECE {ece_m:.1f}" if ece_m is not None else d, loc="left", color=INK)
        ax.grid(axis="x")
        rows += [[d, b, pooled[b][0], c, a] for b, c, a in zip(bins, conf, acc)]
    for ax in axes.flat[len(ds):]:
        ax.set_visible(False)
    for ax in axes[-1]:
        ax.set_xlabel("calibrated confidence")
    for ax in axes[:, 0]:
        ax.set_ylabel("accuracy")
    save(fig, out, "reliability", ["dataset", "bin", "n", "mean_confidence", "accuracy"], rows)


def fig_ece(R, out):
    keys = [("raw", "calibration_eval.ece_raw", RAMP[250]), ("temperature", "calibration_eval.ece_temp", RAMP[450]),
            ("Platt", "calibration_eval.ece_platt", RAMP[650])]
    series = [(lab, c, [R.ms(d, k)[0] for d in R.ds], [R.ms(d, k)[1] for d in R.ds]) for lab, k, c in keys]
    fig, ax = plt.subplots(figsize=(FULL, 2.0))
    grouped_bars(ax, R.ds, series)
    ax.set_ylabel("ECE (%, lower is better)")
    ax.legend(ncol=3, loc="upper left", bbox_to_anchor=(0, 1.15))
    rows = [[d] + [x for _, _, ms_, ss in series for x in (ms_[i], ss[i])] for i, d in enumerate(R.ds)]
    save(fig, out, "ece", ["dataset"] + [f"{s[0]} {k}" for s in series for k in ("mean", "std")], rows)


def fig_sensitivity(R, out):
    ds = [d for d in R.ds if any(r.get("sensitivity") for r in R.R[d])]
    if not ds:
        return
    Ms = sorted({e["M"] for d in ds for r in R.R[d] for e in r.get("sensitivity", [])})
    shades = [RAMP[k] for k in (250, 400, 550, 700)][-len(Ms):] if len(Ms) <= 4 else None
    cols = 3
    nrows = (len(ds) + cols - 1) // cols
    fig, axes = plt.subplots(nrows, cols, figsize=(FULL, 1.9 * nrows), sharex=True, squeeze=False)
    rows = []
    for ax, d in zip(axes.flat, ds):
        cell = {}
        for r in R.R[d]:
            for e in r.get("sensitivity", []):
                cell.setdefault((e["tau"], e["M"]), []).append(e["f1"])
        taus = sorted({t for t, _ in cell})
        for M, color in zip(Ms, shades):
            ys = [st.mean(cell[(t, M)]) if (t, M) in cell else None for t in taus]
            ax.plot([min(t, 1.0) for t in taus], ys, color=color, linewidth=1.5, label=f"M = {M}")
            rows += [[d, t, M, y] for t, y in zip(taus, ys)]
        dot = R.m(d, "dot.f1")
        if dot is not None:
            ax.axhline(dot, color=MUTED, linewidth=0.8)
            ax.annotate("DOT", (0.98, dot), xytext=(0, 2), textcoords="offset points", fontsize=6, color=MUTED,
                        ha="right", va="bottom", xycoords=("axes fraction", "data"))
        ax.set_title(SHORT.get(d, d), loc="left", color=INK)
        ax.grid(axis="x")
    for ax in axes.flat[len(ds):]:
        ax.set_visible(False)
    fig.supxlabel("gate threshold τ (1.0 = every tuple re-viewed)", fontsize=8, color=INK2)
    for ax in axes[:, 0]:
        ax.set_ylabel("F1 (%)")
    axes.flat[0].legend(ncol=len(Ms), loc="lower left", bbox_to_anchor=(0, 1.12))
    save(fig, out, "sensitivity", ["dataset", "tau", "M", "f1"], rows)


def fig_passes(R, out):
    series = [("easy (1 tuple, explicit)", RAMP[250], [R.ms(d, "passes_by_difficulty.easy_mean")[0] for d in R.ds],
               [R.ms(d, "passes_by_difficulty.easy_mean")[1] for d in R.ds]),
              ("hard", RAMP[650], [R.ms(d, "passes_by_difficulty.hard_mean")[0] for d in R.ds],
               [R.ms(d, "passes_by_difficulty.hard_mean")[1] for d in R.ds])]
    fig, ax = plt.subplots(figsize=(FULL, 2.0))
    grouped_bars(ax, R.ds, series, width=0.6)
    ax.axhline(2, color=DOT, linewidth=1.0, label="DOT (always 2)")
    ax.set_ylabel("AURA passes per input")
    ax.legend(ncol=3, loc="upper left", bbox_to_anchor=(0, 1.15))
    rows = [[d] + [x for _, _, ms_, ss in series for x in (ms_[i], ss[i])] for i, d in enumerate(R.ds)]
    save(fig, out, "passes", ["dataset", "easy mean", "easy std", "hard mean", "hard std"], rows)


def fig_flags(R, out):
    series = [("accepted by the gate", RAMP[650], [R.ms(d, "flags.precision_accepted")[0] for d in R.ds],
               [R.ms(d, "flags.precision_accepted")[1] for d in R.ds]),
              ("flagged", RAMP[250], [R.ms(d, "flags.precision_flagged")[0] for d in R.ds],
               [R.ms(d, "flags.precision_flagged")[1] for d in R.ds])]
    fig, ax = plt.subplots(figsize=(FULL, 2.0))
    grouped_bars(ax, R.ds, series, width=0.6)
    ax.set_ylabel("precision of tuples (%)")
    ax.legend(ncol=2, loc="upper left", bbox_to_anchor=(0, 1.15))
    rows = [[d] + [x for _, _, ms_, ss in series for x in (ms_[i], ss[i])] + [R.m(d, "aura.flag_rate")]
            for i, d in enumerate(R.ds)]
    save(fig, out, "flags", ["dataset", "accepted mean", "accepted std", "flagged mean", "flagged std",
                             "flag_rate"], rows)


def fig_count(R, out):
    series = [("DOT greedy count accuracy", DOT, [R.ms(d, "count.greedy_acc")[0] for d in R.ds],
               [R.ms(d, "count.greedy_acc")[1] for d in R.ds]),
              ("AURA hypothesis-set coverage", AURA, [R.ms(d, "count.coverage")[0] for d in R.ds],
               [R.ms(d, "count.coverage")[1] for d in R.ds])]
    fig, ax = plt.subplots(figsize=(FULL, 2.0))
    grouped_bars(ax, R.ds, series, width=0.6)
    ax.set_ylim(50, 100)
    ax.set_ylabel("% of test sentences")
    ax.legend(ncol=2, loc="upper left", bbox_to_anchor=(0, 1.15))
    rows = [[d] + [x for _, _, ms_, ss in series for x in (ms_[i], ss[i])] + [R.m(d, "count.mean_|K|")]
            for i, d in enumerate(R.ds)]
    save(fig, out, "count", ["dataset", "greedy acc mean", "greedy acc std", "coverage mean", "coverage std",
                             "mean |K|"], rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--out", default="figures")
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    R = Runs(args.runs)
    if not R.ds:
        raise SystemExit("no results found")
    seeds = {d: sorted(r["seed"] for r in R.R[d]) for d in R.ds}
    with open(os.path.join(args.out, "README.txt"), "w") as fp:
        fp.write("Seeds per dataset in these figures (final figures need 5 each):\n")
        for d in R.ds:
            fp.write(f"  {d:9s} n={len(seeds[d])}  seeds {seeds[d]}  gate_on_dot n={len(R.G.get(d, []))}\n")
    print("seeds per dataset:", {d: len(s) for d, s in seeds.items()})
    for f in (fig_main_f1, fig_tradeoff, fig_ablation, fig_implicit, fig_reliability, fig_ece,
              fig_sensitivity, fig_passes, fig_flags, fig_count):
        f(R, args.out)
    print(f"wrote {args.out}/")


if __name__ == "__main__":
    main()
