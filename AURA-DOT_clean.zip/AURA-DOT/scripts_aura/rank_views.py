"""Step 1: dataset-level view ranking R from the training set (no test labels involved).

Scores every view with a *pre-trained* T5 (mean per-token NLL of all gold tuples written in
that view), as in MvP's dataset-level ranking. Run once per dataset.
"""
import os

from common import Logger, base_parser, ds_dir, load, mode_of
from aura.views import rank_views_dataset_level, save_ranking


def main():
    p = base_parser(__doc__)
    p.add_argument("--model", default="t5-base")
    p.add_argument("--max_examples", type=int, default=2000)
    args = p.parse_args()
    out = os.path.join(ds_dir(args), "R.json")
    log = Logger(os.path.join(ds_dir(args), "log_rank.txt"))
    from aura.model import load as load_model, mean_nll
    model, tok = load_model(args.model)
    train = load(args, "train")
    R = rank_views_dataset_level(train, mode_of(args.dataset),
                                 lambda xs, ys: mean_nll(model, tok, xs, ys),
                                 max_examples=args.max_examples)
    save_ranking(out, R)
    log(f"{args.dataset}: R = {[' '.join(v) for v in R]}")


if __name__ == "__main__":
    main()
