"""Significance across datasets (Dror et al., TACL 2017): sign test and Wilcoxon signed-rank on the
per-dataset mean F1 of AURA vs DOT (and any other pair), from aggregate.py's summary.json.

  python scripts_aura/cross_dataset_tests.py --summary runs_aura/summary.json
"""
import argparse
import json
from math import comb

from scipy.stats import wilcoxon

MAIN = ["R15", "R16", "Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]


def sign_test(diffs):
    """Exact two-sided sign test; ties dropped."""
    d = [x for x in diffs if x != 0]
    n, k = len(d), sum(x > 0 for x in d)
    tail = sum(comb(n, i) for i in range(max(k, n - k), n + 1)) / 2 ** n
    return min(1.0, 2 * tail), k, n


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--summary", default="runs_aura/summary.json")
    args = p.parse_args()
    S = json.load(open(args.summary))
    ds = [d for d in MAIN if d in S]
    pairs = [("aura.f1", "dot.f1", "AURA vs DOT"), ("aura.f1", "g_with_dot_rule.f1", "AURA vs AURA-gen + DOT rule")]
    for a, b, name in pairs:
        diffs = [S[d][a]["mean"] - S[d][b]["mean"] for d in ds]
        ps, k, n = sign_test(diffs)
        w = wilcoxon(diffs, alternative="two-sided", method="exact")
        print(f"{name}: mean diff {sum(diffs) / len(diffs):+.2f} over {len(ds)} datasets, "
              f"{k}/{n} positive | sign test p={ps:.4f} | Wilcoxon W={w.statistic:.1f} p={w.pvalue:.4f}")
        print("   per dataset: " + ", ".join(f"{d} {x:+.2f}" for d, x in zip(ds, diffs)))


if __name__ == "__main__":
    main()
