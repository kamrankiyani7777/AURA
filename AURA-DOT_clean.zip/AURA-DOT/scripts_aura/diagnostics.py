"""Diagnostic figures from the per-sentence test predictions (all datasets x seeds).

  python scripts_aura/diagnostics.py --runs runs_aura --out figures

Recomputes DOT (g_dot cache, greedy count) and AURA (g cache, tuned.json) predictions for every test
sentence of every finished seed; nothing is re-tuned. Pooled numbers are micro-averaged over all
sentences of all seeds unless a caption says otherwise. Figures (PDF + PNG + CSV twin):

  pr_shift         per-dataset arrow from DOT's (recall, precision) to AURA's
  count_errors     gold vs predicted count heatmap + F1 for under-, exactly and over-counted sentences
  error_taxonomy   wrong predictions by type, per 100 gold tuples, DOT vs AURA, per benchmark family
  review_outcomes  flagged tuples sent to re-viewing: correct/incorrect x kept/dropped/changed
  confidence       calibrated confidence of correct vs incorrect tuples + AUROC per dataset
  gain_buckets     AURA - DOT F1 by number of gold tuples, implicit/explicit sentences, sentence length
  paired_seeds     AURA - DOT F1 for each of the dataset x seed runs
"""
import argparse
import glob
import json
import os
import statistics as st

import numpy as np

import make_figures as MF  # style, colors, save(), short()
from common import read_jsonl
from aura.core import Calibration, Config, greedy_count, run
from aura.data import MAX_VIEWS, has_implicit

plt = MF.plt
MAIN = MF.MAIN
FAMILY = {"ASQP": ["R15", "R16"], "ACOS": ["Lap", "Rest"], "MEMD": ["M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]}


# ----------------------------------------------------------------------------- data
def load_runs(root):
    """One entry per finished (dataset, seed): sentences with gold, DOT and AURA outputs."""
    runs = []
    for ds in MAIN:
        for sd in sorted(glob.glob(os.path.join(root, ds, "seed*"))):
            if not os.path.exists(os.path.join(sd, "results.json")):
                continue
            tuned = json.load(open(os.path.join(sd, "tuned.json")))
            cal = Calibration(**tuned["calibration"])
            test = read_jsonl(os.path.join(sd, "cache_g_test.jsonl"))
            dtest = read_jsonl(os.path.join(sd, "cache_g_dot_test.jsonl"))
            aura = run(test, Config(**tuned["config"]), cal)
            dot = run(dtest, Config(mode="dot"), Calibration())
            mode = "quad"
            sents = []
            for r, d, a in zip(test, dot, aura):
                gold = [tuple(g) for g in r["gold"]]
                sents.append({"sentence": r["sentence"], "gold": gold, "gold_k": min(max(r["gold_count"], 1), MAX_VIEWS),
                              "greedy_k": greedy_count(r["betas"]), "dot": d["pred"], "aura": a["pred"],
                              "info": a["info"],
                              "implicit": any(has_implicit(g, r["sentence"], mode) for g in gold)})
            runs.append({"dataset": ds, "seed": int(sd.rsplit("seed", 1)[1]), "sents": sents,
                         "results": json.load(open(os.path.join(sd, "results.json")))})
        print(f"  loaded {ds}", flush=True)
    return runs


def prf(pairs):
    """pairs: iterable of (pred set, gold list) -> micro P, R, F1 (%)"""
    tp = npred = ngold = 0
    for p, g in pairs:
        gs = set(g)
        tp += len(p & gs)
        npred += len(p)
        ngold += len(gs)
    pr = tp / npred if npred else 0.0
    rc = tp / ngold if ngold else 0.0
    return 100 * pr, 100 * rc, 100 * (2 * pr * rc / (pr + rc) if pr + rc else 0.0)


# ----------------------------------------------------------------------------- 1 precision-recall shift
def fig_pr_shift(runs, out):
    rows = []
    for ds in MAIN:
        R = [r["results"] for r in runs if r["dataset"] == ds]
        if not R:
            continue
        m = lambda sysname, k: st.mean(x[sysname][k] for x in R)
        rows.append([ds, m("dot", "recall"), m("dot", "precision"), m("aura", "recall"), m("aura", "precision")])
    fig, ax = plt.subplots(figsize=(MF.COL, 3.0))
    labels = []
    for ds, rd, pd, ra, pa in rows:
        ax.annotate("", xy=(ra, pa), xytext=(rd, pd),
                    arrowprops={"arrowstyle": "-|>", "color": MF.INK2, "lw": 0.8, "shrinkA": 3, "shrinkB": 3,
                                "mutation_scale": 7})
        ax.scatter([rd], [pd], s=16, color=MF.DOT, zorder=3)
        ax.scatter([ra], [pa], s=16, color=MF.AURA, zorder=3)
        labels.append(ax.annotate(MF.SHORT.get(ds, ds), (ra, pa), xytext=(5, -2), textcoords="offset points",
                                  fontsize=6, va="center", color=MF.INK2,
                                  arrowprops={"arrowstyle": "-", "color": MF.AXIS, "lw": 0.5, "shrinkA": 1,
                                              "shrinkB": 3}))
    lims = [min(min(r[1], r[2], r[3], r[4]) for r in rows) - 3, max(max(r[1], r[2], r[3], r[4]) for r in rows) + 3]
    ax.plot(lims, lims, color=MF.GRID, linewidth=0.8, zorder=0)
    ax.set_xlim(lims)
    ax.set_ylim(lims)
    ax.set_xlabel("recall (%)")
    ax.set_ylabel("precision (%)")
    ax.grid(axis="x")
    ax.scatter([], [], s=16, color=MF.DOT, label="DOT")
    ax.scatter([], [], s=16, color=MF.AURA, label="AURA")
    ax.legend(loc="upper left", bbox_to_anchor=(0, 1.12), ncol=2)
    MF.declutter(fig, ax, labels)
    MF.save(fig, out, "pr_shift", ["dataset", "dot_recall", "dot_precision", "aura_recall", "aura_precision"], rows)


# ----------------------------------------------------------------------------- 2 count errors
def fig_count_errors(runs, out):
    conf = np.zeros((MAX_VIEWS, MAX_VIEWS), dtype=int)
    buckets = {b: {"dot": [], "aura": []} for b in ("under", "exact", "over")}
    for r in runs:
        for s in r["sents"]:
            conf[s["gold_k"] - 1, s["greedy_k"] - 1] += 1
            b = "under" if s["greedy_k"] < s["gold_k"] else "over" if s["greedy_k"] > s["gold_k"] else "exact"
            buckets[b]["dot"].append((s["dot"], s["gold"]))
            buckets[b]["aura"].append((s["aura"], s["gold"]))
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(MF.FULL, 2.5), gridspec_kw={"width_ratios": [1, 1.3]})
    rowpct = conf / np.maximum(conf.sum(1, keepdims=True), 1) * 100
    cmap = matplotlib_cmap()
    ax1.imshow(rowpct, cmap=cmap, vmin=0, vmax=100)
    for i in range(MAX_VIEWS):
        for j in range(MAX_VIEWS):
            if conf[i, j]:
                ax1.text(j, i, f"{rowpct[i, j]:.0f}", ha="center", va="center", fontsize=6,
                         color="white" if rowpct[i, j] > 55 else MF.INK)
    ax1.set_xticks(range(MAX_VIEWS))
    ax1.set_xticklabels(range(1, MAX_VIEWS + 1))
    ax1.set_yticks(range(MAX_VIEWS))
    ax1.set_yticklabels([f"{k}  (n={conf[k - 1].sum()})" for k in range(1, MAX_VIEWS + 1)])
    ax1.set_xlabel("predicted count (greedy)")
    ax1.set_ylabel("gold count")
    ax1.grid(False)
    ax1.set_title("row-normalised %", loc="left", color=MF.INK)
    names = ["under", "exact", "over"]
    n = {b: len(buckets[b]["dot"]) for b in names}
    series = [(sysname, color, [prf(buckets[b][key])[2] for b in names], [None] * 3)
              for sysname, key, color in (("DOT", "dot", MF.DOT), ("AURA", "aura", MF.AURA))]
    MF.grouped_bars(ax2, [f"{b}-counted\n({100 * n[b] / sum(n.values()):.0f}% of sentences)" for b in names],
                    series, width=0.6)
    ax2.set_xticklabels([f"{b}-counted\n({100 * n[b] / sum(n.values()):.0f}% of sentences)" for b in names])
    ax2.set_ylabel("F1 (%)")
    ax2.legend(ncol=2, loc="upper right", bbox_to_anchor=(1, 1.15))
    rows = [["confusion", i + 1, j + 1, int(conf[i, j])] for i in range(MAX_VIEWS) for j in range(MAX_VIEWS)]
    rows += [["f1_by_count_error", b, n[b], f"DOT {prf(buckets[b]['dot'])[2]:.2f} AURA {prf(buckets[b]['aura'])[2]:.2f}"]
             for b in names]
    MF.save(fig, out, "count_errors", ["part", "gold_or_bucket", "pred_or_n", "value"], rows)


def matplotlib_cmap():
    from matplotlib.colors import LinearSegmentedColormap
    return LinearSegmentedColormap.from_list("seq", ["#ffffff", MF.RAMP[250], MF.RAMP[450], MF.RAMP[700]])


# ----------------------------------------------------------------------------- 3 error taxonomy
TYPES = ["spurious tuple", "missed tuple", "aspect span", "category", "sentiment", "opinion span",
         "implicit/explicit"]


def classify(pred, gold):
    """Match exact hits, then pair each remaining prediction with a remaining gold tuple that differs in
    exactly one element (that element names the error); everything left is spurious or missed."""
    pred, gold = set(pred), list(gold)
    counts = dict.fromkeys(TYPES, 0)
    rest_g = [g for g in gold if g not in pred]
    rest_p = [p for p in pred if p not in set(gold)]
    for p in sorted(rest_p):
        for g in rest_g:
            diff = [i for i in range(4) if p[i] != g[i]]
            if len(diff) == 1:
                i = diff[0]
                if i in (0, 3) and "null" in (p[i], g[i]):
                    counts["implicit/explicit"] += 1
                else:
                    counts[["aspect span", "category", "sentiment", "opinion span"][i]] += 1
                rest_g.remove(g)
                break
        else:
            counts["spurious tuple"] += 1
    counts["missed tuple"] += len(rest_g)
    return counts


def fig_error_taxonomy(runs, out):
    fams = list(FAMILY)
    tot = {f: {s: dict.fromkeys(TYPES, 0) for s in ("dot", "aura")} for f in fams}
    ngold = dict.fromkeys(fams, 0)
    for r in runs:
        f = next(k for k, v in FAMILY.items() if r["dataset"] in v)
        for s in r["sents"]:
            ngold[f] += len(set(s["gold"]))
            for sysname in ("dot", "aura"):
                for t, c in classify(s[sysname], s["gold"]).items():
                    tot[f][sysname][t] += c
    fig, axes = plt.subplots(1, 3, figsize=(MF.FULL, 2.6), sharey=True)
    rows = []
    y = np.arange(len(TYPES))[::-1]
    for ax, f in zip(axes, fams):
        for k, (sysname, color) in enumerate((("dot", MF.DOT), ("aura", MF.AURA))):
            v = [100 * tot[f][sysname][t] / max(ngold[f], 1) for t in TYPES]
            ax.barh(y + (0.2 if k == 0 else -0.2), v, 0.38, color=color, edgecolor="white", linewidth=1.0,
                    label="DOT" if k == 0 else "AURA")
            rows += [[f, sysname, t, x] for t, x in zip(TYPES, v)]
        ax.set_title(f, loc="left", color=MF.INK)
        ax.grid(axis="y", visible=False)
        ax.grid(axis="x")
        ax.set_xlabel("per 100 gold tuples")
    axes[0].set_yticks(y)
    axes[0].set_yticklabels(TYPES)
    axes[0].tick_params(axis="y", length=0)
    axes[0].legend(ncol=2, loc="upper left", bbox_to_anchor=(0, 1.22))
    MF.save(fig, out, "error_taxonomy", ["family", "system", "error_type", "per_100_gold"], rows)


# ----------------------------------------------------------------------------- 4 re-viewing outcomes
def fig_review_outcomes(runs, out):
    cells = {(c, o): 0 for c in ("correct", "incorrect") for o in ("kept", "dropped", "changed")}
    fixed = 0
    for r in runs:
        for s in r["sents"]:
            gs = set(s["gold"])
            for e in s["info"]:
                if e["action"] != "review":
                    continue
                c = "correct" if e["t"] in gs else "incorrect"
                o = "kept" if e["kept"] == e["t"] else "dropped" if e["kept"] is None else "changed"
                cells[(c, o)] += 1
                fixed += int(o == "changed" and c == "incorrect" and e["kept"] in gs)
    fig, ax = plt.subplots(figsize=(MF.COL, 1.6))
    mat = np.array([[cells[(c, o)] for o in ("kept", "dropped", "changed")] for c in ("correct", "incorrect")])
    pct = mat / np.maximum(mat.sum(1, keepdims=True), 1) * 100
    ax.imshow(pct, cmap=matplotlib_cmap(), vmin=0, vmax=100, aspect="auto")
    for i in range(2):
        for j in range(3):
            ax.text(j, i, f"{pct[i, j]:.0f}%\n(n={mat[i, j]})", ha="center", va="center", fontsize=6.5,
                    color="white" if pct[i, j] > 55 else MF.INK)
    ax.set_xticks(range(3))
    ax.set_xticklabels(["kept", "dropped", "changed"])
    ax.set_yticks(range(2))
    ax.set_yticklabels(["flagged tuple\ncorrect", "flagged tuple\nincorrect"])
    ax.grid(False)
    ax.set_title(f"re-viewed tuples, all runs  (changed into a correct tuple: {fixed})", loc="left", color=MF.INK,
                 fontsize=7)
    rows = [[c, o, cells[(c, o)]] for c in ("correct", "incorrect") for o in ("kept", "dropped", "changed")]
    rows.append(["incorrect", "changed into correct", fixed])
    MF.save(fig, out, "review_outcomes", ["flagged_tuple", "outcome", "count"], rows)


# ----------------------------------------------------------------------------- 5 confidence separability
def auroc(pos, neg):
    """Mann-Whitney AUROC (ties count half)."""
    if not pos or not neg:
        return None
    x = np.concatenate([pos, neg])
    order = x.argsort(kind="mergesort")
    ranks = np.empty(len(x))
    ranks[order] = np.arange(1, len(x) + 1)
    for v in np.unique(x):  # average ranks for ties
        m = x == v
        ranks[m] = ranks[m].mean()
    return (ranks[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))


def fig_confidence(runs, out):
    per = {}
    for r in runs:
        d = per.setdefault(r["dataset"], ([], []))
        for s in r["sents"]:
            gs = set(s["gold"])
            for e in s["info"]:
                (d[0] if e["t"] in gs else d[1]).append(e["c"])
    pos_all = [c for d in per.values() for c in d[0]]
    neg_all = [c for d in per.values() for c in d[1]]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(MF.FULL, 2.2), gridspec_kw={"width_ratios": [1, 1.4]})
    bins = np.linspace(0, 1, 26)
    ax1.hist(neg_all, bins=bins, color=MF.RAMP[250], label="incorrect tuples", density=True)
    ax1.hist(pos_all, bins=bins, histtype="step", color=MF.RAMP[700], linewidth=1.5, label="correct tuples",
             density=True)
    ax1.set_xlabel("calibrated confidence")
    ax1.set_ylabel("density")
    ax1.legend(loc="lower left", bbox_to_anchor=(0, 1.08), ncol=2)
    ax1.set_title(f"all datasets  (AUROC {auroc(pos_all, neg_all):.3f})", loc="left", color=MF.INK)
    ds = [d for d in MAIN if d in per]
    au = [auroc(*per[d]) for d in ds]
    ax2.bar(range(len(ds)), au, 0.6, color=MF.RAMP[450], edgecolor="white", linewidth=1.0)
    for i, a in enumerate(au):
        ax2.text(i, a + 0.005, f"{a:.2f}", ha="center", va="bottom", fontsize=6.5, color=MF.INK2)
    ax2.axhline(0.5, color=MF.MUTED, linewidth=0.8)
    ax2.set_xticks(range(len(ds)))
    ax2.set_xticklabels(MF.short(ds), rotation=35, ha="right", rotation_mode="anchor")
    ax2.tick_params(axis="x", length=0)
    ax2.set_ylim(0.5, 1.0)
    ax2.set_ylabel("AUROC (correct vs incorrect)")
    rows = [[d, a, len(per[d][0]), len(per[d][1])] for d, a in zip(ds, au)]
    MF.save(fig, out, "confidence", ["dataset", "auroc", "n_correct", "n_incorrect"], rows)


# ----------------------------------------------------------------------------- 6 gain by difficulty
def fig_gain_buckets(runs, out):
    lens = sorted(len(s["sentence"].split()) for r in runs for s in r["sents"])
    q1, q2 = lens[len(lens) // 3], lens[2 * len(lens) // 3]
    groups = {
        "gold tuples": [("1", lambda s: s["gold_k"] == 1), ("2", lambda s: s["gold_k"] == 2),
                        ("3", lambda s: s["gold_k"] == 3), ("4+", lambda s: s["gold_k"] >= 4)],
        "implicit element": [("none", lambda s: not s["implicit"]), ("some", lambda s: s["implicit"])],
        "sentence length (words)": [(f"<= {q1}", lambda s: len(s["sentence"].split()) <= q1),
                                    (f"{q1 + 1}-{q2}", lambda s: q1 < len(s["sentence"].split()) <= q2),
                                    (f"> {q2}", lambda s: len(s["sentence"].split()) > q2)]}
    fig, axes = plt.subplots(1, 3, figsize=(MF.FULL, 2.0), sharey=True,
                             gridspec_kw={"width_ratios": [4, 2, 3]})
    rows = []
    for ax, (title, buckets) in zip(axes, groups.items()):
        gains, sds, labels = [], [], []
        for lab, f in buckets:
            per_run = []
            for r in runs:
                sel = [s for s in r["sents"] if f(s)]
                if sel:
                    per_run.append(prf((s["aura"], s["gold"]) for s in sel)[2]
                                   - prf((s["dot"], s["gold"]) for s in sel)[2])
            n = sum(1 for r in runs for s in r["sents"] if f(s))
            gains.append(st.mean(per_run))
            sds.append(st.stdev(per_run) / len(per_run) ** 0.5)
            labels.append(f"{lab}\n{100 * n / len(lens):.0f}%")
            rows.append([title, lab, n, st.mean(per_run), sds[-1]])
        ax.bar(range(len(gains)), gains, 0.6, color=MF.AURA, edgecolor="white", linewidth=1.0,
               yerr=sds, error_kw={"elinewidth": 0.6, "ecolor": MF.INK2, "capsize": 1.5})
        ax.axhline(0, color=MF.AXIS, linewidth=0.8)
        ax.set_xticks(range(len(gains)))
        ax.set_xticklabels(labels)
        ax.tick_params(axis="x", length=0)
        ax.set_title(title, loc="left", color=MF.INK)
    axes[0].set_ylabel("F1 gain over DOT\n(mean over runs ± s.e.)")
    MF.save(fig, out, "gain_buckets", ["grouping", "bucket", "n_sentences", "mean_gain", "standard_error"], rows)


# ----------------------------------------------------------------------------- 7 paired seeds
def fig_paired_seeds(runs, out):
    fig, ax = plt.subplots(figsize=(MF.COL, 2.6))
    rows = []
    ds = [d for d in MAIN if any(r["dataset"] == d for r in runs)]
    for i, d in enumerate(ds[::-1]):
        diffs = [(r["seed"], r["results"]["aura"]["f1"] - r["results"]["dot"]["f1"]) for r in runs if r["dataset"] == d]
        ys = [i + (k - 2) * 0.08 for k in range(len(diffs))]
        ax.scatter([x for _, x in diffs], ys, s=14, color=MF.AURA, edgecolor="white", linewidth=0.6, zorder=3)
        ax.plot([st.mean(x for _, x in diffs)] * 2, [i - 0.3, i + 0.3], color=MF.INK, linewidth=1.2)
        rows += [[d, s, x] for s, x in diffs]
    ax.axvline(0, color=MF.MUTED, linewidth=0.8)
    ax.set_yticks(range(len(ds)))
    ax.set_yticklabels(MF.short(ds[::-1]))
    ax.tick_params(axis="y", length=0)
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x")
    pos = sum(1 for r in rows if r[2] > 0)
    ax.set_xlabel(f"AURA − DOT F1 per seed\n({pos}/{len(rows)} runs > 0; vertical bar = mean)")
    MF.save(fig, out, "paired_seeds", ["dataset", "seed", "aura_minus_dot_f1"], rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--out", default="figures")
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    runs = load_runs(args.runs)
    print(f"{len(runs)} runs")
    for f in (fig_pr_shift, fig_count_errors, fig_error_taxonomy, fig_review_outcomes, fig_confidence,
              fig_gain_buckets, fig_paired_seeds):
        f(runs, args.out)


if __name__ == "__main__":
    main()
