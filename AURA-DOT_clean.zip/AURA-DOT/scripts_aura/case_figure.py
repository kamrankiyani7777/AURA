"""Case-study figure in the style of DOT's Figure 5, with an extra AURA line.

  python scripts_aura/case_figure.py --runs runs_aura --seed 5 --out case_study \
      --case "Rest:170:Simple sentence" --case "Rest:72:Implicit opinion" \
      --case "R16:369:Complex sentence (over-counting)" --case "Lap:212:Implicit aspects and contrast"

Each --case is DATASET:IDX:TITLE (IDX = 0-based line number in that dataset's test.txt).
Reads cache_g_test.jsonl (AURA), cache_g_dot_test.jsonl (DOT) and tuned.json of the seed,
recomputes both predictions and draws, per case: Input, Target, DOT, AURA.
Colours (as in DOT's figure): blue = correct tuple, red = wrong element(s) (wrong element in
bold), yellow = irrelevant tuple (no gold tuple shares two elements). AURA tuples removed by
the gate are shown struck through in grey with their calibrated confidence.
Writes <out>.pdf/.png and <out>.txt (plain listing to check the content).
"""
import argparse
import json
import os
import sys
import textwrap

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path[:0] = [ROOT, os.path.join(ROOT, "scripts_aura")]

from aura.core import Calibration, Config, decide, greedy_count  # noqa: E402

SENT = {"great": "positive", "bad": "negative", "ok": "neutral"}
BLUE, RED, YELLOW, GREY, INK = "#1f4fd1", "#d0242b", "#b8860b", "#8a8a8a", "#222222"
HEAD = ["#c9d8f5", "#f4cccc", "#fbefc4", "#d9ead3", "#e6dcf2", "#d6eef2"]


def read_jsonl(p):
    with open(p) as fp:
        return [json.loads(l) for l in fp if l.strip()]


def show(t):
    """(a, c, s, o) cache order -> DOT's display order (a, o, s, c)."""
    if len(t) == 4:
        a, c, s, o = t
        return [a, o, SENT.get(s, s), c]
    a, o, s = t
    return [a, o, SENT.get(s, s)]


def closest(t, gold):
    best, n = None, -1
    for g in gold:
        m = sum(x == y for x, y in zip(t, g))
        if m > n:
            best, n = g, m
    return best, n


def segments(tuples, gold, dropped=()):
    """list of (text, colour, bold, strike) segments for a tuple list."""
    segs = [("[", INK, False, False)]
    items = [(t, False, None) for t in tuples] + [(t, True, c) for t, c in dropped]
    for i, (t, is_drop, conf) in enumerate(items):
        if i:
            segs.append((", ", INK, False, False))
        disp = show(t)
        if is_drop:
            segs.append(("(" + ", ".join(disp) + ")", GREY, False, True))
            segs.append((f" c={conf:.2f}", GREY, False, False))
            continue
        if t in gold:
            segs.append(("(" + ", ".join(disp) + ")", BLUE, False, False))
            continue
        g, n = closest(t, gold)
        if g is None or n < 2:
            segs.append(("(" + ", ".join(disp) + ")", YELLOW, False, False))
            continue
        gd = show(g)
        segs.append(("(", RED, False, False))
        for j, (x, y) in enumerate(zip(disp, gd)):
            if j:
                segs.append((", ", RED, False, False))
            segs.append((x, RED, x != y, False))
        segs.append((")", RED, False, False))
    segs.append(("]", INK, False, False))
    return segs


def collect(args):
    cases = []
    for spec in args.case:
        ds, idx, title = spec.split(":", 2)
        idx = int(idx)
        sd = os.path.join(args.runs, ds, f"seed{args.seed}")
        tuned = json.load(open(os.path.join(sd, "tuned.json")))
        cal, cfg = Calibration(**tuned["calibration"]), Config(**tuned["config"])
        a_rec = {r["idx"]: r for r in read_jsonl(os.path.join(sd, "cache_g_test.jsonl"))}[idx]
        d_rec = {r["idx"]: r for r in read_jsonl(os.path.join(sd, "cache_g_dot_test.jsonl"))}[idx]
        gold = [tuple(g) for g in a_rec["gold"]]
        a = decide(a_rec, cfg, cal)
        d = decide(d_rec, Config(mode="dot"), Calibration())
        dropped = [(e["t"], e["c"]) for e in a["info"]
                   if e["action"] != "accept" and e.get("kept") is None and tuple(e["t"]) not in a["pred"]]
        cases.append({"title": f"Case {len(cases) + 1}: {title}", "ds": ds, "idx": idx,
                      "sentence": a_rec["sentence"], "gold": gold,
                      "dot": sorted(d["pred"]), "dot_k": greedy_count(d_rec["betas"]),
                      "aura": sorted(a["pred"]), "aura_dropped": dropped, "aura_K": a["K"],
                      "passes": a["passes"]})
    return cases


def draw(cases, out, width_in=7.0):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch

    plt.rcParams.update({"font.family": "DejaVu Sans", "pdf.fonttype": 42})
    fs, line_h, label_w = 7.2, 0.17, 0.62          # inches
    wrap_w = width_in - label_w - 0.35
    fig = plt.figure(figsize=(width_in, 20))
    r = fig.canvas.get_renderer()
    dpi = fig.dpi

    def text_w(s, bold):
        t = fig.text(0, 0, s, fontsize=fs, fontweight="bold" if bold else "normal")
        w = t.get_window_extent(renderer=r).width / dpi
        t.remove()
        return w

    def layout(segs):
        """split segments into lines (lists of (x, text, colour, bold, strike))."""
        lines, cur, x = [], [], 0.0
        for text, col, bold, strike in segs:
            for k, word in enumerate(text.split(" ")):
                piece = word if k == 0 else " " + word
                w = text_w(piece, bold)
                if x + w > wrap_w and cur:
                    lines.append(cur)
                    cur, x = [], 0.0
                    piece = piece.lstrip()
                    w = text_w(piece, bold)
                cur.append((x, piece, col, bold, strike, w))
                x += w
        if cur:
            lines.append(cur)
        return lines

    blocks = []
    for c in cases:
        rows = [("Input:", layout([(c["sentence"], INK, False, False)])),
                ("Target:", layout(segments(c["gold"], set(c["gold"])))),
                ("DOT:", layout(segments(c["dot"], set(c["gold"])))),
                ("AURA:", layout(segments(c["aura"], set(c["gold"]), c["aura_dropped"])))]
        h = 0.30 + sum(max(1, len(l)) * line_h + 0.07 for _, l in rows) + 0.08
        blocks.append((c, rows, h))
    total_h = sum(h + 0.22 for *_, h in blocks) + 0.45
    fig.set_size_inches(width_in, total_h)

    def Y(y):                          # inches from top -> figure fraction
        return 1 - y / total_h

    def X(x):
        return x / width_in

    y = 0.15
    for n, (c, rows, h) in enumerate(blocks):
        col = HEAD[n % len(HEAD)]
        box = FancyBboxPatch((X(0.1), Y(y + h)), X(width_in - 0.2), h / total_h,
                             boxstyle="square,pad=0", fc="none", ec="#5b6fb5" if n == 0 else "#999999",
                             lw=0.8, transform=fig.transFigure)
        fig.add_artist(box)
        tw = text_w(c["title"], True) + 0.4
        tab = FancyBboxPatch((X(width_in / 2 - tw / 2), Y(y + 0.13)), X(tw), 0.26 / total_h,
                             boxstyle="round,pad=0.005", fc=col, ec="#777777", lw=0.6,
                             transform=fig.transFigure)
        fig.add_artist(tab)
        fig.text(0.5, Y(y), c["title"], ha="center", va="center", fontsize=fs, fontweight="bold",
                 style="italic")
        yy = y + 0.30
        for label, lines in rows:
            fig.text(X(0.2), Y(yy), label, fontsize=fs, fontweight="bold", style="italic", va="top")
            for line in lines or [[]]:
                for x0, piece, colr, bold, strike, w in line:
                    fig.text(X(label_w + 0.2 + x0), Y(yy), piece, fontsize=fs, color=colr, va="top",
                             fontweight="bold" if bold else "normal")
                    if strike:
                        ym = Y(yy + 0.065)
                        fig.add_artist(matplotlib.lines.Line2D(
                            [X(label_w + 0.2 + x0), X(label_w + 0.2 + x0 + w)], [ym, ym],
                            color=colr, lw=0.6, transform=fig.transFigure))
                yy += line_h
            yy += 0.07
        y += h + 0.22
    for ext in ("pdf", "png"):
        fig.savefig(f"{out}.{ext}", dpi=300, bbox_inches="tight", pad_inches=0.05)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--seed", type=int, default=5)
    p.add_argument("--case", action="append", required=True, help="DATASET:IDX:TITLE")
    p.add_argument("--out", default="case_study")
    p.add_argument("--width", type=float, default=7.0, help="inches (7.0 = IEEE full width)")
    args = p.parse_args()
    cases = collect(args)
    with open(args.out + ".txt", "w") as fp:
        for c in cases:
            fp.write(f"{c['title']}  [{c['ds']} idx {c['idx']}]\n  {c['sentence']}\n  gold: {c['gold']}\n"
                     f"  DOT (count {c['dot_k']}): {c['dot']}\n  AURA (K={c['aura_K']}, {c['passes']} passes): "
                     f"{c['aura']}\n  AURA dropped: {c['aura_dropped']}\n\n")
    print(open(args.out + ".txt").read())
    draw(cases, args.out, args.width)
    print(f"wrote {args.out}.pdf / .png / .txt")


if __name__ == "__main__":
    main()
