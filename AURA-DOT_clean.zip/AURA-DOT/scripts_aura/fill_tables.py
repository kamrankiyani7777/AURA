"""Print the DOT / AURA rows of the paper's main table (tab:main) and Lap-Im/Res-Im table (tab:im).

  python scripts_aura/fill_tables.py --runs runs_aura [--final_timing]

Reads <runs>/summary.json (from aggregate.py). A dataset is filled only when all --seeds seeds are
in; otherwise its cell stays \\tbd. Avg needs all nine datasets. Time (sum over the nine test sets
of the mean timed seconds) is printed only with --final_timing, i.e. after final_timing.sh re-timed
every run on an otherwise idle GPU. Bold marks the best F1 per column among our rows and the
numbers reported in the table (REPORTED).
"""
import argparse
import json
import os
import statistics as st

MAIN = ["R15", "R16", "Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]
IM = ["Lap-Im", "Res-Im"]
# reported rows already in tab:main / tab:im, used only to decide what is bold
REPORTED = {"R15": [34.78, 36.42, 49.93], "R16": [43.71, 43.77, 62.48],
            "Lap": [27.31, 35.80, 41.56, 42.97], "Rest": [33.53, 44.61, 60.69, 58.41]}
REPORTED_IM = {"Lap-Im": [58.29, 58.48, 58.58, 59.26, 62.58], "Res-Im": [61.77, 61.39, 62.45, 62.19, 65.61]}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--seeds", type=int, default=5, help="seeds required before a cell is filled")
    p.add_argument("--final_timing", action="store_true")
    args = p.parse_args()
    S = json.load(open(os.path.join(args.runs, "summary.json")))

    def mean(ds, key):
        e = S.get(ds, {}).get(key)
        if not e or e["mean"] is None or e["n"] < args.seeds:
            return None
        return e["mean"]

    def cells(datasets, keys, reported):
        rows = {name: [mean(d, k) for d in datasets] for name, k in keys}
        out = {name: [] for name, _ in keys}
        for j, d in enumerate(datasets):
            best = max([r[j] for r in rows.values() if r[j] is not None] + reported.get(d, []), default=None)
            for name in rows:
                v = rows[name][j]
                out[name].append("\\tbd" if v is None else
                                 (f"\\textbf{{{v:.2f}}}" if round(v, 2) >= round(best, 2) else f"{v:.2f}"))
        return rows, out

    print("% ---- tab:main (DOT and AURA rows) ----")
    print("% seeds per dataset: " + ", ".join(f"{d}={S.get(d, {}).get('dot.f1', {}).get('n', 0)}" for d in MAIN))
    rows, out = cells(MAIN, [("DOT", "dot.f1"), ("AURA", "aura.f1")], REPORTED)
    avg = {n: (st.mean(v) if all(x is not None for x in v) else None) for n, v in rows.items()}
    best_avg = max([a for a in avg.values() if a is not None], default=None)
    passes = [mean(d, "aura.passes") for d in MAIN]
    times = {"DOT": [mean(d, "timed_dot.seconds") for d in MAIN], "AURA": [mean(d, "timed_aura.seconds") for d in MAIN]}
    for name, label in [("DOT", "DOT       "), ("AURA", "AURA (ours)")]:
        a = avg[name]
        a_s = "\\tbd" if a is None else (f"\\textbf{{{a:.2f}}}" if round(a, 2) >= round(best_avg, 2) else f"{a:.2f}")
        if name == "DOT":
            ps = "2"
        else:
            ps = f"{st.mean(passes):.2f}" if all(x is not None for x in passes) else "\\tbd"
        t = times[name]
        ts = f"{sum(t):.0f}" if args.final_timing and all(x is not None for x in t) else "\\tbd"
        print(f"{label} & " + " & ".join(out[name]) + f" & {a_s} & {ps} & {ts} \\\\")

    if any(d in S for d in IM):
        print("\n% ---- tab:im (DOT and AURA rows: F1, Implicit) ----")
        _, f1 = cells(IM, [("DOT", "dot.f1"), ("AURA", "aura.f1")], REPORTED_IM)
        _, im = cells(IM, [("DOT", "dot.implicit.f1"), ("AURA", "aura.implicit.f1")], {})
        for name, label in [("DOT", "DOT                   "), ("AURA", "AURA (ours)           ")]:
            print(f"{label} & " + " & ".join(f"{f1[name][j]} & {im[name][j]}" for j in range(len(IM))) + " \\\\")


if __name__ == "__main__":
    main()
