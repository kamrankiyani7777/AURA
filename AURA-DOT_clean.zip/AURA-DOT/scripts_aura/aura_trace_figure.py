"""AURA-only case study: the full decision trace for a few test sentences (no other system).

For each case the figure shows the input and gold quadruples, the count belief P(K|x) as a
small bar chart with the hypothesis set K(x) highlighted, every candidate quadruple with its
hypothesis support, calibrated confidence and the gate's decision (accepted / flagged ->
dropped / flagged -> kept after re-viewing), and AURA's final output.
Quadruples: blue = correct, red = wrong element (bold), yellow = irrelevant.

Pick cases yourself:
  python scripts_aura/aura_trace_figure.py --runs runs_aura --seed 5 --out aura_cases \
      --case "Rest:72:Implicit opinion" --case "Lap:212:Two implicit aspects"
or let the script pick them by fixed rules (first match in dataset order, <= --max_words):
  python scripts_aura/aura_trace_figure.py --runs runs_aura --seed 5 --out aura_cases --auto
Rules for --auto:
  A  gate removes a spurious quadruple and the final output is fully correct
  B  a quadruple with an implicit aspect/opinion is accepted and correct
  C  two count hypotheses are kept (|K(x)| = 2) and the final output is fully correct
  D  failure: a correct quadruple is flagged and dropped by the gate
Writes <out>.pdf/.png and <out>.txt (plain listing).
"""
import argparse
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path[:0] = [ROOT, os.path.join(ROOT, "scripts_aura")]

from aura.core import Calibration, Config, count_belief, decide  # noqa: E402
from aura.data import has_implicit, MAX_VIEWS  # noqa: E402

SENT = {"great": "positive", "bad": "negative", "ok": "neutral"}
BLUE, RED, YELLOW, GREY, INK, GREEN = "#1f4fd1", "#d0242b", "#b8860b", "#8a8a8a", "#222222", "#2e7d32"
HEAD = ["#c9d8f5", "#d9ead3", "#fbefc4", "#f4cccc", "#e6dcf2", "#d6eef2"]
ORDER = ["Rest", "Lap", "R16", "R15", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]
TASK = {"R15": "asqp", "R16": "asqp", "Lap": "acos", "Rest": "acos"}


def read_jsonl(p):
    with open(p) as fp:
        return [json.loads(l) for l in fp if l.strip()]


def show(t):
    a, c, s, o = t
    return [a, o, SENT.get(s, s), c]          # DOT-style order: aspect, opinion, sentiment, category


def closest(t, gold):
    best, n = None, -1
    for g in gold:
        m = sum(x == y for x, y in zip(t, g))
        if m > n:
            best, n = g, m
    return best, n


def tuple_segs(t, gold):
    disp = show(t)
    if t in gold:
        return [("(" + ", ".join(disp) + ")", BLUE, False)]
    g, n = closest(t, gold)
    if g is None or n < 2:
        return [("(" + ", ".join(disp) + ")", YELLOW, False)]
    gd, out = show(g), [("(", RED, False)]
    for j, (x, y) in enumerate(zip(disp, gd)):
        if j:
            out.append((", ", RED, False))
        out.append((x, RED, x != y))
    return out + [(")", RED, False)]


def list_segs(ts, gold):
    out = [("[", INK, False)]
    for i, t in enumerate(ts):
        if i:
            out.append((", ", INK, False))
        out += tuple_segs(t, gold)
    return out + [("]", INK, False)]


def decision(e):
    if e["action"] == "accept":
        return ("accepted", GREEN)
    if e["action"] == "flag-keep":
        return ("flagged → kept", INK)
    if e["action"] == "flag-drop":
        return ("flagged → dropped", GREY)
    kept = e.get("kept")
    if kept is None:
        return (f"flagged → re-viewed, dropped (A={e['A']:.2f})", GREY)
    if tuple(kept) != tuple(e["t"]):
        return (f"flagged → re-viewed, changed (A={e['A']:.2f})", INK)
    return (f"flagged → re-viewed, kept (A={e['A']:.2f})", INK)


def trace(rec, cfg, cal):
    out = decide(rec, cfg, cal)
    gold = [tuple(g) for g in rec["gold"]]
    return {"idx": rec["idx"], "sentence": rec["sentence"], "gold": gold,
            "probs": count_belief(rec["betas"]), "K": out["K"], "passes": out["passes"],
            "pred": sorted(out["pred"]), "info": out["info"]}


def load(args, ds):
    sd = os.path.join(args.runs, ds, f"seed{args.seed}")
    tuned = json.load(open(os.path.join(sd, "tuned.json")))
    cal, cfg = Calibration(**tuned["calibration"]), Config(**tuned["config"])
    return read_jsonl(os.path.join(sd, "cache_g_test.jsonl")), cfg, cal


def auto_pick(args):
    rules = {
        "A": ("Spurious quadruple removed by the gate",
              lambda tr: set(tr["pred"]) == set(tr["gold"]) and any(
                  e["action"] != "accept" and tuple(e["t"]) not in tr["gold"] for e in tr["info"])),
        "B": ("Implicit element",
              lambda tr: any(e["action"] == "accept" and tuple(e["t"]) in tr["gold"]
                             and has_implicit(tuple(e["t"]), tr["sentence"], "quad") for e in tr["info"])),
        "C": ("Two count hypotheses",
              lambda tr: len(tr["K"]) == 2 and set(tr["pred"]) == set(tr["gold"])),
        "D": ("Failure: correct quadruple dropped",
              lambda tr: any(e["action"] != "accept" and tuple(e["t"]) in tr["gold"]
                             and tuple(e["t"]) not in tr["pred"] for e in tr["info"])),
    }
    found = {}
    for ds in ORDER:
        if len(found) == len(rules):
            break
        try:
            recs, cfg, cal = load(args, ds)
        except FileNotFoundError:
            continue
        for r in recs:
            if len(r["sentence"].split()) > args.max_words:
                continue
            tr = trace(r, cfg, cal)
            for key, (title, rule) in rules.items():
                if key not in found and rule(tr):
                    found[key] = (ds, tr, title)
    return [found[k] for k in sorted(found)]


def manual_pick(args):
    out, cache = [], {}
    for spec in args.case:
        ds, idx, title = spec.split(":", 2)
        if ds not in cache:
            cache[ds] = load(args, ds)
        recs, cfg, cal = cache[ds]
        rec = {r["idx"]: r for r in recs}[int(idx)]
        out.append((ds, trace(rec, cfg, cal), title))
    return out


def draw(cases, out, width_in=7.0):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch
    from matplotlib.lines import Line2D

    plt.rcParams.update({"font.family": "DejaVu Sans", "pdf.fonttype": 42})
    fs, lh, lab_w, chart_w = 7.0, 0.165, 0.95, 1.25
    fig = plt.figure(figsize=(width_in, 30))
    r = fig.canvas.get_renderer()

    def tw(s, bold=False):
        t = fig.text(0, 0, s, fontsize=fs, fontweight="bold" if bold else "normal")
        w = t.get_window_extent(renderer=r).width / fig.dpi
        t.remove()
        return w

    def layout(segs, width):
        lines, cur, x = [], [], 0.0
        for text, col, bold in segs:
            for k, word in enumerate(text.split(" ")):
                piece = word if k == 0 else " " + word
                w = tw(piece, bold)
                if x + w > width and cur:
                    lines.append(cur)
                    cur, x = [], 0.0
                    piece = piece.lstrip()
                    w = tw(piece, bold)
                cur.append((x, piece, col, bold))
                x += w
        if cur:
            lines.append(cur)
        return lines or [[]]

    text_w = width_in - lab_w - 0.45
    top_w = text_w - chart_w - 0.15
    blocks = []
    for n, (ds, tr, title) in enumerate(cases):
        gold = tr["gold"]
        top = [("Input:", layout([(tr["sentence"], INK, False)], top_w)),
               ("Target:", layout(list_segs(gold, gold), top_w))]
        cand = []
        for e in tr["info"]:
            d, dc = decision(e)
            segs = tuple_segs(tuple(e["t"]), gold) + [(f"  sup={e['sup']:.2f}, c={e['c']:.2f}  ", INK, False),
                                                       (d, dc, True)]
            cand.append(layout(segs, text_w))
        bottom = [("AURA:", layout(list_segs(tr["pred"], gold), text_w))]
        h_top = max(sum(len(l) * lh + 0.06 for _, l in top), 0.95)
        h = 0.32 + h_top + 0.05 + (len(cand) * 0 + sum(len(c) * lh + 0.03 for c in cand)) + 0.10 \
            + sum(len(l) * lh + 0.06 for _, l in bottom) + 0.12
        blocks.append((ds, tr, title, top, cand, bottom, h_top, h))
    total = sum(b[-1] + 0.24 for b in blocks) + 0.2
    fig.set_size_inches(width_in, total)
    Y = lambda y: 1 - y / total
    X = lambda x: x / width_in

    y = 0.18
    for n, (ds, tr, title, top, cand, bottom, h_top, h) in enumerate(blocks):
        fig.add_artist(FancyBboxPatch((X(0.1), Y(y + h)), X(width_in - 0.2), h / total,
                                      boxstyle="square,pad=0", fc="none", ec="#999999", lw=0.8,
                                      transform=fig.transFigure))
        full = f"Case {n + 1}: {title}  ({ds})"
        w = tw(full, True) + 0.4
        fig.add_artist(FancyBboxPatch((X(width_in / 2 - w / 2), Y(y + 0.13)), X(w), 0.26 / total,
                                      boxstyle="round,pad=0.005", fc=HEAD[n % len(HEAD)], ec="#777777",
                                      lw=0.6, transform=fig.transFigure))
        fig.text(0.5, Y(y), full, ha="center", va="center", fontsize=fs, fontweight="bold", style="italic")
        yy = y + 0.32

        def put_rows(rows, yy):
            for label, lines in rows:
                fig.text(X(0.2), Y(yy), label, fontsize=fs, fontweight="bold", style="italic", va="top")
                for line in lines:
                    for x0, piece, col, bold in line:
                        fig.text(X(lab_w + 0.2 + x0), Y(yy), piece, fontsize=fs, color=col, va="top",
                                 fontweight="bold" if bold else "normal")
                    yy += lh
                yy += 0.06
            return yy

        put_rows(top, yy)
        # count belief chart
        ax = fig.add_axes([X(width_in - 0.3 - chart_w), Y(yy + h_top - 0.12), X(chart_w), (h_top - 0.28) / total])
        ks = list(range(1, MAX_VIEWS + 1))
        ax.bar(ks, tr["probs"], color=["#1f4fd1" if k in tr["K"] else "#c8c8c8" for k in ks], width=0.7)
        gk = min(len(tr["gold"]), MAX_VIEWS)
        ax.set_xticks(ks)
        ax.set_xticklabels([f"{k}*" if k == gk else str(k) for k in ks], fontsize=5.5)
        ax.set_ylim(0, 1)
        ax.set_yticks([0, 0.5, 1])
        ax.tick_params(labelsize=5.5, length=1.5, width=0.4)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        for s in ("left", "bottom"):
            ax.spines[s].set_linewidth(0.4)
        ax.set_title("P(K|x); blue = K(x), * = gold", fontsize=5.5, pad=2)
        yy += h_top + 0.05
        fig.text(X(0.2), Y(yy), "Candidates:", fontsize=fs, fontweight="bold", style="italic", va="top")
        for lines in cand:
            for line in lines:
                for x0, piece, col, bold in line:
                    fig.text(X(lab_w + 0.2 + x0), Y(yy), piece, fontsize=fs, color=col, va="top",
                             fontweight="bold" if bold else "normal")
                yy += lh
            yy += 0.03
        yy += 0.10
        put_rows(bottom, yy)
        fig.text(X(width_in - 0.25), Y(y + h - 0.08), f"{tr['passes']} decoding passes", fontsize=6,
                 ha="right", va="bottom", color=GREY)
        y += h + 0.24
    for ext in ("pdf", "png"):
        fig.savefig(f"{out}.{ext}", dpi=300, bbox_inches="tight", pad_inches=0.05)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--seed", type=int, default=5)
    p.add_argument("--case", action="append", default=[], help="DATASET:IDX:TITLE")
    p.add_argument("--auto", action="store_true", help="pick cases A-D by the fixed rules")
    p.add_argument("--max_words", type=int, default=25)
    p.add_argument("--out", default="aura_cases")
    p.add_argument("--width", type=float, default=7.0)
    args = p.parse_args()
    cases = auto_pick(args) if args.auto else manual_pick(args)
    if not cases:
        raise SystemExit("no cases selected")
    with open(args.out + ".txt", "w") as fp:
        for ds, tr, title in cases:
            fp.write(f"{title}  [{ds} idx {tr['idx']}]  {tr['passes']} passes\n  {tr['sentence']}\n"
                     f"  gold: {tr['gold']}\n  P(K): {[round(x, 2) for x in tr['probs']]}  K(x)={tr['K']}\n")
            for e in tr["info"]:
                fp.write(f"    {tuple(e['t'])}  sup={e['sup']:.2f} c={e['c']:.2f}  {decision(e)[0]}"
                         f"  {'(gold)' if tuple(e['t']) in tr['gold'] else ''}\n")
            fp.write(f"  AURA: {tr['pred']}\n\n")
    print(open(args.out + ".txt").read())
    draw(cases, args.out, args.width)
    print(f"wrote {args.out}.pdf / .png / .txt")


if __name__ == "__main__":
    main()
