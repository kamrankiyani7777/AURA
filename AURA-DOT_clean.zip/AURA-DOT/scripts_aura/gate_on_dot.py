"""Apply AURA's calibrated gate to the DOT-baseline generator g_dot (no anchored training, no re-viewing).

  python scripts_aura/infer.py --dataset Books --seed 5 --split dev --gen g_dot --no_reviews   # once per seed
  python scripts_aura/gate_on_dot.py --dataset Books --seeds 5 10 15 20 25

Calibration (T, Platt) is fitted on g_dot's own dev cache and every threshold is tuned on dev with
the same grid as tune.py; flagged tuples are dropped. Systems on test:
  dot              DOT's rule (greedy count, accept everything)
  dot_gate         greedy count + gate (tau)
  dot_belief_gate  count belief + support + gate (rho, H, tau): AURA without anchored training/re-viewing
Writes seed_dir/gate_on_dot.json and prints them next to DOT and AURA from results.json.
"""
import json
import os
import statistics as st
from dataclasses import replace

from common import Logger, base_parser, mode_of, read_jsonl, seed_dir
from evaluate import golds_of, system_scores
from aura.calibration import DEFAULT_GRID, fit_calibration, grid_search
from aura.core import Calibration, Config, run
from aura.metrics import paired_bootstrap

SYSTEMS = {  # name -> (switches, grid keys that are searched)
    "dot_gate":        ({"use_belief": False, "review": "drop"}, ["tau"]),
    "dot_belief_gate": ({"review": "drop"}, ["rho", "H", "tau"]),
}


def one_seed(args, seed, log):
    sd = seed_dir(args, seed)
    dev = read_jsonl(os.path.join(sd, "cache_g_dot_dev.jsonl"))
    test = read_jsonl(os.path.join(sd, "cache_g_dot_test.jsonl"))
    mode = mode_of(args.dataset)
    cal, info = fit_calibration(dev)
    log(f"{args.dataset} seed {seed}: g_dot calibration T={cal.T} w={cal.w:.3f} b={cal.b:.3f} "
        f"(dev pos rate {info['pos_rate']:.3f})")
    res = {"dataset": args.dataset, "seed": seed, "calibration": vars(cal), "calibration_info": info}
    dot_outs = run(test, Config(mode="dot"), Calibration())
    res["dot"] = system_scores(test, dot_outs, mode)
    for name, (switches, keys) in SYSTEMS.items():
        grid = {k: DEFAULT_GRID[k] for k in keys}
        best, results = grid_search(dev, cal, replace(Config(), **switches), grid)
        top = max(results, key=lambda r: (round(r["f1"], 4), -r["passes"]))
        outs = run(test, best, cal)
        res[name] = system_scores(test, outs, mode)
        res[name]["config"] = best.to_dict()
        res[name]["dev_f1"] = top["f1"]
        res[name]["p_vs_dot"] = paired_bootstrap([o["pred"] for o in outs], [o["pred"] for o in dot_outs],
                                                 golds_of(test), args.bootstrap, seed=seed)
    rp = os.path.join(sd, "results.json")
    if os.path.exists(rp):
        r = json.load(open(rp))
        res["aura"] = {k: r["aura"][k] for k in ("f1", "passes", "flag_rate")}
    json.dump(res, open(os.path.join(sd, "gate_on_dot.json"), "w"), indent=1, default=list)
    line = f"{args.dataset} seed {seed}: DOT {res['dot']['f1']:.2f}"
    for name in SYSTEMS:
        s = res[name]
        line += (f" | {name} {s['f1']:.2f} (tau={s['config']['tau']}, flag {s['flag_rate']:.2f}, "
                 f"passes {s['passes']:.2f}, p={s['p_vs_dot']:.3f})")
    if "aura" in res:
        line += f" | AURA {res['aura']['f1']:.2f}"
    log(line)
    return res


def main():
    p = base_parser(__doc__)
    p.add_argument("--seeds", type=int, nargs="+", default=[5])
    p.add_argument("--bootstrap", type=int, default=1000)
    args = p.parse_args()
    log = Logger(os.path.join(args.runs, args.dataset, "log_gate_on_dot.txt"))
    rows = [one_seed(args, s, log) for s in args.seeds]
    if len(rows) > 1:
        def ms(key):
            v = [r[key]["f1"] for r in rows if key in r]
            return f"{st.mean(v):.2f}+-{st.stdev(v):.2f} (n={len(v)})" if len(v) > 1 else "--"
        log(f"{args.dataset} mean over seeds: " + " | ".join(f"{k} {ms(k)}" for k in ["dot", *SYSTEMS, "aura"]))


if __name__ == "__main__":
    main()
