"""Step 2: train the count model f and the generator g (T5-base, DOT's settings).

  --role count  : f maps x -> order template of k views (k = number of gold tuples, <= 6)
  --role gen    : g maps x + template(R[:k]) -> one tuple per view (AURA: + one single-view
                  anchored example per gold tuple)
  --role gen_dot: g without the anchored examples (the fair DOT baseline)
"""
import os

from common import Logger, base_parser, load, mode_of, seed_dir
from aura.data import MAX_VIEWS, anchor_of, generator_input, implicit_elements, linearise, linearise_many, template
from aura.views import load_ranking, training_anchor_view


def count_pairs(examples, R):
    return [(e.sentence, template(R[: max(1, min(e.count, MAX_VIEWS))])) for e in examples if e.count > 0]


def gen_pairs(examples, R, mode, anchored: bool):
    pairs = []
    for e in examples:
        if e.count == 0:
            continue
        k = min(e.count, MAX_VIEWS)
        views = R[:k]
        pairs.append((generator_input(e.sentence, views), linearise_many(e.tuples, views, mode)))
        if anchored:
            for t in e.tuples:
                mk, _ = anchor_of(t, e.sentence, mode)
                v = training_anchor_view(mk, implicit_elements(t, e.sentence, mode), mode, R)
                pairs.append((generator_input(e.sentence, [v]), linearise(t, v, mode)))
    return pairs


def main():
    p = base_parser(__doc__)
    p.add_argument("--role", choices=["count", "gen", "gen_dot"], required=True)
    p.add_argument("--seed", type=int, default=5)
    p.add_argument("--model", default="t5-base")
    p.add_argument("--epochs", type=int, default=None, help="default: 30 (count), 40 (gen) as in DOT")
    p.add_argument("--batch_size", type=int, default=16)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--bf16", action="store_true")
    p.add_argument("--init_from", default=None,
                   help="start from this checkpoint instead of --model, e.g. seed_dir/f: official DOT initialises "
                        "its tuple generator from the trained count model (src/main.py, copy.deepcopy(tfm_model))")
    p.add_argument("--out_name", default=None, help="output folder in seed_dir (default: f, g or g_dot)")
    args = p.parse_args()
    from aura.model import load as load_model, set_seed, train_seq2seq

    sd = seed_dir(args, args.seed)
    name = args.out_name or {"count": "f", "gen": "g", "gen_dot": "g_dot"}[args.role]
    log = Logger(os.path.join(sd, f"log_train_{name}.txt"))
    R = load_ranking(os.path.join(args.runs, args.dataset, "R.json"))
    train = load(args, "train")
    mode = mode_of(args.dataset)
    if args.role == "count":
        pairs, epochs = count_pairs(train, R), args.epochs or 30
    else:
        pairs, epochs = gen_pairs(train, R, mode, anchored=args.role == "gen"), args.epochs or 40
    if args.smoke:
        epochs = min(epochs, 2)
    set_seed(args.seed)
    model, tok = load_model(args.init_from or args.model)
    log(f"{args.dataset} seed {args.seed} role {args.role}: {len(pairs)} training pairs, {epochs} epochs"
        + (f", initialised from {args.init_from}" if args.init_from else ""))
    log("example:", pairs[0])
    train_seq2seq(model, tok, pairs, epochs, args.batch_size, args.lr, seed=args.seed, bf16=args.bf16, log=log)
    out = os.path.join(sd, name)
    model.save_pretrained(out)
    tok.save_pretrained(out)
    log(f"saved {out}")


if __name__ == "__main__":
    main()
