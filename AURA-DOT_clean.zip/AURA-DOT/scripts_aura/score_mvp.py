"""Score the official MvP re-run with our scorer and DOT's, from MvP's saved per-view test outputs.

  python scripts_aura/score_mvp.py --mvp_out ~/mvp/outputs --runs runs_aura

For every <task>/<dataset>/seed<s> folder, reads MvP's pickle (15 view outputs per test sentence),
applies MvP's own parser (eval_utils.extract_spans_para, copied verbatim) and its vote (keep tuples
produced by >= num_path / 2 views; no tuple -> the first view's output, as in main.py), then maps the
tuples to our normalised form and scores them against our gold tuples with exact match (ours) and with
DOT's stop-word protocol. MvP's own F1 (its scorer against its own targets) is recomputed as a check
against result.txt. Writes <runs>/mvp_scores.json.
"""
import argparse
import glob
import json
import os
import pickle
import re
import statistics as st
from collections import Counter

import numpy as np

import common  # noqa: F401  (puts the project root on sys.path for `aura`)
from aura.data import SENT2WORD, load_split, norm_text
from aura.metrics import exact_match_f1
from rescore_dot_protocol import dot_f1

NAMES = {("asqp", "rest15"): ("R15", "asqp"), ("asqp", "rest16"): ("R16", "asqp"),
         ("acos", "laptop16"): ("Lap", "acos"), ("acos", "rest16"): ("Rest", "acos"),
         ("acos", "M-Rest"): ("M-Rest", "memd"), ("acos", "M-Lap"): ("M-Lap", "memd"),
         ("acos", "Books"): ("Books", "memd"), ("acos", "Clothing"): ("Clothing", "memd"),
         ("acos", "Hotel"): ("Hotel", "memd")}
MAIN = ["R15", "R16", "Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]


def extract_spans_para(seq, seq_type):  # MvP src/eval_utils.py, verbatim (without the prints)
    quads = []
    sents = [s.strip() for s in seq.split('[SSEP]')]
    for s in sents:
        try:
            tok_list = ["[C]", "[S]", "[A]", "[O]"]
            for tok in tok_list:
                if tok not in s:
                    s += " {} null".format(tok)
            index_ac = s.index("[C]")
            index_sp = s.index("[S]")
            index_at = s.index("[A]")
            index_ot = s.index("[O]")
            combined_list = [index_ac, index_sp, index_at, index_ot]
            arg_index_list = list(np.argsort(combined_list))
            result = []
            for i in range(len(combined_list)):
                start = combined_list[i] + 4
                sort_index = arg_index_list.index(i)
                if sort_index < 3:
                    next_ = arg_index_list[sort_index + 1]
                    r = s[start:combined_list[next_]]
                else:
                    r = s[start:]
                result.append(r.strip())
            ac, sp, at, ot = result
            if at.lower() == 'it':
                at = 'null'
        except ValueError:
            ac, at, sp, ot = '', '', '', ''
        quads.append((ac, at, sp, ot))
    return quads


def mvp_vote(views):
    """main.py, agg_strategy 'vote': keep quads produced by >= len(views) / 2 views."""
    all_quads = [q for s in views for q in extract_spans_para(s, 'pred')]
    kept = [q for q, c in Counter(all_quads).items() if c >= len(views) / 2]
    return kept if kept else extract_spans_para(views[0], 'pred')


def realign(term, sentence):
    """MvP decodes with the tokenizer's default clean-up, which glues tokens the datasets keep apart
    ("tiffany 's place" -> "tiffany's place"); our pipeline decodes without it. Map the term back to the
    sentence span with the same characters once spaces are ignored, so MvP is not penalised for it."""
    if term == "null" or f" {term} " in f" {sentence} ":
        return term
    words, target = sentence.split(), term.replace(" ", "")
    for i in range(len(words)):
        acc = ""
        for j in range(i, len(words)):
            acc += words[j]
            if acc == target:
                return " ".join(words[i:j + 1])
            if len(acc) >= len(target) or not target.startswith(acc):
                break
    return term


def ours(q, sentence):
    """MvP (ac, at, sp, ot) -> our normalised (aspect, category, sentiment, opinion)."""
    ac, at, sp, ot = (norm_text(x) for x in q)
    at = "null" if at in ("it", "") else realign(at, sentence)
    return (at, ac, SENT2WORD.get(sp, sp), realign(ot or "null", sentence))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mvp_out", default=os.path.expanduser("~/mvp/outputs"))
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--data_root", default="data")
    args = p.parse_args()
    out = {}
    for (task, name), (ds, our_task) in NAMES.items():
        examples = load_split(os.path.join(args.data_root, our_task, ds, "test.txt"))
        gold = [[tuple(t) for t in e.tuples] for e in examples]
        for sd in sorted(glob.glob(os.path.join(args.mvp_out, task, name, "seed*"))):
            pk = glob.glob(os.path.join(sd, "result_cd_*_path*_beam1.pickle"))
            if not pk:
                continue
            outputs, targets, _ = pickle.load(open(pk[0], "rb"))
            k = len(outputs) // len(gold)
            assert k * len(gold) == len(outputs), (sd, len(outputs), len(gold))
            raw = [mvp_vote(outputs[i * k:(i + 1) * k]) for i in range(len(gold))]
            mvp_targets = [extract_spans_para(t, 'gold') for t in targets[::k]]
            tp = sum(q in g for r, g in zip(raw, mvp_targets) for q in r)
            npred, ngold = sum(map(len, raw)), sum(map(len, mvp_targets))
            pr, rc = tp / max(npred, 1), tp / max(ngold, 1)
            preds = [{ours(q, e.sentence) for q in r} for r, e in zip(raw, examples)]
            seed = sd.rsplit("seed", 1)[1]
            out.setdefault(ds, {})[seed] = {
                "views": k,
                "mvp_own_f1": 100 * (2 * pr * rc / (pr + rc) if pr + rc else 0.0),
                "ours": exact_match_f1(preds, gold)["f1"],
                "dot_protocol": dot_f1(preds, gold)}
            print(f"{ds} seed {seed}: {k} views | MvP scorer {out[ds][seed]['mvp_own_f1']:.2f} | "
                  f"ours {out[ds][seed]['ours']:.2f} | DOT protocol {out[ds][seed]['dot_protocol']:.2f}", flush=True)
    json.dump(out, open(os.path.join(args.runs, "mvp_scores.json"), "w"), indent=1)
    for key in ("ours", "dot_protocol"):
        vals = {d: st.mean(r[key] for r in out[d].values()) for d in MAIN if d in out}
        n = {d: len(out[d]) for d in vals}
        print(f"\nMvP ({key}): " + "  ".join(f"{d} {v:.2f}" for d, v in vals.items())
              + (f"  Avg {st.mean(vals.values()):.2f}" if len(vals) == len(MAIN) else "") + f"  seeds {n}")


if __name__ == "__main__":
    main()
