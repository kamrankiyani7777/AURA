"""Step 4: fit calibration and tune AURA's hyper-parameters on the development cache.

Writes seed_dir/tuned.json with the calibration (T, w, b), the tuned configuration of the full
model, and a separately tuned configuration for every ablation variant (each variant gets the
same grid search, with the parameters it does not use held fixed).
"""
import json
import os
from dataclasses import replace

from common import Logger, base_parser, read_jsonl, seed_dir
from aura.calibration import DEFAULT_GRID, fit_calibration, grid_search
from aura.core import Config

# variant -> (fixed switches, grid parameters that become irrelevant)
VARIANTS = {
    "full":            ({}, []),
    "wo_belief":       ({"use_belief": False}, ["rho", "H"]),
    "wo_support":      ({"use_support": False}, []),
    "wo_calibration":  ({"use_calibration": False}, []),
    "wo_reviewing":    ({"review": "drop"}, ["tau_v", "M", "agree"]),
    "accept_all":      ({"review": "accept_all"}, ["tau_v", "M", "agree"]),
    "random_views":    ({"view_rank": "random"}, []),
    "wo_implicit_cue": ({"view_rank": "nll"}, []),
}
PARAM_DEFAULTS = {"rho": 0.9, "H": 2, "tau_v": 0.4, "M": 2, "agree": 0}


def tune_records(dev, grid=None, variants=VARIANTS, log=print):
    cal, cal_info = fit_calibration(dev)
    log(f"calibration: T={cal.T} w={cal.w:.3f} b={cal.b:.3f} ({cal_info['n_platt']} tuples, "
        f"pos rate {cal_info['pos_rate']})")
    out = {"calibration": {"T": cal.T, "w": cal.w, "b": cal.b}, "calibration_info": cal_info, "variants": {}}
    for name, (switches, unused) in variants.items():
        base = replace(Config(), **switches)
        fixed = {k: PARAM_DEFAULTS[k] for k in unused}
        best, results = grid_search(dev, cal, base, grid or DEFAULT_GRID, fixed)
        top = max(results, key=lambda r: (round(r["f1"], 4), -r["passes"]))
        out["variants"][name] = {"config": best.to_dict(), "dev": top}
        log(f"  {name:16s} dev F1 {top['f1']:.2f}  passes {top['passes']:.2f}  "
            + " ".join(f"{k}={getattr(best, k)}" for k in DEFAULT_GRID))
        if name == "full":
            out["config"] = best.to_dict()
            out["grid_full"] = results
    return out


def main():
    p = base_parser(__doc__)
    p.add_argument("--seed", type=int, default=5)
    p.add_argument("--cache", default=None, help="default: seed_dir/cache_g_dev.jsonl")
    p.add_argument("--out", default="tuned.json", help="file name in seed_dir")
    args = p.parse_args()
    sd = seed_dir(args, args.seed)
    log = Logger(os.path.join(sd, "log_tune.txt"))
    dev = read_jsonl(args.cache or os.path.join(sd, "cache_g_dev.jsonl"))
    log(f"{args.dataset} seed {args.seed}: tuning on {len(dev)} dev sentences")
    out = tune_records(dev, log=log)
    json.dump(out, open(os.path.join(sd, args.out), "w"), indent=1)
    log(f"wrote {os.path.join(sd, args.out)}")


if __name__ == "__main__":
    main()
