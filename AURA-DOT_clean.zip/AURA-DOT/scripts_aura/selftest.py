"""Step 0: sanity checks of the torch layer (run once on the GPU machine, ~1-2 minutes).

  python scripts_aura/selftest.py --model t5-base [--dataset R15]

Checks marker tokenisation, scanner alignment on real targets, constrained decoding (full and
single-tuple with forced prefix) with an *untrained* model, teacher-forced scoring, count
betas, and a few training steps.
"""
import os

from common import base_parser, categories, load, mode_of, free_vocab_of
from aura.data import (MAX_VIEWS, anchor_of, generator_input, implicit_elements, linearise, linearise_many,
                       parse_output, template)
from aura.views import all_views, anchored_views


def main():
    p = base_parser(__doc__)
    p.set_defaults(dataset="R15")
    p.add_argument("--model", default="t5-base")
    args = p.parse_args()
    import numpy as np
    import torch
    from aura import model as M
    from aura.constraints import MarkerVocab, content_vocab, scan

    mode = mode_of(args.dataset)
    model, tok = M.load(args.model)
    print("device:", next(model.parameters()).device)
    mv = MarkerVocab.build(tok, mode)
    print("marker patterns:", {k: tok.convert_ids_to_tokens(v) for k, v in mv.patterns.items()})

    train = load(args, "train")[:200]
    R = all_views(mode)
    n_bad = 0
    for e in train:
        k = min(e.count, MAX_VIEWS)
        tgt = linearise_many(e.tuples, R[:k], mode)
        ids = tok(tgt).input_ids
        st = scan(ids, mv)
        if len(st.segments) != e.count or st.tuples_done != e.count - 1:
            n_bad += 1
        back = parse_output(M.decode_text(tok, ids), mode)
        if back != list(e.tuples):
            n_bad += 1
            if n_bad < 4:
                print("  mismatch:", e.tuples, back)
    print(f"[1] scanner/parse alignment on 200 targets: {n_bad} problems")
    assert n_bad <= 4, "tokeniser round trip broken"

    cats = categories(load(args, "train"))
    ex = load(args, "test")[:8]
    sents = [e.sentence for e in ex]
    contents = [content_vocab(tok, mode, tok(s, add_special_tokens=False).input_ids, cats, free_vocab_of(args.dataset))
                for s in sents]
    inputs = [generator_input(s, R[:2]) for s in sents]
    ids = M.constrained_generate(model, tok, inputs, contents, mv, max_new_tokens=120)
    outs = [parse_output(M.decode_text(tok, x), mode) for x in ids]
    well = sum(all(t is not None for t in o) for o, x in zip(outs, ids) if x and x[-1] == mv.eos_id)
    print(f"[2] constrained decoding (untrained model): {well}/{len(ids)} finished outputs well-formed")
    print("    e.g.", M.decode_text(tok, ids[0])[:150])

    e = ex[0]
    t = e.tuples[0]
    mk, val = anchor_of(t, e.sentence, mode)
    vs = anchored_views(mk, implicit_elements(t, e.sentence, mode), mode)
    pre = [f"{mk} {val}"] * len(vs)
    ins = [generator_input(e.sentence, [v]) for v in vs]
    ids = M.constrained_generate(model, tok, ins, [contents[0]] * len(vs), mv, prefixes=pre, single=True, max_new_tokens=48)
    for x in ids:
        o = parse_output(M.decode_text(tok, x), mode)
        assert M.decode_text(tok, x).startswith(f"{mk} {val}".split()[0]), M.decode_text(tok, x)
        print("[3] anchored single-tuple decode:", M.decode_text(tok, x), "->", o)
        break

    tg = [tok(linearise(t, v, mode)).input_ids for v in vs]
    lps = M.token_logprobs(model, tok, ins, tg, ["1.0", "2.0"])
    nll = M.mean_nll(model, tok, ins, [linearise(t, v, mode) for v in vs])
    assert abs(nll[0] + float(np.mean(lps[0]["1.0"]))) < 1e-3
    z = M.segment_z(tg[0], lps[0], mv)
    print(f"[4] scoring: mean NLL {nll[0]:.3f}, element z {z[0]}")

    betas = M.count_betas(model, tok, sents[:4], template(R[:MAX_VIEWS]), mv)
    assert all(len(b) == MAX_VIEWS - 1 and all(0 <= x <= 1 for x in b) for b in betas)
    print(f"[5] count betas: {[round(x, 3) for x in betas[0]]}")

    pairs = [(generator_input(e.sentence, R[:min(e.count, MAX_VIEWS)]),
              linearise_many(e.tuples, R[:min(e.count, MAX_VIEWS)], mode)) for e in train[:64]]
    losses = []
    M.train_seq2seq(model, tok, pairs, 3, batch_size=16, lr=3e-4, log_every=0,
                    log=lambda m: (losses.append(float(m.split()[-1])), print("   ", m)))
    assert losses[-1] < losses[0], "loss did not decrease"
    print("[6] training loop OK")
    print("\nselftest passed")


if __name__ == "__main__":
    main()
