"""Step 5: evaluate every system and analysis on the test caches -> seed_dir/results.json.

Uses
  cache_g_test.jsonl      (AURA generator, with re-views)
  cache_g_dot_test.jsonl  (DOT-baseline generator, no re-views)   [optional]
  tuned.json              (from tune.py)
Systems: DOT (greedy count), DOT oracle count, AURA, AURA oracle count, AURA generator with
DOT's decision rule (isolates the effect of the anchored training examples), every ablation
variant, count accuracy / coverage, implicit vs explicit F1, ECE (raw, temperature, Platt),
flag analysis, passes by difficulty, tau x M sensitivity, paired bootstrap AURA vs DOT.
"""
import json
import math
import os
from dataclasses import replace

from common import Logger, base_parser, mode_of, read_jsonl, seed_dir
from aura.core import Calibration, Config, count_belief, greedy_count, hypothesis_set, hyp_tuples, run
from aura.data import MAX_VIEWS, has_implicit
from aura.metrics import ece, exact_match_f1, explicit_subset_f1, implicit_subset_f1, paired_bootstrap


def golds_of(recs):
    return [[tuple(g) for g in r["gold"]] for r in recs]


def system_scores(recs, outs, mode):
    preds = [o["pred"] for o in outs]
    golds = golds_of(recs)
    sents = [r["sentence"] for r in recs]
    m = exact_match_f1(preds, golds)
    m["implicit"] = implicit_subset_f1(preds, golds, sents, mode)
    m["explicit"] = explicit_subset_f1(preds, golds, sents, mode)
    m["passes"] = sum(o["passes"] for o in outs) / max(1, len(outs))
    m["flag_rate"] = sum(o["flagged"] for o in outs) / max(1, sum(o["n_pool"] for o in outs))
    return m


def count_stats(recs, cfg):
    n = len(recs)
    gk = [min(max(r["gold_count"], 1), MAX_VIEWS) for r in recs]
    greedy = [greedy_count(r["betas"]) for r in recs]
    probs = [count_belief(r["betas"]) for r in recs]
    argmax = [max(range(MAX_VIEWS), key=lambda i: p[i]) + 1 for p in probs]
    K = [hypothesis_set(p, cfg.rho, cfg.H) for p in probs]
    return {"greedy_acc": 100 * sum(a == b for a, b in zip(greedy, gk)) / n,
            "argmax_acc": 100 * sum(a == b for a, b in zip(argmax, gk)) / n,
            "coverage": 100 * sum(g in k for g, k in zip(gk, K)) / n,
            "mean_|K|": sum(len(k) for k in K) / n}


def calibration_stats(recs, outs, cal):
    """ECE over the AURA candidate pool (every tuple produced under K(x)), against exact match."""
    raw, temp, platt, y = [], [], [], []
    for r, o in zip(recs, outs):
        gold = {tuple(g) for g in r["gold"]}
        pool1, poolT = {}, {}
        for k in o["K"]:
            for t, z in hyp_tuples(r, k, "1.0").items():
                pool1[t] = max(pool1.get(t, -1e9), z)
            for t, z in hyp_tuples(r, k, cal.T).items():
                poolT[t] = max(poolT.get(t, -1e9), z)
        for t in poolT:
            y.append(int(t in gold))
            raw.append(math.exp(min(pool1.get(t, poolT[t]), 0.0)))
            temp.append(math.exp(min(poolT[t], 0.0)))
            platt.append(cal.conf(poolT[t]))
    return {"ece_raw": ece(raw, y), "ece_temp": ece(temp, y), "ece_platt": ece(platt, y), "n": len(y),
            "bins_platt": reliability(platt, y)}


def reliability(conf, y, n_bins=10):
    out = []
    for b in range(n_bins):
        lo, hi = b / n_bins, (b + 1) / n_bins
        idx = [i for i, c in enumerate(conf) if lo < c <= hi or (b == 0 and c == 0)]
        if idx:
            out.append({"bin": b, "n": len(idx), "conf": sum(conf[i] for i in idx) / len(idx),
                        "acc": sum(y[i] for i in idx) / len(idx)})
    return out


def flag_analysis(recs, outs):
    acc = {"accept": [0, 0], "flagged": [0, 0]}
    changed = {"wrong": [0, 0], "right": [0, 0]}     # [changed, total] among reviewed q0
    for r, o in zip(recs, outs):
        gold = {tuple(g) for g in r["gold"]}
        for e in o["info"]:
            ok = e["t"] in gold
            key = "accept" if e["action"] == "accept" else "flagged"
            acc[key][0] += ok
            acc[key][1] += 1
            if e["action"] == "review":
                c = changed["right" if ok else "wrong"]
                c[0] += int(e["kept"] != e["t"])
                c[1] += 1
    pct = lambda a: 100 * a[0] / a[1] if a[1] else float("nan")
    return {"precision_accepted": pct(acc["accept"]), "precision_flagged": pct(acc["flagged"]),
            "n_accepted": acc["accept"][1], "n_flagged": acc["flagged"][1],
            "change_rate_when_wrong": pct(changed["wrong"]), "change_rate_when_right": pct(changed["right"])}


def passes_by_difficulty(recs, outs, mode):
    easy, hard, hist = [], [], {}
    for r, o in zip(recs, outs):
        imp = any(has_implicit(tuple(g), r["sentence"], mode) for g in r["gold"])
        (easy if r["gold_count"] == 1 and not imp else hard).append(o["passes"])
        hist[o["passes"]] = hist.get(o["passes"], 0) + 1
    return {"easy_n": len(easy), "easy_two_pass_pct": 100 * sum(p <= 2 for p in easy) / max(1, len(easy)),
            "easy_mean": sum(easy) / max(1, len(easy)), "hard_n": len(hard),
            "hard_mean": sum(hard) / max(1, len(hard)), "hist": {str(k): v for k, v in sorted(hist.items())}}


def sensitivity(recs, cfg, cal, taus=(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.01), Ms=(1, 2, 3, 4)):
    out = []
    for tau in taus:
        for M in Ms:
            o = run(recs, replace(cfg, tau=tau, M=M), cal)
            f = exact_match_f1([x["pred"] for x in o], golds_of(recs))["f1"]
            out.append({"tau": tau, "M": M, "f1": f, "passes": sum(x["passes"] for x in o) / len(o)})
    return out


def main():
    p = base_parser(__doc__)
    p.add_argument("--seed", type=int, default=5)
    p.add_argument("--tuned", default=None, help="default: seed_dir/tuned.json (use tuned_shared.json for the shared setting)")
    p.add_argument("--tag", default="", help="suffix for results file")
    p.add_argument("--bootstrap", type=int, default=1000)
    args = p.parse_args()
    sd = seed_dir(args, args.seed)
    log = Logger(os.path.join(sd, "log_eval.txt"))
    mode = mode_of(args.dataset)
    tuned = json.load(open(args.tuned or os.path.join(sd, "tuned.json")))
    cal = Calibration(**tuned["calibration"])
    cfg = Config(**tuned["config"])
    test = read_jsonl(os.path.join(sd, "cache_g_test.jsonl"))
    res = {"dataset": args.dataset, "seed": args.seed, "n_test": len(test), "calibration": tuned["calibration"],
           "config": tuned["config"]}

    outs = run(test, cfg, cal)
    res["aura"] = system_scores(test, outs, mode)
    res["aura_oracle"] = system_scores(test, run(test, replace(cfg, mode="aura_oracle"), cal), mode)
    res["g_with_dot_rule"] = system_scores(test, run(test, Config(mode="dot"), Calibration()), mode)
    res["g_with_dot_rule_oracle"] = system_scores(test, run(test, Config(mode="dot_oracle"), Calibration()), mode)

    dot_path = os.path.join(sd, "cache_g_dot_test.jsonl")
    dot_outs = None
    if os.path.exists(dot_path):
        dtest = read_jsonl(dot_path)
        assert [r["idx"] for r in dtest] == [r["idx"] for r in test], "DOT and AURA caches differ"
        dot_outs = run(dtest, Config(mode="dot"), Calibration())
        res["dot"] = system_scores(dtest, dot_outs, mode)
        res["dot_oracle"] = system_scores(dtest, run(dtest, Config(mode="dot_oracle"), Calibration()), mode)
        if args.bootstrap:
            res["p_aura_vs_dot"] = paired_bootstrap([o["pred"] for o in outs], [o["pred"] for o in dot_outs],
                                                    golds_of(test), args.bootstrap, seed=args.seed)
    else:
        log(f"(no {dot_path}: DOT baseline skipped)")

    res["variants"] = {}
    for name, v in tuned.get("variants", {}).items():
        vo = run(test, Config(**v["config"]), cal)
        res["variants"][name] = system_scores(test, vo, mode)
    res["count"] = count_stats(test, cfg)
    res["calibration_eval"] = calibration_stats(test, outs, cal)
    res["flags"] = flag_analysis(test, outs)
    res["passes_by_difficulty"] = passes_by_difficulty(test, outs, mode)
    res["sensitivity"] = sensitivity(test, cfg, cal)

    for t in ("timed_aura_test.json", "timed_dot_test.json"):
        fp = os.path.join(sd, t)
        if os.path.exists(fp):
            res[t[:-10]] = json.load(open(fp))

    out = os.path.join(sd, f"results{args.tag}.json")
    json.dump(res, open(out, "w"), indent=1, default=list)
    line = f"{args.dataset} seed {args.seed}: AURA F1 {res['aura']['f1']:.2f} ({res['aura']['passes']:.2f} passes)"
    if "dot" in res:
        line += f" | DOT F1 {res['dot']['f1']:.2f} | p={res.get('p_aura_vs_dot', float('nan')):.3f}"
    log(line)
    log(f"wrote {out}")


if __name__ == "__main__":
    main()
