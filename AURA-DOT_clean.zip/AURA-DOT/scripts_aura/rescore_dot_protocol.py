"""Re-score DOT, DOT + gate and AURA with DOT's official evaluation (src/eval_utils.py).

  python scripts_aura/rescore_dot_protocol.py --runs runs_aura      # needs NLTK stopwords + punkt_tab

DOT's scorer (extract_spans_para / compute_f1_scores) differs from ours in two ways, applied to gold
and predictions alike: an aspect "it" is null (ours does this too), and stop words are removed from
the aspect and opinion terms with NLTK's English list and word_tokenize. A prediction counts as
correct when it is in the gold list. Predictions are recomputed from the caches with the configs
already tuned on dev (tuned.json, gate_on_dot.json); nothing is re-tuned here.
Writes <runs>/dot_protocol.json and prints per-dataset means over seeds for both protocols.
"""
import argparse
import glob
import json
import os
import statistics as st
from functools import lru_cache

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

from common import read_jsonl
from aura.core import Calibration, Config, run
from aura.metrics import exact_match_f1

MAIN = ["R15", "R16", "Lap", "Rest", "M-Rest", "M-Lap", "Books", "Clothing", "Hotel"]
STOP = set(stopwords.words("english"))


@lru_cache(maxsize=None)
def filt(term):
    return " ".join(w for w in word_tokenize(term) if w.lower() not in STOP)


def dot_form(t):
    a, c, s, o = t
    return (filt("null" if a == "it" else a), c, s, filt(o))


def dot_f1(preds, golds):
    tp = n_pred = n_gold = 0
    for p, g in zip(preds, golds):
        gl = [dot_form(tuple(x)) for x in g]
        pl = [dot_form(tuple(x)) for x in p]
        n_gold += len(gl)
        n_pred += len(pl)
        tp += sum(x in gl for x in pl)
    pr = tp / n_pred if n_pred else 0.0
    rc = tp / n_gold if n_gold else 0.0
    return 100 * (2 * pr * rc / (pr + rc) if pr + rc else 0.0)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--tuned", default="tuned.json", help="tuned file in each seed dir")
    p.add_argument("--tag", default="", help="suffix for the output file")
    args = p.parse_args()
    out = {}
    for ds in MAIN:
        for sd in sorted(glob.glob(os.path.join(args.runs, ds, "seed*"))):
            if not os.path.exists(os.path.join(sd, "results.json")):
                continue
            tuned = json.load(open(os.path.join(sd, args.tuned)))
            test = read_jsonl(os.path.join(sd, "cache_g_test.jsonl"))
            dtest = read_jsonl(os.path.join(sd, "cache_g_dot_test.jsonl"))
            golds = [r["gold"] for r in test]
            preds = {
                "dot": [o["pred"] for o in run(dtest, Config(mode="dot"), Calibration())],
                "aura": [o["pred"] for o in run(test, Config(**tuned["config"]), Calibration(**tuned["calibration"]))],
            }
            gp = os.path.join(sd, "gate_on_dot.json")
            if os.path.exists(gp):
                g = json.load(open(gp))
                preds["dot_gate"] = [o["pred"] for o in run(dtest, Config(**g["dot_gate"]["config"]),
                                                            Calibration(**g["calibration"]))]
            seed = sd.rsplit("seed", 1)[1]
            out.setdefault(ds, {})[seed] = {
                k: {"ours": exact_match_f1(v, [[tuple(x) for x in gg] for gg in golds])["f1"],
                    "dot_protocol": dot_f1(v, golds)} for k, v in preds.items()}
        print(f"  {ds} done", flush=True)
    json.dump(out, open(os.path.join(args.runs, f"dot_protocol{args.tag}.json"), "w"), indent=1)

    systems = ["dot", "dot_gate", "aura"]
    for proto in ("ours", "dot_protocol"):
        print(f"\n== {proto} (mean over seeds) ==")
        print(f"{'':10s}" + "".join(f"{d:>9s}" for d in MAIN) + f"{'Avg':>8s}")
        for s in systems:
            vals = [st.mean(r[s][proto] for r in out[d].values() if s in r) for d in MAIN]
            print(f"{s:10s}" + "".join(f"{v:9.2f}" for v in vals) + f"{st.mean(vals):8.2f}")


if __name__ == "__main__":
    main()
