"""Optional: one hyper-parameter setting shared across datasets (Section 'Sensitivity and a
shared setting'). Calibration stays per dataset (it is fitted, not tuned). For each seed,
picks the grid point with the best mean dev F1 over the given datasets and writes
seed_dir/tuned_shared.json for each of them. Then run
  evaluate.py --tuned runs_aura/<ds>/seed<s>/tuned_shared.json --tag _shared
"""
import argparse
import itertools
import json
import os
import sys
from dataclasses import replace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from aura.calibration import DEFAULT_GRID, evaluate_config  # noqa: E402
from aura.core import Calibration, Config  # noqa: E402


def read_jsonl(path):
    with open(path) as fp:
        return [json.loads(l) for l in fp if l.strip()]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--runs", default="runs_aura")
    p.add_argument("--datasets", nargs="+", required=True)
    p.add_argument("--seed", type=int, default=5)
    args = p.parse_args()
    data = {}
    for ds in args.datasets:
        sd = os.path.join(args.runs, ds, f"seed{args.seed}")
        tuned = json.load(open(os.path.join(sd, "tuned.json")))
        data[ds] = (read_jsonl(os.path.join(sd, "cache_g_dev.jsonl")), Calibration(**tuned["calibration"]), tuned, sd)
    keys = list(DEFAULT_GRID)
    best, best_key = None, None
    for vals in itertools.product(*[DEFAULT_GRID[k] for k in keys]):
        cfg = replace(Config(), **dict(zip(keys, vals)))
        ms = [evaluate_config(dev, cfg, cal) for dev, cal, _, _ in data.values()]
        key = (round(sum(m["f1"] for m in ms) / len(ms), 4), -sum(m["passes"] for m in ms) / len(ms))
        if best_key is None or key > best_key:
            best, best_key = cfg, key
    print(f"seed {args.seed}: shared setting {dict((k, getattr(best, k)) for k in keys)}  mean dev F1 {best_key[0]:.2f}")
    for ds, (_, cal, tuned, sd) in data.items():
        out = {"calibration": tuned["calibration"], "config": best.to_dict(), "variants": {}}
        json.dump(out, open(os.path.join(sd, "tuned_shared.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
