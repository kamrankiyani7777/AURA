"""Shared helpers for the AURA experiment scripts."""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from aura.data import (MAX_VIEWS, TASK_DATASETS, dataset_path, load_split)  # noqa: E402

IM_DATASETS = {"Lap-Im", "Res-Im"}   # triplet datasets with inferred implicit terms


def task_of(dataset: str) -> str:
    for t, ds in TASK_DATASETS.items():
        if dataset in ds:
            return t
    if dataset in IM_DATASETS:
        return "gomit"
    raise ValueError(f"unknown dataset {dataset}")


def mode_of(dataset: str) -> str:
    return "triplet" if dataset in IM_DATASETS else "quad"


def free_vocab_of(dataset: str) -> bool:
    return dataset in IM_DATASETS


def base_parser(desc: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=desc)
    p.add_argument("--data_root", default=os.path.join(ROOT, "data"))
    p.add_argument("--runs", default=os.path.join(ROOT, "runs_aura"))
    p.add_argument("--dataset", required=True)
    p.add_argument("--smoke", action="store_true", help="tiny subset for a quick end-to-end check")
    return p


def load(args, split):
    ex = load_split(dataset_path(args.data_root, task_of(args.dataset), args.dataset, split), mode_of(args.dataset))
    if getattr(args, "smoke", False):
        ex = ex[:24]
    return ex


def categories(train_examples):
    cats = set()
    for e in train_examples:
        if e.mode == "quad":
            cats |= {t[1] for t in e.tuples}
    return sorted(cats)


def ds_dir(args) -> str:
    d = os.path.join(args.runs, args.dataset)
    os.makedirs(d, exist_ok=True)
    return d


def seed_dir(args, seed) -> str:
    d = os.path.join(ds_dir(args), f"seed{seed}")
    os.makedirs(d, exist_ok=True)
    return d


class Logger:
    def __init__(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.fp = open(path, "a")

    def __call__(self, *a):
        msg = " ".join(str(x) for x in a)
        line = time.strftime("%H:%M:%S ") + msg
        print(line, flush=True)
        self.fp.write(line + "\n")
        self.fp.flush()


def write_jsonl(path, records):
    with open(path, "w") as fp:
        for r in records:
            fp.write(json.dumps(r) + "\n")


def read_jsonl(path):
    with open(path) as fp:
        return [json.loads(l) for l in fp if l.strip()]
