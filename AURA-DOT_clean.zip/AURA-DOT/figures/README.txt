Seeds per dataset in these figures (final figures need 5 each):
  R15       n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  R16       n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  Lap       n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  Rest      n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  M-Rest    n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  M-Lap     n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  Books     n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  Clothing  n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
  Hotel     n=5  seeds [5, 10, 15, 20, 25]  gate_on_dot n=5
