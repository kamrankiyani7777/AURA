"""Data loading, normalisation, linearisation and parsing (no torch).

Tuples are handled in a canonical *normalised* form:
  quad mode    : (aspect, category, sentiment, opinion)   sentiment in {great, bad, ok}
  triplet mode : (aspect, opinion, sentiment)              (Lap-Im / Res-Im style)
An implicit aspect/opinion is the string "null" (quad mode). In the text that the
models generate, an implicit aspect is written "it" (as in DOT) and mapped back to "null".
"""
from __future__ import annotations

import ast
import json
import os
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

SENT2WORD = {"positive": "great", "negative": "bad", "neutral": "ok",
             "pos": "great", "neg": "bad", "neu": "ok",
             "great": "great", "bad": "bad", "ok": "ok"}
WORD2SENT = {"great": "positive", "bad": "negative", "ok": "neutral"}
SENT_WORDS = ["great", "bad", "ok"]

QUAD_MARKERS = ["[A]", "[C]", "[S]", "[O]"]          # aspect, category, sentiment, opinion
TRIPLET_MARKERS = ["[A]", "[O]", "[S]"]              # target, opinion, sentiment
SSEP = "[SSEP]"

TASK_DATASETS = {
    "asqp": ["R15", "R16"],
    "acos": ["Lap", "Rest"],
    "memd": ["M-Rest", "M-Lap", "Books", "Clothing", "Hotel"],
}
MAX_VIEWS = 6   # K_max, as in DOT


def norm_text(s: str) -> str:
    return re.sub(r"\s+", " ", str(s).strip().lower())


@dataclass
class Example:
    idx: int
    sentence: str                       # lower-cased, whitespace-normalised
    tuples: List[Tuple[str, ...]]       # normalised gold tuples (sorted by position)
    mode: str = "quad"                  # "quad" or "triplet"

    @property
    def count(self) -> int:
        return len(self.tuples)


# ----------------------------------------------------------------------------- loading
def _normalise_tuple(t: Sequence[str], mode: str) -> Tuple[str, ...]:
    if mode == "quad":
        a, c, s, o = [norm_text(x) or "null" for x in t]     # one ACOS-Rest train label has an empty opinion
        # DOT writes an implicit aspect as "it", so an annotated aspect "it" and an implicit
        # aspect are indistinguishable in its targets and evaluation; we merge them the same way.
        if a == "it":
            a = "null"
        return (a, c, SENT2WORD.get(s, s), o)
    a, o, s = [norm_text(x) or "null" for x in t]
    return (a, o, SENT2WORD.get(s, s))


def _position(sentence: str, t: Tuple[str, ...], mode: str) -> float:
    """Sort key used by DOT (--sort_label): last position of aspect/opinion in the sentence."""
    a, o = (t[0], t[3]) if mode == "quad" else (t[0], t[1])
    pa = sentence.find(a) if a and a != "null" else -1
    po = sentence.find(o) if o and o != "null" else -1
    p = max(pa, po)
    return 1e4 if p < 0 else p


def load_split(path: str, mode: str = "quad") -> List[Example]:
    """Read DOT's format `sentence####[[a, c, s, o], ...]` (or triplets [a, o, s]),
    or JSONL with fields {"sentence": str, "tuples": [[...], ...]}."""
    out: List[Example] = []
    with open(path, encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            if path.endswith(".jsonl"):
                rec = json.loads(line)
                sent, raw = rec["sentence"], rec["tuples"]
            else:
                sent, raw = line.split("####")
                raw = ast.literal_eval(raw)
            sent = norm_text(sent)
            tuples = [_normalise_tuple(t, mode) for t in raw]
            tuples.sort(key=lambda t: _position(sent, t, mode))
            out.append(Example(len(out), sent, tuples, mode))
    return out


def dataset_path(data_root: str, task: str, dataset: str, split: str) -> str:
    for ext in (".txt", ".jsonl"):
        p = os.path.join(data_root, task, dataset, split + ext)
        if os.path.exists(p):
            return p
    raise FileNotFoundError(f"no {split} file for {task}/{dataset} under {data_root}")


# ----------------------------------------------------------------------------- views
def markers_for(mode: str) -> List[str]:
    return QUAD_MARKERS if mode == "quad" else TRIPLET_MARKERS


def element_map(t: Tuple[str, ...], mode: str) -> Dict[str, str]:
    """Marker -> surface value written in the target text (implicit aspect -> 'it')."""
    if mode == "quad":
        a, c, s, o = t
        return {"[A]": "it" if a == "null" else a, "[C]": c, "[S]": s, "[O]": o}
    a, o, s = t
    return {"[A]": a, "[O]": o, "[S]": s}


def view_str(view: Sequence[str]) -> str:
    return " ".join(view)


def linearise(t: Tuple[str, ...], view: Sequence[str], mode: str) -> str:
    """e.g. view ([A],[C],[S],[O]) -> '[A] food [C] food quality [S] great [O] null'."""
    m = element_map(t, mode)
    return " ".join(f"{mk} {m[mk]}" for mk in view)


def linearise_many(tuples: Sequence[Tuple[str, ...]], views: Sequence[Sequence[str]], mode: str) -> str:
    """One tuple per view; tuples beyond the number of views reuse the last view (as in DOT)."""
    parts = [linearise(t, views[min(j, len(views) - 1)], mode) for j, t in enumerate(tuples)]
    return f" {SSEP} ".join(parts)


def template(views: Sequence[Sequence[str]]) -> str:
    """Order template: '[A] [C] [S] [O] [SSEP] [C] [S] [A] [O]'."""
    return f" {SSEP} ".join(view_str(v) for v in views)


def generator_input(sentence: str, views: Sequence[Sequence[str]]) -> str:
    return f"{sentence} {template(views)}"


# ----------------------------------------------------------------------------- parsing
_MARK_RE = re.compile(r"\[(A|C|S|O)\]")


def parse_segment(seg: str, mode: str) -> Optional[Tuple[str, ...]]:
    """Parse one '[X] v [Y] w ...' segment into a normalised tuple, or None if malformed."""
    seg = seg.strip()
    marks = list(_MARK_RE.finditer(seg))
    need = {"A", "C", "S", "O"} if mode == "quad" else {"A", "O", "S"}
    vals: Dict[str, str] = {}
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(seg)
        key = m.group(1)
        if key in vals or key not in need:
            return None
        vals[key] = norm_text(seg[m.end():end])
    if set(vals) != need or any(v == "" for v in vals.values()):
        return None
    if mode == "quad":
        a = "null" if vals["A"] == "it" else vals["A"]
        s = SENT2WORD.get(vals["S"], vals["S"])
        return (a, vals["C"], s, vals["O"])
    return (vals["A"], vals["O"], SENT2WORD.get(vals["S"], vals["S"]))


def split_segments(text: str) -> List[str]:
    return [s for s in text.split(SSEP)]


def parse_output(text: str, mode: str) -> List[Optional[Tuple[str, ...]]]:
    """Parse a generated sequence; keeps one entry per segment (None if malformed) so that
    segment i stays aligned with the token-level confidence of segment i."""
    text = text.replace("</s>", " ").replace("<pad>", " ")
    return [parse_segment(s, mode) for s in split_segments(text)]


# ----------------------------------------------------------------------------- implicitness and anchors
def implicit_elements(t: Tuple[str, ...], sentence: str, mode: str) -> List[str]:
    """Markers whose element is implicit. Quad mode: value 'null'. Triplet (Im) mode:
    implicit elements carry inferred terms, so an element is implicit if its term does not
    occur in the sentence."""
    if mode == "quad":
        out = []
        if t[0] == "null":
            out.append("[A]")
        if t[3] == "null":
            out.append("[O]")
        return out
    words = f" {sentence} "
    out = []
    if f" {t[0]} " not in words:
        out.append("[A]")
    if f" {t[1]} " not in words:
        out.append("[O]")
    return out


def has_implicit(t: Tuple[str, ...], sentence: str, mode: str) -> bool:
    return bool(implicit_elements(t, sentence, mode))


def anchor_of(t: Tuple[str, ...], sentence: str, mode: str) -> Tuple[str, str]:
    """(anchor marker, anchor surface value). Quad: aspect if explicit, else category.
    Triplet: target if explicit, else opinion if explicit, else sentiment."""
    imp = set(implicit_elements(t, sentence, mode))
    m = element_map(t, mode)
    if mode == "quad":
        mk = "[A]" if "[A]" not in imp else "[C]"
    else:
        mk = "[A]" if "[A]" not in imp else ("[O]" if "[O]" not in imp else "[S]")
    return mk, m[mk]


def tuple_key(t: Tuple[str, ...]) -> str:
    return " || ".join(t)


def key_tuple(k: str) -> Tuple[str, ...]:
    return tuple(k.split(" || "))
