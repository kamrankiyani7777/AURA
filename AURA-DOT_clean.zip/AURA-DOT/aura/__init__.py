"""AURA: Adaptive Uncertainty-guided Re-viewing for generative ABSA.

Pure-Python modules (no torch): data, views, metrics, core, calibration.
Model-dependent modules (torch + transformers): model, constraints.
"""
