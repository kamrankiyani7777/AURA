"""Temperature selection, Platt scaling, and grid search over cached records (numpy/scipy)."""
from __future__ import annotations

import itertools
import math
from dataclasses import replace
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from scipy.optimize import minimize

from .core import Calibration, Config, hyp_tuples, run
from .metrics import exact_match_f1


def choose_temperature(records: Sequence[dict]) -> Tuple[str, Dict[str, float]]:
    """T minimising the NLL of the gold targets' element tokens on the development set.
    Each record carries rec["gold_nll"] = {T: [sum_nll, n_tokens]}."""
    tot: Dict[str, List[float]] = {}
    for r in records:
        for T, (s, n) in r.get("gold_nll", {}).items():
            a = tot.setdefault(T, [0.0, 0.0])
            a[0] += s
            a[1] += n
    if not tot:
        return "1.0", {}
    nll = {T: s / max(n, 1) for T, (s, n) in tot.items()}
    return min(nll, key=nll.get), nll


def platt_data(records: Sequence[dict], T: str) -> Tuple[np.ndarray, np.ndarray]:
    """(z, correct) for every tuple generated under any cached hypothesis."""
    zs, ys = [], []
    for r in records:
        gold = {tuple(g) for g in r["gold"]}
        for k in r["hyps"]:
            for t, z in hyp_tuples(r, int(k), T).items():
                zs.append(z)
                ys.append(1.0 if t in gold else 0.0)
    return np.asarray(zs, dtype=float), np.asarray(ys, dtype=float)


def fit_platt(z: np.ndarray, y: np.ndarray, l2: float = 1e-3) -> Tuple[float, float]:
    """Logistic regression c = sigmoid(w z + b) by maximum likelihood (small L2 on w)."""
    if len(z) == 0 or y.min() == y.max():
        return 1.0, 0.0

    def loss(p):
        w, b = p
        s = w * z + b
        # log(1 + exp(-s)) for y=1, log(1 + exp(s)) for y=0, numerically stable
        l = np.logaddexp(0.0, -s) * y + np.logaddexp(0.0, s) * (1 - y)
        return l.mean() + l2 * w * w

    res = minimize(loss, x0=np.array([1.0, 0.0]), method="L-BFGS-B")
    w, b = res.x
    return float(w), float(b)


def fit_calibration(dev_records: Sequence[dict]) -> Tuple[Calibration, dict]:
    T, nll = choose_temperature(dev_records)
    z, y = platt_data(dev_records, T)
    w, b = fit_platt(z, y)
    return Calibration(T=T, w=w, b=b), {"T_nll": nll, "n_platt": int(len(z)), "pos_rate": float(y.mean()) if len(y) else None}


DEFAULT_GRID = {
    "rho": [0.80, 0.90, 0.95],
    "H": [2, 3],
    # down to 0.1: on low-precision data (MEMD Books/Clothing) sigma(w*z + b) with b < 0 stays below 0.5
    # for every tuple, so a grid starting at 0.5 would flag everything
    "tau": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
    "tau_v": [0.3, 0.4, 0.5],
    "M": [1, 2, 3, 4],
    # agreement-aware vote (core.vote): [0, 2, 3] was tried (tuned_v2.json / results_v2.json); it raised dev
    # F1 but not test F1 (51.17 vs 51.18) at +0.45 passes, so the main setting keeps the confidence vote
    "agree": [0],
}


def evaluate_config(records, cfg: Config, cal: Calibration) -> Dict[str, float]:
    outs = run(records, cfg, cal)
    f = exact_match_f1([o["pred"] for o in outs], [[tuple(g) for g in r["gold"]] for r in records])
    f["passes"] = float(np.mean([o["passes"] for o in outs]))
    f["flag_rate"] = float(sum(o["flagged"] for o in outs) / max(1, sum(o["n_pool"] for o in outs)))
    return f


def grid_search(dev_records, cal: Calibration, base: Config = Config(), grid: Dict[str, list] = None,
                fixed: Dict[str, object] = None) -> Tuple[Config, List[dict]]:
    """Exhaustive search on the development set: maximise F1, tie-break on fewer passes."""
    grid = dict(DEFAULT_GRID if grid is None else grid)
    for k in (fixed or {}):
        grid.pop(k, None)
    keys = list(grid)
    results = []
    best, best_key = None, None
    for vals in itertools.product(*[grid[k] for k in keys]):
        cfg = replace(base, **dict(zip(keys, vals)), **(fixed or {}))
        m = evaluate_config(dev_records, cfg, cal)
        results.append({**dict(zip(keys, vals)), **m})
        key = (round(m["f1"], 4), -m["passes"])
        if best_key is None or key > best_key:
            best, best_key = cfg, key
    return best, results
