"""Marker-aware token scanning and structure-constrained decoding (torch + transformers).

The scanner and state logic are pure Python over token-id lists; only the LogitsProcessor
touches torch. Structural rules enforced during decoding (stronger than DOT's constraint):
  * every tuple contains each element marker exactly once, in any order;
  * a [SSEP] may only follow a complete tuple; EOS may only follow a complete tuple;
  * element contents are restricted: aspect/opinion -> tokens of the input sentence
    (+ "it" / "null" for implicit elements), category -> categories seen in training,
    sentiment -> great / bad / ok. In free-vocabulary mode (Lap-Im / Res-Im, where implicit
    elements are inferred terms) aspect/opinion contents are unrestricted.
  * single-tuple mode (re-viewing): EOS is forced once the first tuple is complete.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Set, Tuple

from .data import QUAD_MARKERS, SSEP, TRIPLET_MARKERS

ALL = None   # sentinel: unrestricted content


@dataclass
class MarkerVocab:
    patterns: Dict[str, List[int]]          # marker string -> token ids (as written after a space)
    eos_id: int
    pad_id: int
    elements: List[str]                     # element markers for the task mode
    starts: Set[int] = field(default_factory=set)

    @classmethod
    def build(cls, tokenizer, mode: str) -> "MarkerVocab":
        elements = QUAD_MARKERS if mode == "quad" else TRIPLET_MARKERS
        pats = {}
        base = tokenizer("x", add_special_tokens=False).input_ids
        for mk in elements + [SSEP]:
            full = tokenizer(f"x {mk}", add_special_tokens=False).input_ids
            assert full[: len(base)] == base, f"tokenizer splits 'x' differently in context: {full}"
            pats[mk] = full[len(base):]
            at_start = tokenizer(mk, add_special_tokens=False).input_ids
            assert at_start == pats[mk], (f"marker {mk} tokenises differently at sequence start "
                                          f"{at_start} vs after a space {pats[mk]}")
        mv = cls(pats, tokenizer.eos_token_id, tokenizer.pad_token_id, list(elements))
        mv.starts = {p[0] for p in pats.values()}
        return mv


@dataclass
class ScanState:
    tuples_done: int = 0
    seen: Tuple[str, ...] = ()              # markers seen in the current tuple
    last: Optional[str] = None              # last completed marker
    n_content: int = 0                      # content tokens since last marker
    partial: Tuple[int, ...] = ()           # unfinished marker prefix at the end
    segments: List[List[Tuple[int, str]]] = field(default_factory=lambda: [[]])  # per tuple: (pos, element)


def scan(ids: Sequence[int], mv: MarkerVocab) -> ScanState:
    """Walk a decoder token sequence (without the decoder start token)."""
    st = ScanState()
    i, n = 0, len(ids)
    pats = sorted(mv.patterns.items(), key=lambda kv: -len(kv[1]))
    while i < n:
        tok = ids[i]
        if tok in (mv.eos_id, mv.pad_id):
            break
        matched = None
        for mk, p in pats:
            if list(ids[i:i + len(p)]) == p:
                matched = (mk, p)
                break
        if matched is None:
            # an unfinished marker at the very end?
            tail = tuple(ids[i:])
            if tail and any(len(p) > len(tail) and tuple(p[: len(tail)]) == tail for p in mv.patterns.values()):
                st.partial = tail
                break
            st.segments[-1].append((i, st.last))
            st.n_content += 1
            i += 1
            continue
        mk, p = matched
        if mk == SSEP:
            st.tuples_done += 1
            st.seen = ()
            st.segments.append([])
        else:
            st.seen = st.seen + (mk,)
        st.last = mk
        st.n_content = 0
        i += len(p)
    return st


def allowed_next(st: ScanState, mv: MarkerVocab, content: Dict[str, Optional[Set[int]]],
                 single: bool = False):
    """Return (allowed_set or ALL, excluded_set). ALL means 'anything except excluded'."""
    complete = set(st.seen) == set(mv.elements)
    next_markers = [SSEP] if complete else [m for m in mv.elements if m not in st.seen]
    if single and complete:
        next_markers = []
    if st.partial:
        k = len(st.partial)
        nxt = {mv.patterns[m][k] for m in next_markers
               if len(mv.patterns[m]) > k and tuple(mv.patterns[m][:k]) == st.partial}
        return (nxt or {mv.eos_id}), set()
    if st.last is None or st.last == SSEP:          # start, or right after [SSEP]
        return {mv.patterns[m][0] for m in next_markers if m != SSEP}, set()
    if st.n_content == 0:                          # right after an element marker: need content
        c = content.get(st.last)
        if c is ALL:
            return ALL, {mv.eos_id, mv.pad_id} | mv.starts
        return set(c) - mv.starts - {mv.eos_id}, set()
    # inside content: continue, start a marker, or finish
    starts = {mv.patterns[m][0] for m in next_markers}
    extra = starts | ({mv.eos_id} if complete else set())
    c = content.get(st.last)
    if c is ALL:
        excl = {mv.pad_id} | ({mv.eos_id} if not complete else set())
        excl -= extra
        return ALL, excl
    return set(c) | extra, set()


def content_vocab(tokenizer, mode: str, source_ids: Sequence[int], categories: Sequence[str],
                  free_vocab: bool = False) -> Dict[str, Optional[Set[int]]]:
    enc = lambda s: tokenizer(" " + s, add_special_tokens=False).input_ids
    src = set(source_ids) - {tokenizer.eos_token_id, tokenizer.pad_token_id}
    sent = set(enc("great")) | set(enc("bad")) | set(enc("ok"))
    if mode == "quad":
        cats = set()
        for c in categories:
            cats |= set(enc(c))
        if free_vocab:
            return {"[A]": ALL, "[O]": ALL, "[C]": cats, "[S]": sent}
        return {"[A]": src | set(enc("it")), "[O]": src | set(enc("null")), "[C]": cats, "[S]": sent}
    if free_vocab:
        return {"[A]": ALL, "[O]": ALL, "[S]": sent}
    return {"[A]": src | set(enc("null")), "[O]": src | set(enc("null")), "[S]": sent}


try:  # torch part
    import torch
    from transformers import LogitsProcessor

    class StructureConstraint(LogitsProcessor):
        def __init__(self, mv: MarkerVocab, contents: List[Dict[str, Optional[Set[int]]]], single: bool = False,
                     vocab_only: bool = False):
            self.mv, self.contents, self.single, self.vocab_only = mv, contents, single, vocab_only

        def __call__(self, input_ids, scores):
            mask = torch.full_like(scores, float("-inf"))
            for b in range(input_ids.shape[0]):
                ids = input_ids[b, 1:].tolist()           # drop decoder start token
                if self.vocab_only:
                    allowed = set()
                    for c in self.contents[b].values():
                        if c is not ALL:
                            allowed |= c
                    if any(c is ALL for c in self.contents[b].values()):
                        mask[b] = 0.0
                        continue
                    allowed |= self.mv.starts | {self.mv.eos_id}
                    for p in self.mv.patterns.values():
                        allowed |= set(p)
                    mask[b, list(allowed)] = 0.0
                    continue
                st = scan(ids, self.mv)
                allowed, excluded = allowed_next(st, self.mv, self.contents[b], self.single)
                if allowed is ALL:
                    mask[b] = 0.0
                    if excluded:
                        mask[b, list(excluded)] = float("-inf")
                else:
                    if not allowed:
                        allowed = {self.mv.eos_id}
                    mask[b, list(allowed)] = 0.0
            return scores + mask
except ImportError:  # pragma: no cover - allows the pure-python parts to be used without torch
    pass
