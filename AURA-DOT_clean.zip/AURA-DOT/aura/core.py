"""AURA decision logic over a cached inference record (no torch).

A cache record (one per sentence, produced by scripts_aura/infer.py) holds:
  betas    : [beta_1, ..., beta_{Kmax-1}]  P(continue) at each view boundary of the count model
  hyps     : {"k": {"segments": [{"t": tuple|None, "view": [...], "z": {"T": z}}]}}
             generator outputs for every decoded count hypothesis k
  reviews  : {tuple_key: {"anchor": mk, "implicit": [...], "used_views": [[...]],
             "cands": [{"view": [...], "nll": float, "implicit_last": bool, "t": tuple|None, "z": {...}}],
             "rand_cands": [...same, unanchored random views...]}}
             re-decodes of each pooled tuple under all its anchored views (+ a few random ones)
Everything below is a pure function of (record, config, calibration), so tuning, ablations,
oracle studies and DOT baselines are computed from one cached GPU run.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Sequence, Tuple

from .data import MAX_VIEWS, key_tuple, tuple_key

Tup = Tuple[str, ...]


@dataclass
class Config:
    mode: str = "aura"            # aura | dot | dot_oracle | aura_oracle
    rho: float = 0.9              # cumulative belief mass of the hypothesis set
    H: int = 2                    # max number of count hypotheses
    tau: float = 0.7              # gate threshold on calibrated confidence
    tau_v: float = 0.4            # vote threshold
    M: int = 2                    # extra views per flagged tuple
    agree: int = 0                # keep a reviewed tuple produced by >= agree of the votes (0: off)
    T: str = "1.0"                # temperature key (string, as stored in the cache)
    # ablation switches
    use_belief: bool = True       # False: commit to the greedy count (as DOT)
    use_support: bool = True      # False: gate on confidence only
    use_calibration: bool = True  # False: gate on the raw score exp(z) at T=1, no Platt
    review: str = "anchored"      # anchored | drop | accept_all
    view_rank: str = "full"       # full (implicit-last + NLL) | nll (no implicit cue) | random
    seed: int = 0

    def to_dict(self):
        return asdict(self)


@dataclass
class Calibration:
    T: str = "1.0"
    w: float = 1.0
    b: float = 0.0

    def conf(self, z: float) -> float:
        return 1.0 / (1.0 + math.exp(-(self.w * z + self.b)))


# ----------------------------------------------------------------------------- count belief
def count_belief(betas: Sequence[float], kmax: int = MAX_VIEWS) -> List[float]:
    """P(K=k) = (1 - beta_k) * prod_{i<k} beta_i, with beta_Kmax = 0 (Eq. 1)."""
    b = list(betas[: kmax - 1]) + [0.0]
    probs, run = [], 1.0
    for k in range(kmax):
        probs.append(run * (1.0 - b[k]))
        run *= b[k]
    s = sum(probs) or 1.0
    return [p / s for p in probs]


def greedy_count(betas: Sequence[float], kmax: int = MAX_VIEWS) -> int:
    """Count produced by greedy decoding of the template: stop at the first boundary whose
    P(continue) < 0.5. This is DOT's hard estimate."""
    for i, b in enumerate(betas[: kmax - 1]):
        if b < 0.5:
            return i + 1
    return kmax


def hypothesis_set(probs: Sequence[float], rho: float, H: int) -> List[int]:
    order = sorted(range(len(probs)), key=lambda i: -probs[i])
    out, mass = [], 0.0
    for i in order:
        out.append(i + 1)
        mass += probs[i]
        if mass >= rho or len(out) >= H:
            break
    return sorted(out)


# ----------------------------------------------------------------------------- per-hypothesis tuples
def hyp_tuples(rec: dict, k: int, T: str) -> Dict[Tup, float]:
    """Tuples generated under hypothesis k -> best z (a tuple may appear twice)."""
    h = rec["hyps"].get(str(k))
    if h is None:
        raise KeyError(f"hypothesis k={k} not in cache for record {rec.get('idx')}")
    out: Dict[Tup, float] = {}
    for seg in h["segments"]:
        if seg["t"] is None:
            continue
        t = tuple(seg["t"])
        z = seg["z"][T]
        out[t] = max(out.get(t, -1e9), z)
    return out


def support(per_hyp: Dict[int, Dict[Tup, float]], probs: Sequence[float]) -> Dict[Tup, float]:
    """sup(q) = sum over hypotheses producing q of the renormalised belief (Eq. 2)."""
    ks = list(per_hyp)
    mass = sum(probs[k - 1] for k in ks) or 1.0
    sup: Dict[Tup, float] = {}
    for k in ks:
        for t in per_hyp[k]:
            sup[t] = sup.get(t, 0.0) + probs[k - 1] / mass
    return sup


# ----------------------------------------------------------------------------- re-viewing
def ranked_candidates(rv: dict, how: str, seed: int, key: str, exclude=()) -> List[dict]:
    """Re-decodes of a flagged tuple in the order they are used. `exclude`: views already used
    by the chosen count hypotheses (not re-used for re-viewing)."""
    ex = {tuple(v) for v in exclude}
    cands = [c for c in rv["cands"] if tuple(c["view"]) not in ex]
    if how == "full":
        pref = [c for c in cands if c["implicit_last"]] or cands
        return sorted(pref, key=lambda c: c["nll"])
    if how == "nll":
        return sorted(cands, key=lambda c: c["nll"])
    if how == "random":            # unanchored, randomly chosen views (cached separately)
        cands = [c for c in rv.get("rand_cands", []) if tuple(c["view"]) not in ex]
        rng = random.Random(f"{seed}-{key}")
        rng.shuffle(cands)
        return cands
    raise ValueError(how)


def vote(q0: Tup, c0: float, cands: Sequence[Tuple[Optional[Tup], float]], tau_v: float, agree: int = 0):
    """Confidence-weighted vote over q0 and the re-decoded tuples (Eq. 6). With agree > 0 the winning
    tuple is also kept when at least `agree` of the votes produce it: flagged tuples have low
    confidence by construction, so A alone rarely clears tau_v even when the views agree.
    Returns (kept tuple or None, agreement A)."""
    allc = [(q0, c0)] + list(cands)
    n = len(allc)
    freq: Dict[Tup, int] = {}
    conf_sum: Dict[Tup, float] = {}
    for t, c in allc:
        if t is None:
            continue
        freq[t] = freq.get(t, 0) + 1
        conf_sum[t] = conf_sum.get(t, 0.0) + c
    if not freq:
        return None, 0.0
    best = max(freq, key=lambda t: (freq[t], conf_sum[t]))
    A = conf_sum[best] / n
    keep = A >= tau_v or (agree > 0 and freq[best] >= agree)
    return (best if keep else None), A


# ----------------------------------------------------------------------------- decision
def decide(rec: dict, cfg: Config, cal: Calibration, kmax: int = MAX_VIEWS) -> dict:
    """Final prediction for one record plus bookkeeping (passes, flagged, per-tuple info)."""
    betas = rec["betas"]
    probs = count_belief(betas, kmax)
    T = cal.T if cfg.use_calibration else "1.0"

    def conf(z: float) -> float:
        if cfg.use_calibration:
            return cal.conf(z)
        return math.exp(min(z, 0.0))               # raw: geometric-mean token probability exp(z)

    gold_k = min(max(rec["gold_count"], 1), kmax)
    if cfg.mode in ("dot", "dot_oracle"):
        k = gold_k if cfg.mode == "dot_oracle" else greedy_count(betas, kmax)
        tuples = hyp_tuples(rec, k, T)
        return {"pred": set(tuples), "passes": 2, "K": [k], "flagged": 0, "n_pool": len(tuples), "info": []}

    if cfg.mode == "aura_oracle":
        K = [gold_k]
    elif cfg.use_belief:
        K = hypothesis_set(probs, cfg.rho, cfg.H)
    else:
        K = [greedy_count(betas, kmax)]
    per_hyp = {k: hyp_tuples(rec, k, T) for k in K}
    sup = support(per_hyp, probs) if cfg.mode != "aura_oracle" else {t: 1.0 for t in per_hyp[K[0]]}
    pool: Dict[Tup, float] = {}
    for d in per_hyp.values():
        for t, z in d.items():
            pool[t] = max(pool.get(t, -1e9), z)

    pred, info, passes, flagged = set(), [], 1 + len(K), 0
    for t, z in pool.items():
        c = conf(z)
        ok_sup = (sup[t] >= 1.0 - 1e-9) if cfg.use_support else True
        if ok_sup and c >= cfg.tau:
            pred.add(t)
            info.append({"t": t, "c": c, "sup": sup[t], "action": "accept"})
            continue
        flagged += 1
        if cfg.review == "accept_all":
            pred.add(t)
            info.append({"t": t, "c": c, "sup": sup[t], "action": "flag-keep"})
            continue
        if cfg.review == "drop":
            info.append({"t": t, "c": c, "sup": sup[t], "action": "flag-drop"})
            continue
        rv = rec["reviews"].get(tuple_key(t))
        used = rec.get("R", [])[: max(K)]
        cands = ranked_candidates(rv, cfg.view_rank, cfg.seed, tuple_key(t), used)[: cfg.M] if rv else []
        passes += len(cands)
        cs = [(tuple(c["t"]) if c["t"] is not None else None, conf(c["z"][T])) for c in cands]
        kept, A = vote(t, c, cs, cfg.tau_v, cfg.agree)
        if kept is not None:
            pred.add(kept)
        info.append({"t": t, "c": c, "sup": sup[t], "action": "review", "kept": kept, "A": A,
                     "changed": kept is not None and kept != t})
    return {"pred": pred, "passes": passes, "K": K, "flagged": flagged, "n_pool": len(pool), "info": info}


def run(records: Sequence[dict], cfg: Config, cal: Calibration, kmax: int = MAX_VIEWS) -> List[dict]:
    return [decide(r, cfg, cal, kmax) for r in records]
