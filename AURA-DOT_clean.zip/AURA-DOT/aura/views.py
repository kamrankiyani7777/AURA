"""View enumeration, dataset-level ranking R, and anchored view selection (no torch)."""
from __future__ import annotations

import itertools
import json
import random
from typing import Callable, Dict, List, Sequence, Tuple

from .data import Example, linearise_many, markers_for

View = Tuple[str, ...]


def all_views(mode: str) -> List[View]:
    return [tuple(p) for p in itertools.permutations(markers_for(mode))]


def rank_views_dataset_level(examples: Sequence[Example], mode: str,
                             score_fn: Callable[[List[str], List[str]], List[float]],
                             max_examples: int = 2000, seed: int = 0) -> List[View]:
    """Dataset-level ranking R (as in MvP): for every view, the mean per-token NLL of a
    *pre-trained* (not fine-tuned) T5 when all gold tuples of a training sentence are written
    in that view; lower is better. `score_fn(inputs, targets) -> mean NLL per pair`."""
    rng = random.Random(seed)
    pool = list(examples)
    if len(pool) > max_examples:
        pool = rng.sample(pool, max_examples)
    views = all_views(mode)
    scores: Dict[View, float] = {}
    for v in views:
        inputs = [ex.sentence for ex in pool]
        targets = [linearise_many(ex.tuples, [v], mode) for ex in pool]
        nll = score_fn(inputs, targets)
        scores[v] = float(sum(nll) / max(1, len(nll)))
    return sorted(views, key=lambda v: scores[v])


def save_ranking(path: str, ranking: Sequence[View]) -> None:
    with open(path, "w") as fp:
        json.dump([list(v) for v in ranking], fp, indent=1)


def load_ranking(path: str) -> List[View]:
    with open(path) as fp:
        return [tuple(v) for v in json.load(fp)]


def anchored_views(anchor_marker: str, implicit: Sequence[str], mode: str,
                   exclude: Sequence[View] = (), implicit_last: bool = True) -> List[View]:
    """Views that start with the anchor marker; with `implicit_last`, implicit elements are
    placed last (if several are implicit, they occupy the final positions)."""
    out = []
    imp = [m for m in implicit if m != anchor_marker]
    for v in all_views(mode):
        if v[0] != anchor_marker or v in exclude:
            continue
        if implicit_last and imp and set(v[-len(imp):]) != set(imp):
            continue
        out.append(v)
    return out


def training_anchor_view(anchor_marker: str, implicit: Sequence[str], mode: str,
                         ranking: Sequence[View]) -> View:
    """View used for the single-view anchored training example of a gold tuple: the
    best-ranked (by R) view that starts with the anchor and puts implicit elements last."""
    cands = set(anchored_views(anchor_marker, implicit, mode, implicit_last=True)) or \
        set(anchored_views(anchor_marker, implicit, mode, implicit_last=False))
    for v in ranking:
        if v in cands:
            return v
    return sorted(cands)[0]
