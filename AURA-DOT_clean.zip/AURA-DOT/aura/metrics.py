"""Evaluation: exact-match F1 (no stop-word filtering), implicit-subset F1, count accuracy,
ECE, and paired bootstrap significance (no torch)."""
from __future__ import annotations

import random
from typing import Dict, List, Sequence, Set, Tuple

from .data import has_implicit

Tup = Tuple[str, ...]


def prf(n_tp: int, n_pred: int, n_gold: int) -> Dict[str, float]:
    p = n_tp / n_pred if n_pred else 0.0
    r = n_tp / n_gold if n_gold else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return {"precision": 100 * p, "recall": 100 * r, "f1": 100 * f, "tp": n_tp, "pred": n_pred, "gold": n_gold}


def exact_match_f1(preds: Sequence[Set[Tup]], golds: Sequence[Sequence[Tup]]) -> Dict[str, float]:
    """Micro P/R/F1; a predicted tuple is correct iff all elements match a gold tuple exactly.
    Predictions are de-duplicated per sentence; gold duplicates are kept (as in the data)."""
    tp = npred = ngold = 0
    for p, g in zip(preds, golds):
        p = set(p)
        npred += len(p)
        ngold += len(g)
        gs = list(g)
        for t in p:
            if t in gs:
                tp += 1
                gs.remove(t)
    return prf(tp, npred, ngold)


def implicit_subset_f1(preds, golds, sentences, mode: str) -> Dict[str, float]:
    """F1 restricted to tuples with at least one implicit element (on both sides)."""
    p_sub = [{t for t in p if has_implicit(t, s, mode)} for p, s in zip(preds, sentences)]
    g_sub = [[t for t in g if has_implicit(t, s, mode)] for g, s in zip(golds, sentences)]
    return exact_match_f1(p_sub, g_sub)


def explicit_subset_f1(preds, golds, sentences, mode: str) -> Dict[str, float]:
    p_sub = [{t for t in p if not has_implicit(t, s, mode)} for p, s in zip(preds, sentences)]
    g_sub = [[t for t in g if not has_implicit(t, s, mode)] for g, s in zip(golds, sentences)]
    return exact_match_f1(p_sub, g_sub)


def ece(confidences: Sequence[float], correct: Sequence[int], n_bins: int = 10) -> float:
    """Expected calibration error with equal-width bins."""
    n = len(confidences)
    if n == 0:
        return float("nan")
    total = 0.0
    for b in range(n_bins):
        lo, hi = b / n_bins, (b + 1) / n_bins
        idx = [i for i, c in enumerate(confidences) if (lo < c <= hi) or (b == 0 and c == 0.0)]
        if not idx:
            continue
        acc = sum(correct[i] for i in idx) / len(idx)
        conf = sum(confidences[i] for i in idx) / len(idx)
        total += len(idx) / n * abs(acc - conf)
    return 100 * total


def paired_bootstrap(preds_a, preds_b, golds, n_samples: int = 1000, seed: int = 0) -> float:
    """p-value that system A is *not* better than B in F1 (one-sided, sentence resampling)."""
    rng = random.Random(seed)
    n = len(golds)
    base = exact_match_f1(preds_a, golds)["f1"] - exact_match_f1(preds_b, golds)["f1"]
    if base <= 0:
        return 1.0
    worse = 0
    for _ in range(n_samples):
        idx = [rng.randrange(n) for _ in range(n)]
        d = exact_match_f1([preds_a[i] for i in idx], [golds[i] for i in idx])["f1"] - \
            exact_match_f1([preds_b[i] for i in idx], [golds[i] for i in idx])["f1"]
        if d <= 0:
            worse += 1
    return worse / n_samples
