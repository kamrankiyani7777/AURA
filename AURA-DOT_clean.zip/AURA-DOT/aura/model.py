"""T5 training, constrained decoding with forced prefixes, and teacher-forced scoring.

Requires: torch, transformers (tested API: transformers>=4.40). Runs on CPU or CUDA.
"""
from __future__ import annotations

import math
import random
import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.nn.utils.rnn import pad_sequence
from transformers import (AutoTokenizer, LogitsProcessorList, T5ForConditionalGeneration,
                          get_linear_schedule_with_warmup)

from .constraints import MarkerVocab, StructureConstraint, scan, content_vocab
from .data import SSEP

DEFAULT_T_GRID = ["0.5", "0.75", "1.0", "1.25", "1.5", "2.0", "2.5", "3.0"]


def device_auto() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load(name_or_path: str, device=None):
    tok = AutoTokenizer.from_pretrained(name_or_path)
    model = T5ForConditionalGeneration.from_pretrained(name_or_path)
    model.to(device or device_auto())
    model.eval()
    return model, tok


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ----------------------------------------------------------------------------- training
def _backward_batch(model, ids, mask, lab, bf16: bool, parts: int = 1) -> float:
    """Backward pass for one batch; returns its mean loss. On CUDA out-of-memory the batch is
    split into `parts` chunks, each chunk's token-mean loss weighted by its share of target
    tokens, so the accumulated gradient equals the full-batch gradient."""
    if parts > ids.size(0):
        raise RuntimeError("a single training example does not fit in GPU memory")
    try:
        n_tok = (lab != -100).sum()
        total = 0.0
        for c_ids, c_mask, c_lab in zip(ids.tensor_split(parts), mask.tensor_split(parts), lab.tensor_split(parts)):
            w = (c_lab != -100).sum() / n_tok
            with torch.autocast(device_type=ids.device.type, dtype=torch.bfloat16, enabled=bf16):
                loss = model(input_ids=c_ids, attention_mask=c_mask, labels=c_lab).loss * w
            loss.backward()
            total += loss.item()
        return total
    except torch.OutOfMemoryError:
        pass  # retry outside the handler so the exception's references to GPU memory are freed
    loss = None
    model.zero_grad(set_to_none=True)
    torch.cuda.empty_cache()
    return _backward_batch(model, ids, mask, lab, bf16, parts * 2)


def train_seq2seq(model, tok, pairs: Sequence[Tuple[str, str]], epochs: int, batch_size: int = 16,
                  lr: float = 1e-4, max_src: int = 256, max_tgt: int = 320, seed: int = 0,
                  bf16: bool = False, grad_clip: float = 1.0, log_every: int = 100, log=print):
    """Plain fine-tuning loop (AdamW, linear decay, no warm-up), as in DOT's setting."""
    dev = next(model.parameters()).device
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    steps = epochs * math.ceil(len(pairs) / batch_size)
    sched = get_linear_schedule_with_warmup(opt, 0, steps)
    rng = random.Random(seed)
    order = list(range(len(pairs)))
    step, t0 = 0, time.time()
    for ep in range(epochs):
        rng.shuffle(order)
        tot, nb = 0.0, 0
        for s in range(0, len(order), batch_size):
            batch = [pairs[i] for i in order[s:s + batch_size]]
            enc = tok([b[0] for b in batch], max_length=max_src, truncation=True, padding=True, return_tensors="pt").to(dev)
            lab = tok([b[1] for b in batch], max_length=max_tgt, truncation=True, padding=True, return_tensors="pt").input_ids.to(dev)
            lab[lab == tok.pad_token_id] = -100
            loss = _backward_batch(model, enc.input_ids, enc.attention_mask, lab, bf16 and dev.type == "cuda")
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            opt.step()
            sched.step()
            opt.zero_grad(set_to_none=True)
            tot += loss
            nb += 1
            step += 1
            if log_every and step % log_every == 0:
                log(f"  epoch {ep + 1}/{epochs} step {step}/{steps} loss {tot / nb:.4f} ({time.time() - t0:.0f}s)")
        log(f"epoch {ep + 1}/{epochs} mean loss {tot / max(nb, 1):.4f}")
    model.eval()
    return model


# ----------------------------------------------------------------------------- scoring
@torch.no_grad()
def token_logprobs(model, tok, inputs: Sequence[str], target_ids: Sequence[Sequence[int]],
                   T_grid: Sequence[str] = ("1.0",), batch_size: int = 32, max_src: int = 256,
                   ) -> List[Dict[str, np.ndarray]]:
    """Teacher-forced log-probabilities of the given target token ids (EOS included if present),
    at several temperatures: out[i][T] = array of log p_T(y_t | y_<t, x)."""
    dev = next(model.parameters()).device
    out: List[Dict[str, np.ndarray]] = []
    for s in range(0, len(inputs), batch_size):
        enc = tok(list(inputs[s:s + batch_size]), max_length=max_src, truncation=True, padding=True,
                  return_tensors="pt").to(dev)
        tg = [torch.tensor(list(t), dtype=torch.long) for t in target_ids[s:s + batch_size]]
        lab = pad_sequence(tg, batch_first=True, padding_value=-100).to(dev)
        logits = model(input_ids=enc.input_ids, attention_mask=enc.attention_mask, labels=lab).logits.float()
        gather_idx = lab.clamp(min=0).unsqueeze(-1)
        per_T = {}
        for T in T_grid:
            lp = torch.log_softmax(logits / float(T), dim=-1).gather(-1, gather_idx).squeeze(-1)
            per_T[T] = lp.cpu().numpy()
        for b, t in enumerate(tg):
            out.append({T: per_T[T][b, : len(t)] for T in T_grid})
    return out


def mean_nll(model, tok, inputs: Sequence[str], targets: Sequence[str], batch_size: int = 32) -> List[float]:
    ids = [tok(t, add_special_tokens=True).input_ids for t in targets]     # appends EOS
    lps = token_logprobs(model, tok, inputs, ids, ("1.0",), batch_size)
    return [float(-lp["1.0"].mean()) for lp in lps]


def segment_z(ids: Sequence[int], lp_by_T: Dict[str, np.ndarray], mv: MarkerVocab) -> List[Dict[str, float]]:
    """Mean log-prob of the *content* tokens of each tuple segment (markers, separators and
    EOS excluded) at every temperature (Eq. 3)."""
    st = scan(ids, mv)
    res = []
    for seg in st.segments:
        pos = [p for p, el in seg if el is not None]
        if not pos:
            res.append({T: -1e9 for T in lp_by_T})
            continue
        res.append({T: float(np.mean(lp_by_T[T][pos])) for T in lp_by_T})
    return res


def content_nll(ids: Sequence[int], lp_by_T: Dict[str, np.ndarray], mv: MarkerVocab) -> Dict[str, Tuple[float, int]]:
    st = scan(ids, mv)
    pos = [p for seg in st.segments for p, el in seg if el is not None]
    return {T: (float(-lp_by_T[T][pos].sum()), len(pos)) for T in lp_by_T}


@torch.no_grad()
def count_betas(model_f, tok, sentences: Sequence[str], template_text: str, mv: MarkerVocab,
                batch_size: int = 32) -> List[List[float]]:
    """beta_i = P(continue) at the i-th view boundary of the count model's template:
    renormalised over {first token of [SSEP], EOS}. One teacher-forced pass per sentence."""
    ids = tok(template_text, add_special_tokens=True).input_ids          # ends with EOS
    st = scan(ids, mv)
    # positions where an [SSEP] pattern starts = boundaries 1..Kmax-1
    sep = mv.patterns[SSEP]
    bpos = [i for i in range(len(ids) - len(sep) + 1) if ids[i:i + len(sep)] == sep]
    dev = next(model_f.parameters()).device
    lab_full = torch.tensor(ids, dtype=torch.long)
    out = []
    for s in range(0, len(sentences), batch_size):
        batch = list(sentences[s:s + batch_size])
        enc = tok(batch, max_length=256, truncation=True, padding=True, return_tensors="pt").to(dev)
        lab = lab_full.unsqueeze(0).repeat(len(batch), 1).to(dev)
        logp = torch.log_softmax(model_f(input_ids=enc.input_ids, attention_mask=enc.attention_mask, labels=lab).logits.float(), -1)
        for b in range(len(batch)):
            betas = []
            for p in bpos:
                lc = logp[b, p, sep[0]].item()
                le = logp[b, p, mv.eos_id].item()
                m = max(lc, le)
                betas.append(math.exp(lc - m) / (math.exp(lc - m) + math.exp(le - m)))
            out.append(betas)
    return out


# ----------------------------------------------------------------------------- decoding
@torch.no_grad()
def constrained_generate(model, tok, inputs: Sequence[str], contents: Sequence[dict], mv: MarkerVocab,
                         prefixes: Optional[Sequence[str]] = None, single: bool = False,
                         max_new_tokens: int = 200, batch_size: int = 32, vocab_only: bool = False,
                         max_src: int = 256) -> List[List[int]]:
    """Greedy decoding under the structure constraint. With `prefixes`, each sequence starts
    with a forced decoder prefix (e.g. '[A] food'); the returned ids include the prefix and
    exclude the decoder start token."""
    dev = next(model.parameters()).device
    start = model.config.decoder_start_token_id
    pre_ids = [tok(p, add_special_tokens=False).input_ids if p else [] for p in (prefixes or [None] * len(inputs))]
    results: List[Optional[List[int]]] = [None] * len(inputs)
    # bucket by prefix length so that decoder prefixes need no padding
    buckets: Dict[int, List[int]] = {}
    for i, p in enumerate(pre_ids):
        buckets.setdefault(len(p), []).append(i)
    for plen, idxs in buckets.items():
        for s in range(0, len(idxs), batch_size):
            bi = idxs[s:s + batch_size]
            enc = tok([inputs[i] for i in bi], max_length=max_src, truncation=True, padding=True,
                      return_tensors="pt").to(dev)
            dec = torch.tensor([[start] + pre_ids[i] for i in bi], dtype=torch.long, device=dev)
            proc = StructureConstraint(mv, [contents[i] for i in bi], single=single, vocab_only=vocab_only)
            gen = model.generate(input_ids=enc.input_ids, attention_mask=enc.attention_mask,
                                 decoder_input_ids=dec, logits_processor=LogitsProcessorList([proc]),
                                 max_new_tokens=max_new_tokens, do_sample=False, num_beams=1)
            for row, i in enumerate(bi):
                ids = gen[row, 1:].tolist()
                if mv.eos_id in ids:
                    ids = ids[: ids.index(mv.eos_id) + 1]
                ids = [t for t in ids if t != mv.pad_id]
                results[i] = ids
    return results


def decode_text(tok, ids: Sequence[int]) -> str:
    return tok.decode(ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)
